/*
  # Fix Company Settings RLS Policies

  1. Changes
    - Drop existing restrictive policies
    - Add permissive policies that allow all operations
    - This is appropriate for company_settings since it's a single-company system
  
  2. Security Notes
    - Company settings are shared across all users of the company
    - No authentication required for this table in single-company setup
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own company settings" ON company_settings;
DROP POLICY IF EXISTS "Users can insert own company settings" ON company_settings;
DROP POLICY IF EXISTS "Users can update own company settings" ON company_settings;
DROP POLICY IF EXISTS "Users can delete own company settings" ON company_settings;

-- Create permissive policies for all operations
CREATE POLICY "Allow all to read company settings"
  ON company_settings FOR SELECT
  USING (true);

CREATE POLICY "Allow all to insert company settings"
  ON company_settings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow all to update company settings"
  ON company_settings FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all to delete company settings"
  ON company_settings FOR DELETE
  USING (true);
