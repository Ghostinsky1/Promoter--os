import { formatCurrency } from '../../lib/calculations';
import { SupportAct, TicketTier, Expenses } from '../../types';
import { Plus, Music, ArrowUp, ArrowDown, Trash2, Info } from 'lucide-react';

interface ArtistDeduction {
  name: string;
  amount: number;
}

interface ArtistDealTabProps {
  dealType: string;
  setDealType: (value: string) => void;
  guarantee: number;
  setGuarantee: (value: number) => void;
  artistPercentage?: number;
  setArtistPercentage?: (value: number) => void;
  taxWithholdingPct: number;
  setTaxWithholdingPct: (value: number) => void;
  depositPct: number;
  setDepositPct: (value: number) => void;
  artistBackendPct: number;
  setArtistBackendPct: (value: number) => void;
  promoterBackendPct: number;
  setPromoterBackendPct: (value: number) => void;
  supportActs: SupportAct[];
  setSupportActs: (acts: SupportAct[]) => void;
  merchRateSoft?: number;
  setMerchRateSoft?: (value: number) => void;
  merchRateHard?: number;
  setMerchRateHard?: (value: number) => void;
  artistDeductions?: ArtistDeduction[];
  setArtistDeductions?: (value: ArtistDeduction[]) => void;
  ticketTiers?: TicketTier[];
  salesTaxPct?: number;
  expenses?: Expenses;
  facilityFeePerTicket?: number;
  ascapRate?: number;
  bmiRate?: number;
  sesacRate?: number;
  insurancePerAttendee?: number;
  ccFeeRate?: number;
}

export function ArtistDealTab({
  dealType,
  setDealType,
  guarantee,
  setGuarantee,
  artistPercentage = 100,
  setArtistPercentage = () => {},
  taxWithholdingPct,
  setTaxWithholdingPct,
  depositPct,
  setDepositPct,
  artistBackendPct,
  setArtistBackendPct,
  promoterBackendPct,
  setPromoterBackendPct,
  supportActs,
  setSupportActs,
  merchRateSoft = 100,
  setMerchRateSoft = () => {},
  merchRateHard = 100,
  setMerchRateHard = () => {},
  artistDeductions = [],
  setArtistDeductions = () => {},
  ticketTiers = [],
  salesTaxPct = 0,
  expenses = { talent: {}, production: {}, marketing: {}, general: {} },
  facilityFeePerTicket = 2,
  ascapRate = 0.0023,
  bmiRate = 0.003,
  sesacRate = 0.000214,
  insurancePerAttendee = 0.62,
  ccFeeRate = 0.012,
}: ArtistDealTabProps) {
  const taxWithholding = guarantee * (taxWithholdingPct / 100);
  const totalPayout = guarantee - taxWithholding;
  const depositAmount = guarantee * (depositPct / 100);

  const calculateDealPayouts = () => {
    const grossPotential = ticketTiers.reduce((sum, tier) =>
      sum + (tier.allotment * tier.price), 0
    );

    const totalSellable = ticketTiers.reduce((sum, tier) =>
      sum + (tier.allotment - tier.comps), 0
    );

    const facilityFees = totalSellable * facilityFeePerTicket;
    const adjustedGross = grossPotential - facilityFees;
    const salesTax = adjustedGross * (salesTaxPct / 100);
    const netGross = adjustedGross - salesTax;

    const fixedExpenses =
      Object.values(expenses.talent || {}).reduce((sum: number, val) => sum + (val || 0), 0) +
      Object.values(expenses.production || {}).reduce((sum: number, val) => sum + (val || 0), 0) +
      Object.values(expenses.marketing || {}).reduce((sum: number, val) => sum + (val || 0), 0) +
      Object.values(expenses.general || {}).reduce((sum: number, val) => sum + (val || 0), 0) +
      supportActs.reduce((sum, act) => sum + (act.guarantee || 0), 0);

    const ascap = netGross * ascapRate;
    const bmi = netGross * bmiRate;
    const sesac = netGross * sesacRate;
    const insurance = totalSellable * insurancePerAttendee;
    const ccFee = netGross * ccFeeRate;
    const variableExpenses = ascap + bmi + sesac + insurance + ccFee;

    const netRevenue = netGross - fixedExpenses - variableExpenses;

    let artistPayout = 0;
    let promoterProfit = 0;

    switch (dealType) {
      case 'flat_fee':
        artistPayout = guarantee;
        promoterProfit = netRevenue - artistPayout;
        break;

      case 'guarantee_vs_percentage':
        const percentageAmount = netRevenue * (artistPercentage / 100);
        artistPayout = Math.max(guarantee, percentageAmount);
        promoterProfit = netRevenue - artistPayout;
        break;

      case 'percentage_only':
        artistPayout = netRevenue * (artistPercentage / 100);
        promoterProfit = netRevenue - artistPayout;
        break;

      case 'door_deal':
        artistPayout = netRevenue * (artistPercentage / 100);
        promoterProfit = netRevenue - artistPayout;
        break;

      default:
        artistPayout = guarantee;
        promoterProfit = netRevenue - artistPayout;
    }

    return {
      grossPotential,
      netGross,
      netRevenue,
      artistPayout,
      promoterProfit,
      totalExpenses: fixedExpenses + variableExpenses
    };
  };

  const { netRevenue, artistPayout, promoterProfit } = calculateDealPayouts();

  const addSupportAct = () => {
    setSupportActs([...supportActs, {
      name: '',
      type: 'artist',
      guarantee: 0,
      set_length: 30,
      genre: '',
      notes: ''
    }]);
  };

  const updateSupportAct = (index: number, field: keyof SupportAct, value: any) => {
    const updated = [...supportActs];
    updated[index] = { ...updated[index], [field]: value };
    setSupportActs(updated);
  };

  const removeSupportAct = (index: number) => {
    setSupportActs(supportActs.filter((_, i) => i !== index));
  };

  const moveSupportAct = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= supportActs.length) return;

    const updated = [...supportActs];
    [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
    setSupportActs(updated);
  };

  const totalSupportCost = supportActs.reduce((sum, act) => sum + (act.guarantee || 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900 mb-4">Artist Deal Terms</h2>
        <p className="text-slate-600 mb-6">Configure the artist's financial terms</p>
      </div>

      <div className="bg-white border-2 border-slate-300 rounded-lg p-6">
        <h3 className="text-lg font-bold mb-4">Deal Structure</h3>

        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-700 mb-3">Deal Type</label>
          <select
            value={dealType}
            onChange={(e) => setDealType(e.target.value)}
            className="w-full border-2 border-slate-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
          >
            <option value="flat_fee">Flat Fee - I pay artist flat amount, I keep profit</option>
            <option value="guarantee_vs_percentage">Guarantee vs Percentage - Artist gets higher</option>
            <option value="percentage_only">Percentage Only - No guarantee</option>
            <option value="door_deal">Door Deal - Split after covering costs</option>
          </select>
        </div>

        {dealType === 'flat_fee' && (
          <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-bold text-blue-900 mb-1">Flat Fee Deal</div>
                <div className="text-sm text-blue-800">
                  You pay the artist a fixed amount regardless of how the show does.
                  You keep all profit after paying the artist and covering expenses.
                </div>
                {netRevenue > 0 && (
                  <div className="text-sm text-blue-900 font-semibold mt-2">
                    Example: Pay artist {formatCurrency(guarantee)} → Show makes {formatCurrency(netRevenue)} net → You keep {formatCurrency(promoterProfit)} profit
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {dealType === 'guarantee_vs_percentage' && (
          <div className="p-4 bg-purple-50 border-2 border-purple-200 rounded-lg">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-purple-600 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-bold text-purple-900 mb-1">Guarantee vs Percentage</div>
                <div className="text-sm text-purple-800">
                  Artist gets whichever is higher: the guarantee OR their percentage of net revenue.
                  This is the standard deal for bigger artists who want protection but also upside.
                </div>
              </div>
            </div>
          </div>
        )}

        {dealType === 'percentage_only' && (
          <div className="p-4 bg-green-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-bold text-green-900 mb-1">Percentage Only</div>
                <div className="text-sm text-green-800">
                  No guarantee - artist only gets their percentage of net revenue.
                  Lower risk for you, higher risk for artist. Good for emerging artists.
                </div>
              </div>
            </div>
          </div>
        )}

        {dealType === 'door_deal' && (
          <div className="p-4 bg-orange-50 border-2 border-orange-200 rounded-lg">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-orange-600 mt-0.5 flex-shrink-0" />
              <div>
                <div className="font-bold text-orange-900 mb-1">Door Deal</div>
                <div className="text-sm text-orange-800">
                  Split the door proceeds after covering expenses. Common for co-promotions
                  or when sharing risk/reward with the artist.
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              {dealType === 'flat_fee'
                ? 'Flat Fee Amount'
                : dealType === 'percentage_only'
                ? 'No Guarantee'
                : 'Guarantee Amount'}
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">$</span>
              <input
                type="number"
                value={guarantee || ''}
                onChange={(e) => setGuarantee(Number(e.target.value))}
                placeholder="2500"
                min="0"
                step="100"
                disabled={dealType === 'percentage_only'}
                className="w-full pl-8 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-slate-100"
              />
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {dealType === 'flat_fee'
                ? 'Fixed amount you pay the artist'
                : 'Guaranteed minimum payment'}
            </p>
          </div>

          {dealType !== 'flat_fee' && dealType !== 'flat_guarantee' && dealType !== 'promoter_profit' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Artist Percentage</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={artistPercentage}
                  onChange={(e) => setArtistPercentage(Number(e.target.value))}
                  placeholder="100"
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
                <span className="text-slate-600 font-medium">%</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                % of net revenue after expenses
              </p>
            </div>
          )}
        </div>
      </div>

      {(netRevenue > 0 || guarantee > 0) && (
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200 rounded-lg p-6">
          <h3 className="text-xl font-bold mb-4">Deal Summary</h3>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-slate-700">Net Revenue (after costs):</span>
              <span className="font-bold text-lg">
                {formatCurrency(Math.max(0, netRevenue))}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-700">
                Artist {dealType === 'flat_fee' ? 'Flat Fee' : 'Payout'}:
              </span>
              <span className="font-bold text-lg text-green-600">
                {formatCurrency(Math.max(0, artistPayout))}
              </span>
            </div>

            <div className="border-t-2 border-purple-300 pt-3">
              <div className="flex justify-between items-center">
                <span className="text-xl font-bold">Your Profit:</span>
                <span className={`text-2xl font-bold ${promoterProfit >= 0 ? 'text-purple-600' : 'text-red-600'}`}>
                  {formatCurrency(promoterProfit)}
                </span>
              </div>
            </div>

            {dealType === 'guarantee_vs_percentage' && netRevenue > 0 && (
              <div className="mt-4 p-3 bg-white rounded-lg text-sm border border-slate-200">
                <div className="font-semibold mb-2">Artist Gets Higher Of:</div>
                <div className="flex justify-between">
                  <span>Guarantee:</span>
                  <span className="font-medium">{formatCurrency(guarantee)}</span>
                </div>
                <div className="flex justify-between">
                  <span>{artistPercentage}% of Net:</span>
                  <span className="font-medium">{formatCurrency(netRevenue * (artistPercentage / 100))}</span>
                </div>
                <div className="border-t border-slate-200 mt-2 pt-2 flex justify-between font-bold">
                  <span>Artist Receives:</span>
                  <span className="text-green-600">{formatCurrency(Math.max(guarantee, netRevenue * (artistPercentage / 100)))}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {(dealType === 'flat_guarantee' || dealType === 'promoter_profit') && (
        <div className="space-y-4">
          {dealType === 'promoter_profit' && (
            <div>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <p className="text-sm text-amber-800">
                  <span className="font-semibold">Backend Split:</span> After expenses and {promoterBackendPct}% promoter profit, artist receives {artistBackendPct}% of remaining revenue.
                </p>
              </div>

              <div className="bg-white border border-slate-300 rounded-lg p-4">
                <h3 className="font-semibold text-slate-900 mb-4">Customize Backend Split</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Artist Backend (%)
                    </label>
                    <input
                      type="number"
                      value={artistBackendPct}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        if (val >= 0 && val <= 100) {
                          setArtistBackendPct(val);
                          setPromoterBackendPct(100 - val);
                        }
                      }}
                      placeholder="85"
                      min="0"
                      max="100"
                      step="1"
                      className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Promoter Backend (%)
                    </label>
                    <input
                      type="number"
                      value={promoterBackendPct}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        if (val >= 0 && val <= 100) {
                          setPromoterBackendPct(val);
                          setArtistBackendPct(100 - val);
                        }
                      }}
                      placeholder="15"
                      min="0"
                      max="100"
                      step="1"
                      className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Total must equal 100%. Adjusting one will automatically update the other.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Tax Withholding (%)
          </label>
          <input
            type="number"
            value={taxWithholdingPct}
            onChange={(e) => {
              const val = e.target.value === '' ? 0 : Number(e.target.value);
              setTaxWithholdingPct(isNaN(val) ? 0 : val);
            }}
            placeholder="0"
            min="0"
            max="100"
            step="0.1"
            className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Deposit (%)
          </label>
          <input
            type="number"
            value={depositPct}
            onChange={(e) => {
              const val = e.target.value === '' ? 0 : Number(e.target.value);
              setDepositPct(isNaN(val) ? 0 : val);
            }}
            placeholder="0"
            min="0"
            max="100"
            step="1"
            className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {dealType === 'flat_fee' || dealType === 'flat_guarantee' && (
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Calculated Payout</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-slate-600">Guarantee</span>
              <span className="font-medium">{formatCurrency(guarantee)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Tax Withholding ({taxWithholdingPct}%)</span>
              <span className="font-medium text-red-600">-{formatCurrency(taxWithholding)}</span>
            </div>
            <div className="border-t border-slate-300 pt-3 flex justify-between">
              <span className="font-semibold text-slate-900">Total Potential Payout</span>
              <span className="font-semibold text-slate-900 text-lg">{formatCurrency(totalPayout)}</span>
            </div>
            <div className="border-t border-slate-200 pt-3 mt-3">
              <div className="flex justify-between">
                <span className="text-slate-600">Deposit Due (30 days before)</span>
                <span className="font-medium">{formatCurrency(depositAmount)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-lg p-6">
        <h3 className="text-xl font-bold text-slate-900 mb-4">Merchandise</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Soft Merch % (Artist Keeps)</label>
            <input
              type="number"
              value={merchRateSoft}
              onChange={(e) => setMerchRateSoft(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Hard Merch % (Artist Keeps)</label>
            <input
              type="number"
              value={merchRateHard}
              onChange={(e) => setMerchRateHard(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Support Acts</h3>
            <p className="text-sm text-slate-600 mt-1">Add opening acts, DJs, or special guests</p>
          </div>
          <button
            onClick={addSupportAct}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium"
          >
            <Plus className="h-4 w-4" />
            Add Support
          </button>
        </div>

        {supportActs.length === 0 ? (
          <div className="text-center py-12 text-slate-500 border-2 border-dashed border-slate-200 rounded-lg">
            <Music className="h-12 w-12 mx-auto mb-3 text-slate-400" />
            <p className="font-medium">No support acts added yet</p>
            <button
              onClick={addSupportAct}
              className="mt-3 text-purple-600 hover:text-purple-700 font-medium text-sm"
            >
              Add your first support act
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {supportActs.map((act, index) => (
              <div key={index} className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg">
                <div className="flex gap-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                      {index + 1}
                    </div>
                  </div>

                  <div className="flex-1 space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-sm font-semibold mb-1 text-slate-700">Artist/Act Name *</label>
                        <input
                          type="text"
                          value={act.name}
                          onChange={(e) => updateSupportAct(index, 'name', e.target.value)}
                          placeholder="e.g., DJ Nova, The Opening Band"
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold mb-1 text-slate-700">Type</label>
                        <select
                          value={act.type}
                          onChange={(e) => updateSupportAct(index, 'type', e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        >
                          <option value="dj">DJ</option>
                          <option value="band">Band</option>
                          <option value="artist">Solo Artist</option>
                          <option value="special_guest">Special Guest</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-sm font-semibold mb-1 text-slate-700">Guarantee ($)</label>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500">$</span>
                          <input
                            type="number"
                            value={act.guarantee || ''}
                            onChange={(e) => updateSupportAct(index, 'guarantee', parseFloat(e.target.value) || 0)}
                            placeholder="0"
                            min="0"
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-semibold mb-1 text-slate-700">Set Length (min)</label>
                        <input
                          type="number"
                          value={act.set_length || ''}
                          onChange={(e) => updateSupportAct(index, 'set_length', parseInt(e.target.value) || 0)}
                          placeholder="30"
                          min="0"
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold mb-1 text-slate-700">Genre</label>
                        <input
                          type="text"
                          value={act.genre || ''}
                          onChange={(e) => updateSupportAct(index, 'genre', e.target.value)}
                          placeholder="e.g., House, Rock"
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-1 text-slate-700">Notes</label>
                      <input
                        type="text"
                        value={act.notes || ''}
                        onChange={(e) => updateSupportAct(index, 'notes', e.target.value)}
                        placeholder="Special requirements, social media handles, etc."
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => moveSupportAct(index, 'up')}
                      disabled={index === 0}
                      className="p-2 hover:bg-white rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <ArrowUp className="h-4 w-4 text-slate-600" />
                    </button>
                    <button
                      onClick={() => moveSupportAct(index, 'down')}
                      disabled={index === supportActs.length - 1}
                      className="p-2 hover:bg-white rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <ArrowDown className="h-4 w-4 text-slate-600" />
                    </button>
                    <button
                      onClick={() => removeSupportAct(index)}
                      className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {totalSupportCost > 0 && (
              <div className="p-4 bg-purple-100 border border-purple-300 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-lg text-slate-900">Total Support Acts Cost:</span>
                  <span className="text-2xl font-bold text-purple-600">
                    {formatCurrency(totalSupportCost)}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
