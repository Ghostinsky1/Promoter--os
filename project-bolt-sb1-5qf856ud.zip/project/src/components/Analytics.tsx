import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { OfferWithShow } from '../types';
import { formatCurrency } from '../lib/calculations';
import { parseLocalDate } from '../lib/dateHelpers';
import {
  calculateBreakEven,
  calculateScenarios,
  calculateCapitalRequired,
  calculateRiskScore,
  getDaysUntilEvent,
  getConfidenceLevel,
  getRiskAngle
} from '../lib/breakEvenCalculations';
import { Target, AlertCircle, ArrowLeft, TrendingUp, DollarSign, Calendar, Users, Wallet } from 'lucide-react';

export function Analytics() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [offer, setOffer] = useState<OfferWithShow | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadOffer(id);
    }
  }, [id]);

  const loadOffer = async (offerId: string) => {
    try {
      const { data: offerData, error: offerError } = await supabase
        .from('offers')
        .select('*')
        .eq('id', offerId)
        .maybeSingle();

      if (offerError) throw offerError;
      if (!offerData) {
        navigate('/offers');
        return;
      }

      const { data: showData, error: showError } = await supabase
        .from('shows')
        .select('*')
        .eq('id', offerData.show_id)
        .maybeSingle();

      if (showError) throw showError;
      if (!showData) {
        navigate('/offers');
        return;
      }

      setOffer({
        ...offerData,
        show: showData,
      });
    } catch (error) {
      console.error('Error loading offer:', error);
      navigate('/offers');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading analytics...</div>
      </div>
    );
  }

  if (!offer) {
    return null;
  }

  const breakEven = calculateBreakEven(offer);
  const scenarios = calculateScenarios(offer);
  const capital = calculateCapitalRequired(offer);
  const riskScore = calculateRiskScore(offer);
  const daysUntil = getDaysUntilEvent(offer.show.event_date);
  const confidence = getConfidenceLevel(breakEven.percentage);

  const totalSellable = offer.ticket_tiers.reduce((sum, tier) => sum + (tier.allotment - tier.comps), 0);
  const artistTotal = offer.calculations.artistTotalPayout;
  const totalExpenses = offer.calculations.totalExpenses;
  const grossRevenue = offer.calculations.netGross;
  const netProfit = offer.calculations.netProfit;

  const expenseCategories = [
    { title: 'Talent', total: Object.values(offer.expenses.talent || {}).reduce((s, v) => s + v, 0), color: '#06b6d4' },
    { title: 'Production', total: Object.values(offer.expenses.production || {}).reduce((s, v) => s + v, 0), color: '#8b5cf6' },
    { title: 'Marketing', total: Object.values(offer.expenses.marketing || {}).reduce((s, v) => s + v, 0), color: '#f59e0b' },
    { title: 'General', total: Object.values(offer.expenses.general || {}).reduce((s, v) => s + v, 0), color: '#ec4899' },
  ].filter(cat => cat.total > 0);

  return (
    <div className="min-h-screen bg-black text-white p-3 sm:p-4">
      <div className="max-w-7xl mx-auto mb-4">
        <button
          onClick={() => navigate(`/offers/${id}`)}
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-3 transition-colors text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Offer
        </button>

        <div className="mb-4">
          <h1 className="text-2xl sm:text-3xl font-bold mb-1">{offer.show.artist_name}</h1>
          <p className="text-gray-400 text-sm">{offer.show.venue_name} • {(() => {
            const eventDate = parseLocalDate(offer.show.event_date);
            return eventDate ? eventDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Invalid date';
          })()}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

        {/* Key Metrics Overview */}
        <div className="lg:col-span-3 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
          <h2 className="text-lg font-bold mb-3">Event Overview</h2>

          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="bg-black/30 rounded-xl p-3 border border-cyan-500/20">
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 bg-cyan-500/20 rounded">
                  <DollarSign className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-[10px] text-gray-400 uppercase tracking-wide">Net Profit</div>
              </div>
              <div className="text-2xl font-bold text-cyan-400">
                {formatCurrency(netProfit / 1000)}K
              </div>
              <div className="text-[10px] text-gray-500">at 100% capacity</div>
            </div>

            <div className="bg-black/30 rounded-xl p-3 border border-purple-500/20">
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 bg-purple-500/20 rounded">
                  <Target className="w-4 h-4 text-purple-400" />
                </div>
                <div className="text-[10px] text-gray-400 uppercase tracking-wide">Break-Even</div>
              </div>
              <div className="text-2xl font-bold text-purple-400">
                {breakEven.percentage.toFixed(0)}%
              </div>
              <div className="text-[10px] text-gray-500">{breakEven.tickets} tickets</div>
            </div>

            <div className="bg-black/30 rounded-xl p-3 border border-orange-500/20">
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 bg-orange-500/20 rounded">
                  <Wallet className="w-4 h-4 text-orange-400" />
                </div>
                <div className="text-[10px] text-gray-400 uppercase tracking-wide">Capital</div>
              </div>
              <div className="text-2xl font-bold text-orange-400">
                {formatCurrency(capital.total / 1000)}K
              </div>
              <div className="text-[10px] text-gray-500">upfront needed</div>
            </div>

            <div className="bg-black/30 rounded-xl p-3 border border-pink-500/20">
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 bg-pink-500/20 rounded">
                  <Users className="w-4 h-4 text-pink-400" />
                </div>
                <div className="text-[10px] text-gray-400 uppercase tracking-wide">Capacity</div>
              </div>
              <div className="text-2xl font-bold text-pink-400">
                {totalSellable}
              </div>
              <div className="text-[10px] text-gray-500">sellable tickets</div>
            </div>

            <div className="bg-black/30 rounded-xl p-3 border border-blue-500/20">
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 bg-blue-500/20 rounded">
                  <Calendar className="w-4 h-4 text-blue-400" />
                </div>
                <div className="text-[10px] text-gray-400 uppercase tracking-wide">Days Until</div>
              </div>
              <div className="text-2xl font-bold text-blue-400">
                {daysUntil}
              </div>
              <div className="text-[10px] text-gray-500">{daysUntil === 1 ? 'day' : 'days'} away</div>
            </div>
          </div>
        </div>

        {/* Break-Even Widget */}
        <div className="lg:col-span-2 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
          <div className="flex items-center gap-2 mb-3">
            <div className="p-1.5 bg-purple-500/20 rounded">
              <Target className="h-5 w-5 text-purple-400" />
            </div>
            <h2 className="text-lg font-bold">Break-Even Analysis</h2>
          </div>

          <div className="flex items-center justify-center mb-4">
            <div className="relative w-48 h-48">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <circle
                  cx="100"
                  cy="100"
                  r="80"
                  fill="none"
                  stroke="#1f2937"
                  strokeWidth="20"
                />
                <circle
                  cx="100"
                  cy="100"
                  r="80"
                  fill="none"
                  stroke="url(#breakeven-gradient)"
                  strokeWidth="20"
                  strokeDasharray={`${(breakEven.tickets / totalSellable) * 502} 502`}
                  strokeLinecap="round"
                  transform="rotate(-90 100 100)"
                  className="transition-all duration-1000"
                />
                <defs>
                  <linearGradient id="breakeven-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#06b6d4" />
                  </linearGradient>
                </defs>
                <text x="100" y="95" textAnchor="middle" className="text-4xl font-bold fill-white">
                  {breakEven.tickets}
                </text>
                <text x="100" y="115" textAnchor="middle" className="text-xs fill-gray-400 uppercase tracking-wide">
                  Tickets
                </text>
              </svg>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-black/30 rounded-xl p-3 border border-purple-500/20">
              <div className="text-[10px] text-gray-400 mb-1 uppercase tracking-wide">Break-Even %</div>
              <div className="text-xl font-bold text-purple-400">
                {breakEven.percentage.toFixed(0)}%
              </div>
            </div>
            <div className="bg-black/30 rounded-xl p-3 border border-cyan-500/20">
              <div className="text-[10px] text-gray-400 mb-1 uppercase tracking-wide">Capacity</div>
              <div className="text-xl font-bold text-cyan-400">
                {totalSellable}
              </div>
            </div>
            <div className="bg-black/30 rounded-xl p-3 border border-pink-500/20">
              <div className="text-[10px] text-gray-400 mb-1 uppercase tracking-wide">Buffer</div>
              <div className="text-xl font-bold text-pink-400">
                {breakEven.buffer}
              </div>
            </div>
          </div>

          {breakEven.percentage > 70 && (
            <div className="mt-3 bg-orange-500/10 border border-orange-500/30 rounded-xl p-3 flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-orange-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-orange-200">
                High break-even point. Consider reducing costs or increasing ticket prices.
              </div>
            </div>
          )}
        </div>

        {/* Profit Forecast */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
          <div className="flex items-center gap-2 mb-3">
            <div className="p-1.5 bg-cyan-500/20 rounded">
              <TrendingUp className="h-5 w-5 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Profit Forecast</h2>
              <p className="text-gray-400 text-[10px]">At 100% capacity</p>
            </div>
          </div>

          <div className="text-center mb-4 py-4">
            <div className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 mb-2">
              {formatCurrency(netProfit / 1000)}K
            </div>
            <div className="text-[10px] text-gray-400 uppercase tracking-wide">Projected Net Profit</div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center p-2 bg-black/30 rounded-lg border border-cyan-500/20">
              <span className="text-gray-400 text-xs">Profit Margin</span>
              <span className="font-bold text-cyan-400 text-sm">
                {((netProfit / grossRevenue) * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between items-center p-2 bg-black/30 rounded-lg border border-purple-500/20">
              <span className="text-gray-400 text-xs">Confidence</span>
              <span className={`font-bold text-sm ${confidence.color}`}>
                {confidence.emoji} {confidence.text}
              </span>
            </div>
            <div className="flex justify-between items-center p-2 bg-black/30 rounded-lg border border-pink-500/20">
              <span className="text-gray-400 text-xs">Risk Score</span>
              <span className={`font-bold text-sm ${riskScore < 40 ? 'text-pink-400' : riskScore < 70 ? 'text-orange-400' : 'text-red-400'}`}>
                {riskScore.toFixed(0)}/100
              </span>
            </div>
          </div>
        </div>

        {/* Revenue Breakdown */}
        <div className="lg:col-span-3 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
          <h2 className="text-lg font-bold mb-3">Revenue Split</h2>

          <div className="grid lg:grid-cols-2 gap-6">
            <div className="flex items-center justify-center">
              <div className="relative w-48 h-48">
                <svg viewBox="0 0 200 200" className="w-full h-full transform -rotate-90">
                  <circle
                    cx="100"
                    cy="100"
                    r="70"
                    fill="none"
                    stroke="#8b5cf6"
                    strokeWidth="40"
                    strokeDasharray={`${(artistTotal / grossRevenue) * 440} 440`}
                  />
                  <circle
                    cx="100"
                    cy="100"
                    r="70"
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="40"
                    strokeDasharray={`${(totalExpenses / grossRevenue) * 440} 440`}
                    strokeDashoffset={`-${(artistTotal / grossRevenue) * 440}`}
                  />
                  <circle
                    cx="100"
                    cy="100"
                    r="70"
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="40"
                    strokeDasharray={`${(netProfit / grossRevenue) * 440} 440`}
                    strokeDashoffset={`-${((artistTotal + totalExpenses) / grossRevenue) * 440}`}
                  />
                  <circle cx="100" cy="100" r="50" fill="#000" />
                </svg>

                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-white">
                      {formatCurrency(grossRevenue / 1000)}K
                    </div>
                    <div className="text-xs text-gray-400 uppercase tracking-wide">Total</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-center space-y-3">
              <div className="flex items-center justify-between p-3 bg-black/30 rounded-xl border border-purple-500/20">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full bg-purple-500"></div>
                  <span className="text-white font-medium">Artist Payout</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-purple-400">
                    {formatCurrency(artistTotal / 1000)}K
                  </div>
                  <div className="text-[10px] text-gray-500">
                    {((artistTotal / grossRevenue) * 100).toFixed(1)}%
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-black/30 rounded-xl border border-orange-500/20">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full bg-orange-500"></div>
                  <span className="text-white font-medium">Total Expenses</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-orange-400">
                    {formatCurrency(totalExpenses / 1000)}K
                  </div>
                  <div className="text-[10px] text-gray-500">
                    {((totalExpenses / grossRevenue) * 100).toFixed(1)}%
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-black/30 rounded-xl border border-cyan-500/20">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full bg-cyan-500"></div>
                  <span className="text-white font-medium">Net Profit</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-cyan-400">
                    {formatCurrency(netProfit / 1000)}K
                  </div>
                  <div className="text-[10px] text-gray-500">
                    {((netProfit / grossRevenue) * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sell-Through Scenarios */}
        <div className="lg:col-span-3 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
          <h2 className="text-lg font-bold mb-3">Sell-Through Scenarios</h2>

          <div className="mb-4 overflow-x-auto">
            <div className="min-w-[600px]">
              <svg viewBox="0 0 600 200" className="w-full" style={{ height: '180px' }}>
                {[0, 25, 50, 75, 100].map((value, i) => (
                  <g key={i}>
                    <line
                      x1="60"
                      y1={165 - (value * 1.3)}
                      x2="580"
                      y2={165 - (value * 1.3)}
                      stroke="#374151"
                      strokeWidth="1"
                      strokeDasharray="4"
                    />
                    <text
                      x="50"
                      y={169 - (value * 1.3)}
                      textAnchor="end"
                      className="text-[10px] fill-gray-500"
                    >
                      {value}%
                    </text>
                  </g>
                ))}

                {scenarios.map((scenario, index) => {
                  const colors = ['#ef4444', '#f59e0b', '#8b5cf6', '#06b6d4'];
                  const xPos = 100 + (index * 120);
                  const height = scenario.percentage * 1.3;
                  const yPos = 165 - height;

                  return (
                    <g key={index}>
                      <rect
                        x={xPos}
                        y={yPos}
                        width="80"
                        height={height}
                        fill={colors[index]}
                        opacity="0.8"
                        rx="8"
                      />
                      <text
                        x={xPos + 40}
                        y="185"
                        textAnchor="middle"
                        className="text-xs fill-white font-bold"
                      >
                        {scenario.percentage}%
                      </text>
                      <text
                        x={xPos + 40}
                        y={Math.max(yPos - 6, 20)}
                        textAnchor="middle"
                        className="text-[10px] fill-white font-bold"
                      >
                        {formatCurrency(scenario.profit / 1000)}K
                      </text>
                    </g>
                  );
                })}

                <line
                  x1="60"
                  y1={165 - (breakEven.percentage * 1.3)}
                  x2="580"
                  y2={165 - (breakEven.percentage * 1.3)}
                  stroke="#f59e0b"
                  strokeWidth="2"
                  strokeDasharray="8"
                />
                <text
                  x="585"
                  y={169 - (breakEven.percentage * 1.3)}
                  className="text-[10px] fill-orange-400 font-bold"
                >
                  BE
                </text>
              </svg>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {scenarios.map((scenario, i) => {
              const colors = ['border-red-500/20 text-red-400', 'border-orange-500/20 text-orange-400', 'border-purple-500/20 text-purple-400', 'border-cyan-500/20 text-cyan-400'];
              return (
                <div key={i} className={`bg-black/30 rounded-xl p-3 border ${colors[i]}`}>
                  <div className="text-[10px] text-gray-400 mb-1 uppercase tracking-wide">{scenario.percentage}% SOLD</div>
                  <div className="text-lg font-bold mb-1 text-white">{scenario.tickets}</div>
                  <div className={`text-xs font-bold ${scenario.isProfit ? 'text-cyan-400' : 'text-red-400'}`}>
                    {formatCurrency(scenario.profit / 1000)}K
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Capital Required */}
        <div className="lg:col-span-2 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
          <div className="flex items-center gap-2 mb-3">
            <div className="p-1.5 bg-orange-500/20 rounded">
              <Wallet className="h-5 w-5 text-orange-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Capital Required</h2>
              <p className="text-gray-400 text-[10px]">Upfront investment</p>
            </div>
          </div>

          <div className="text-center mb-4 py-3">
            <div className="text-3xl sm:text-4xl font-bold text-orange-400 mb-1">
              {formatCurrency(capital.total / 1000)}K
            </div>
            <div className="text-[10px] text-gray-400 uppercase tracking-wide">Total Needed</div>
          </div>

          <div className="space-y-2">
            <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-3">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-gray-300 font-medium">Artist Deposit</span>
                <span className="font-bold text-purple-400">
                  {formatCurrency(capital.artistDeposit)}
                </span>
              </div>
              {offer.deposit_due_date && (
                <div className="text-[10px] text-gray-400">
                  Due: {new Date(offer.deposit_due_date).toLocaleDateString()}
                </div>
              )}
            </div>

            {capital.venueDeposit > 0 && (
              <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-3">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-gray-300 font-medium">Venue Deposit</span>
                  <span className="font-bold text-cyan-400">
                    {formatCurrency(capital.venueDeposit)}
                  </span>
                </div>
                {offer.venue_deposit_due_date && (
                  <div className="text-[10px] text-gray-400">
                    Due: {new Date(offer.venue_deposit_due_date).toLocaleDateString()}
                  </div>
                )}
              </div>
            )}

            {capital.marketing > 0 && (
              <div className="bg-pink-500/10 border border-pink-500/30 rounded-xl p-3">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-gray-300 font-medium">Marketing Budget</span>
                  <span className="font-bold text-pink-400">
                    {formatCurrency(capital.marketing)}
                  </span>
                </div>
                <div className="text-[10px] text-gray-400">Ongoing campaign</div>
              </div>
            )}
          </div>
        </div>

        {/* Risk Assessment */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
          <h2 className="text-lg font-bold mb-3">Risk Gauge</h2>

          <div className="flex items-center justify-center mb-4">
            <div className="relative w-full max-w-xs">
              <svg viewBox="0 0 200 120" className="w-full" style={{ height: '120px' }}>
                <defs>
                  <linearGradient id="gauge-gradient-cyan" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#06b6d4" />
                    <stop offset="100%" stopColor="#0891b2" />
                  </linearGradient>
                  <linearGradient id="gauge-gradient-purple" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#7c3aed" />
                  </linearGradient>
                  <linearGradient id="gauge-gradient-orange" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#f59e0b" />
                    <stop offset="100%" stopColor="#ea580c" />
                  </linearGradient>
                  <linearGradient id="gauge-gradient-red" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#ef4444" />
                    <stop offset="100%" stopColor="#dc2626" />
                  </linearGradient>
                </defs>

                <path
                  d="M 20 100 A 80 80 0 0 1 180 100"
                  fill="none"
                  stroke="#1f2937"
                  strokeWidth="20"
                  strokeLinecap="round"
                />

                <path
                  d="M 20 100 A 80 80 0 0 1 60 44"
                  fill="none"
                  stroke="url(#gauge-gradient-cyan)"
                  strokeWidth="20"
                  strokeLinecap="round"
                />
                <path
                  d="M 60 44 A 80 80 0 0 1 100 20"
                  fill="none"
                  stroke="url(#gauge-gradient-purple)"
                  strokeWidth="20"
                  strokeLinecap="round"
                />
                <path
                  d="M 100 20 A 80 80 0 0 1 140 44"
                  fill="none"
                  stroke="url(#gauge-gradient-orange)"
                  strokeWidth="20"
                  strokeLinecap="round"
                />
                <path
                  d="M 140 44 A 80 80 0 0 1 180 100"
                  fill="none"
                  stroke="url(#gauge-gradient-red)"
                  strokeWidth="20"
                  strokeLinecap="round"
                />

                <line
                  x1="100"
                  y1="100"
                  x2={100 + Math.cos(getRiskAngle(riskScore)) * 70}
                  y2={100 + Math.sin(getRiskAngle(riskScore)) * 70}
                  stroke="white"
                  strokeWidth="3"
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
                <circle cx="100" cy="100" r="6" fill="white" />
              </svg>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="text-center p-2 bg-black/30 rounded-xl border border-cyan-500/20">
              <div className="text-xl font-bold text-cyan-400">
                {((breakEven.buffer / totalSellable) * 100).toFixed(0)}%
              </div>
              <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-wide">Buffer</div>
            </div>
            <div className="text-center p-2 bg-black/30 rounded-xl border border-purple-500/20">
              <div className="text-xl font-bold text-purple-400">
                {daysUntil}
              </div>
              <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-wide">Days</div>
            </div>
            <div className="text-center p-2 bg-black/30 rounded-xl border border-pink-500/20">
              <div className={`text-xl font-bold ${
                (capital.marketing / totalExpenses * 100) >= 15 ? 'text-pink-400' : 'text-orange-400'
              }`}>
                {(capital.marketing / totalExpenses * 100).toFixed(0)}%
              </div>
              <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-wide">Marketing</div>
            </div>
          </div>
        </div>

        {/* Expense Breakdown */}
        {expenseCategories.length > 0 && (
          <div className="lg:col-span-3 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-4 shadow-2xl border border-gray-700">
            <h2 className="text-lg font-bold mb-3">Expense Breakdown</h2>

            <div className="grid md:grid-cols-2 gap-4">
              {expenseCategories.map((category, index) => {
                const percentage = (category.total / totalExpenses) * 100;

                return (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-white text-sm">{category.title}</span>
                      <span className="font-bold text-white">
                        {formatCurrency(category.total / 1000)}K
                      </span>
                    </div>
                    <div className="w-full h-3 bg-gray-800 rounded-full overflow-hidden border border-gray-700">
                      <div
                        className="h-full rounded-full transition-all duration-1000"
                        style={{
                          width: `${percentage}%`,
                          backgroundColor: category.color
                        }}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] text-gray-400">
                      <span>{percentage.toFixed(1)}% of total</span>
                      <span>{formatCurrency(category.total)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>

      <div className="max-w-7xl mx-auto mt-4">
        <button
          onClick={() => navigate(`/offers/${id}`)}
          className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white py-4 rounded-xl font-bold transition-all shadow-lg"
        >
          BACK TO OFFER
        </button>
      </div>
    </div>
  );
}
