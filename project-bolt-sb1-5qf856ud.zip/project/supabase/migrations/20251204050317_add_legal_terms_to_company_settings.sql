/*
  # Add Legal Terms to Company Settings

  1. Changes
    - Add `legal_terms` column to `company_settings` table for storing contract terms and rules
    - This will be displayed on all PDFs (offers, run of show, settlements)

  2. Security
    - No changes to RLS policies needed
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'company_settings' AND column_name = 'legal_terms'
  ) THEN
    ALTER TABLE company_settings ADD COLUMN legal_terms text;
  END IF;
END $$;