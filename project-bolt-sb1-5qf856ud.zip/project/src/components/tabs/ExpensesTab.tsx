import { Expenses } from '../../types';
import { calculateCategoryTotal, formatCurrency } from '../../lib/calculations';

interface ExpensesTabProps {
  expenses: Expenses;
  setExpenses: (expenses: Expenses) => void;
  ascapRate?: number;
  setAscapRate?: (value: number) => void;
  bmiRate?: number;
  setBmiRate?: (value: number) => void;
  sesacRate?: number;
  setSesacRate?: (value: number) => void;
  insurancePerAttendee?: number;
  setInsurancePerAttendee?: (value: number) => void;
  ccFeeRate?: number;
  setCcFeeRate?: (value: number) => void;
}

export function ExpensesTab({
  expenses,
  setExpenses,
  ascapRate = 0.0023,
  setAscapRate = () => {},
  bmiRate = 0.003,
  setBmiRate = () => {},
  sesacRate = 0.000214,
  setSesacRate = () => {},
  insurancePerAttendee = 0.62,
  setInsurancePerAttendee = () => {},
  ccFeeRate = 0.012,
  setCcFeeRate = () => {},
}: ExpensesTabProps) {
  const updateExpense = (category: keyof Expenses, field: string, value: number) => {
    setExpenses({
      ...expenses,
      [category]: {
        ...expenses[category],
        [field]: value,
      },
    });
  };

  const addExpenseItem = (category: keyof Expenses) => {
    const itemName = prompt(`Enter expense item name for ${category}:`);
    if (itemName) {
      setExpenses({
        ...expenses,
        [category]: {
          ...expenses[category],
          [itemName.toLowerCase().replace(/\s+/g, '_')]: 0,
        },
      });
    }
  };

  const removeExpenseItem = (category: keyof Expenses, field: string) => {
    const updated = { ...expenses[category] };
    delete updated[field];
    setExpenses({
      ...expenses,
      [category]: updated,
    });
  };

  const totalExpenses = Object.values(expenses).reduce(
    (sum, category) => sum + calculateCategoryTotal(category),
    0
  );

  const renderCategory = (
    title: string,
    category: keyof Expenses,
    color: string
  ) => {
    const categoryTotal = calculateCategoryTotal(expenses[category]);

    return (
      <div className={`border ${color} rounded-lg p-5`}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-semibold text-slate-900">{title}</h3>
          <span className="font-semibold text-lg">{formatCurrency(categoryTotal)}</span>
        </div>

        <div className="space-y-3">
          {Object.entries(expenses[category]).map(([field, value]) => (
            <div key={field} className="flex items-center gap-3">
              <div className="flex-1">
                <label className="block text-sm text-slate-600 mb-1 capitalize">
                  {field.replace(/_/g, ' ')}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
                  <input
                    type="number"
                    value={value || ''}
                    onChange={(e) => updateExpense(category, field, Number(e.target.value))}
                    placeholder="0.00"
                    min="0"
                    step="0.01"
                    className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              <button
                onClick={() => removeExpenseItem(category, field)}
                className="mt-6 px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors text-sm"
              >
                Remove
              </button>
            </div>
          ))}
        </div>

        <button
          onClick={() => addExpenseItem(category)}
          className="mt-4 w-full py-2 border border-dashed border-slate-300 rounded-lg text-slate-600 hover:border-blue-500 hover:text-blue-600 transition-colors text-sm"
        >
          + Add Item
        </button>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900 mb-4">Expense Breakdown</h2>
        <p className="text-slate-600 mb-6">Manage all show expenses by category</p>
      </div>

      <div className="bg-white border border-slate-200 rounded-lg p-6 mb-6">
        <h3 className="text-xl font-bold text-slate-900 mb-4">Variable Expenses</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">ASCAP (%)</label>
            <input
              type="number"
              step="0.01"
              value={(ascapRate * 100).toFixed(3)}
              onChange={(e) => setAscapRate(parseFloat(e.target.value) / 100)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <p className="text-xs text-slate-500 mt-1">Standard: 0.23%</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">BMI (%)</label>
            <input
              type="number"
              step="0.01"
              value={(bmiRate * 100).toFixed(3)}
              onChange={(e) => setBmiRate(parseFloat(e.target.value) / 100)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <p className="text-xs text-slate-500 mt-1">Standard: 0.30%</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">SESAC (%)</label>
            <input
              type="number"
              step="0.001"
              value={(sesacRate * 100).toFixed(4)}
              onChange={(e) => setSesacRate(parseFloat(e.target.value) / 100)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <p className="text-xs text-slate-500 mt-1">Standard: 0.0214%</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">CC Fee (%)</label>
            <input
              type="number"
              step="0.1"
              value={(ccFeeRate * 100).toFixed(2)}
              onChange={(e) => setCcFeeRate(parseFloat(e.target.value) / 100)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <p className="text-xs text-slate-500 mt-1">Standard: 1.2%</p>
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-2">Insurance Per Attendee ($)</label>
            <input
              type="number"
              step="0.01"
              value={insurancePerAttendee}
              onChange={(e) => setInsurancePerAttendee(parseFloat(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <p className="text-xs text-slate-500 mt-1">Standard: $0.50-$0.75</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {renderCategory('Talent Expenses', 'talent', 'border-purple-200 bg-purple-50')}
        {renderCategory('General Expenses', 'general', 'border-blue-200 bg-blue-50')}
        {renderCategory('Marketing Expenses', 'marketing', 'border-green-200 bg-green-50')}
        {renderCategory('Production Expenses', 'production', 'border-orange-200 bg-orange-50')}
      </div>

      <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
        <div className="flex justify-between items-center">
          <span className="text-lg font-semibold text-slate-900">Total Expenses</span>
          <span className="text-2xl font-bold text-slate-900">{formatCurrency(totalExpenses)}</span>
        </div>
      </div>
    </div>
  );
}
