import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Template } from '../types';
import { Plus, Copy, Edit, Trash2, FileText, DollarSign, FileCheck } from 'lucide-react';
import { CreateTemplateModal } from './CreateTemplateModal';

export function Templates() {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      console.log('🔍 Loading templates...');

      const { data: { user }, error: authError } = await supabase.auth.getUser();

      if (authError) {
        console.error('❌ Auth error:', authError);
        throw authError;
      }

      if (!user) {
        console.log('⚠️ No user logged in');
        setTemplates([]);
        setLoading(false);
        return;
      }

      console.log('✅ User authenticated:', user.id);

      const { data, error } = await supabase
        .from('templates')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('❌ Templates error:', error);
        throw error;
      }

      console.log('📊 Templates loaded:', data?.length || 0);
      setTemplates(data || []);
    } catch (error) {
      console.error('❌ Error loading templates:', error);
      setTemplates([]);
    } finally {
      setLoading(false);
    }
  };

  const deleteTemplate = async (id: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;

    try {
      const { error } = await supabase
        .from('templates')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setTemplates(templates.filter(t => t.id !== id));
    } catch (error) {
      console.error('Error deleting template:', error);
      alert('Failed to delete template');
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'venue': return <FileText className="h-7 w-7 text-blue-600" />;
      case 'artist': return <DollarSign className="h-7 w-7 text-purple-600" />;
      case 'event': return <FileCheck className="h-7 w-7 text-green-600" />;
      default: return <FileText className="h-7 w-7 text-gray-600" />;
    }
  };

  const getTypeBgColor = (type: string) => {
    switch (type) {
      case 'venue': return 'bg-blue-100';
      case 'artist': return 'bg-purple-100';
      case 'event': return 'bg-green-100';
      default: return 'bg-gray-100';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">Loading templates...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Offer Templates</h1>
              <p className="text-slate-600 mt-1">Save and reuse offer configurations</p>
            </div>
            <button
              onClick={() => setIsCreating(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors"
            >
              <Plus className="h-5 w-5" />
              Create Template
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {templates.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-12 text-center">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="h-10 w-10 text-slate-400" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">No Templates Yet</h3>
            <p className="text-slate-600 mb-6">
              Create your first template to quickly set up future offers
            </p>
            <button
              onClick={() => setIsCreating(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors"
            >
              <Plus className="h-5 w-5" />
              Create Template
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 hover:shadow-lg transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${getTypeBgColor(template.type)}`}>
                    {getTypeIcon(template.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-bold text-slate-900 mb-1 truncate">{template.name}</h3>
                    <p className="text-sm text-slate-500 line-clamp-2">
                      {template.description || 'No description'}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-slate-50 rounded-lg p-3">
                    <div className="text-xs text-slate-500 mb-1">Deal Type</div>
                    <div className="font-semibold text-sm text-slate-900">
                      {template.deal_type === 'flat_guarantee' ? 'Flat' : 'Profit Deal'}
                    </div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-3">
                    <div className="text-xs text-slate-500 mb-1">Expenses</div>
                    <div className="font-semibold text-sm text-slate-900">
                      {template.expense_categories?.length || 0} categories
                    </div>
                  </div>
                </div>

                <div className="space-y-2 text-sm mb-4">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Deposit:</span>
                    <span className="font-semibold text-slate-900">{template.deposit_pct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Tax Withholding:</span>
                    <span className="font-semibold text-slate-900">{template.tax_withholding_pct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Ticket Tiers:</span>
                    <span className="font-semibold text-slate-900">{template.ticket_tier_templates?.length || 0}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => navigate('/offers/create', { state: { template } })}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 text-slate-900 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors"
                  >
                    <Copy className="h-4 w-4" />
                    Use
                  </button>
                  <button
                    onClick={() => setEditingTemplate(template)}
                    className="flex items-center justify-center px-3 py-2 bg-slate-100 text-slate-900 rounded-lg hover:bg-slate-200 transition-colors"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => deleteTemplate(template.id)}
                    className="flex items-center justify-center px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {(isCreating || editingTemplate) && (
        <CreateTemplateModal
          existingTemplate={editingTemplate}
          onClose={() => {
            setIsCreating(false);
            setEditingTemplate(null);
          }}
          onSave={(template) => {
            if (editingTemplate) {
              setTemplates(templates.map(t => t.id === template.id ? template : t));
            } else {
              setTemplates([template, ...templates]);
            }
            setIsCreating(false);
            setEditingTemplate(null);
          }}
        />
      )}
    </div>
  );
}
