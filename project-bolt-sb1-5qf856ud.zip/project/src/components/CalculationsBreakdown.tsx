import { Calculations, TicketTier } from '../types';
import { formatCurrency } from '../lib/calculations';
import { CheckCircle2 } from 'lucide-react';

interface CalculationsBreakdownProps {
  ticketTiers: TicketTier[];
  salesTaxPct: number;
  calculations: Calculations;
  guarantee: number;
  mode: 'estimate' | 'settlement';
}

export function CalculationsBreakdown({
  ticketTiers,
  salesTaxPct,
  calculations,
  guarantee,
  mode,
}: CalculationsBreakdownProps) {
  const steps = [];

  steps.push({
    label: 'Gross Revenue (All Ticket Tiers)',
    value: calculations.grossPotential,
    isPositive: true,
    details: ticketTiers.map((tier) => {
      const tickets = mode === 'settlement' && tier.actualSold !== undefined
        ? tier.actualSold
        : (tier.allotment - tier.comps);
      return `${tier.type}: ${tickets} × ${formatCurrency(tier.price)} = ${formatCurrency(tickets * tier.price)}`;
    }),
  });

  steps.push({
    label: `Sales Tax (${salesTaxPct}%)`,
    value: -calculations.salesTax,
    isPositive: false,
    details: [`${salesTaxPct}% of ${formatCurrency(calculations.grossPotential)}`],
  });

  steps.push({
    label: 'Net Gross Revenue',
    value: calculations.netGross,
    isSubtotal: true,
    details: [`${formatCurrency(calculations.grossPotential)} - ${formatCurrency(calculations.salesTax)}`],
  });

  steps.push({
    label: 'Artist Guarantee',
    value: -guarantee,
    isPositive: false,
    details: [`Fixed artist payment`],
  });

  steps.push({
    label: 'Total Expenses',
    value: -calculations.totalExpenses,
    isPositive: false,
    details: [`All show expenses (Talent, General, Marketing, Production)`],
  });

  steps.push({
    label: 'NET PROFIT',
    value: calculations.netProfit,
    isFinal: true,
    details: [
      `${formatCurrency(calculations.netGross)} (Net Gross)`,
      `- ${formatCurrency(guarantee)} (Guarantee)`,
      `- ${formatCurrency(calculations.totalExpenses)} (Expenses)`,
    ],
  });

  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
      <div className="flex items-center gap-2 mb-3">
        <CheckCircle2 className="w-5 h-5 text-green-600" />
        <h2 className="text-base font-bold text-slate-900">Verified Calculations</h2>
      </div>

      <div className="space-y-2">
        {steps.map((step, index) => (
          <div key={index}>
            <div className={`flex justify-between items-start p-3 rounded-lg ${
              step.isFinal
                ? step.value >= 0
                  ? 'bg-green-50 border-2 border-green-500'
                  : 'bg-red-50 border-2 border-red-500'
                : step.isSubtotal
                ? 'bg-blue-50'
                : 'bg-slate-50'
            }`}>
              <div className="flex-1">
                <div className={`font-semibold ${
                  step.isFinal
                    ? 'text-base'
                    : step.isSubtotal
                    ? 'text-sm'
                    : 'text-xs'
                } ${
                  step.isFinal
                    ? step.value >= 0
                      ? 'text-green-900'
                      : 'text-red-900'
                    : 'text-slate-900'
                }`}>
                  {step.label}
                </div>
                {step.details && step.details.length > 0 && (
                  <div className="mt-1 space-y-0.5">
                    {step.details.map((detail, i) => (
                      <div key={i} className="text-[10px] text-slate-600">
                        {detail}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className={`font-bold text-right ml-4 ${
                step.isFinal
                  ? step.value >= 0
                    ? 'text-green-600 text-lg'
                    : 'text-red-600 text-lg'
                  : step.isSubtotal
                  ? 'text-blue-600 text-sm'
                  : step.isPositive
                  ? 'text-green-600 text-xs'
                  : 'text-red-600 text-xs'
              }`}>
                {step.value >= 0 ? '+' : ''}{formatCurrency(step.value)}
              </div>
            </div>

            {!step.isFinal && (
              <div className="flex justify-center my-1">
                <div className="w-px h-3 bg-slate-300" />
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 p-3 bg-slate-50 rounded-lg">
        <div className="text-xs text-slate-600 mb-1">Formula Verification</div>
        <div className="text-[10px] font-mono text-slate-700 space-y-0.5">
          <div>Net Gross = Gross Revenue - Sales Tax</div>
          <div>Net Profit = Net Gross - Artist Guarantee - Total Expenses</div>
        </div>
      </div>
    </div>
  );
}
