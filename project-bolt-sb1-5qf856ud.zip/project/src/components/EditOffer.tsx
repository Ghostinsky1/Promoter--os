import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { TicketTier, Expenses, OfferStatus, SupportAct } from '../types';
import { calculateOffer } from '../lib/calculations';
import { toLocalDateString } from '../lib/dateHelpers';
import { EventDetailsTab } from './tabs/EventDetailsTab';
import { ArtistDealTab } from './tabs/ArtistDealTab';
import { DepositsTab } from './tabs/DepositsTab';
import { TicketScalingTab } from './tabs/TicketScalingTab';
import { ExpensesTab } from './tabs/ExpensesTab';
import { SummaryTab } from './tabs/SummaryTab';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';

interface ArtistDeduction {
  name: string;
  amount: number;
}

export function EditOffer() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const [showId, setShowId] = useState('');
  const [eventName, setEventName] = useState('');
  const [artistName, setArtistName] = useState('');
  const [venueName, setVenueName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [capacity, setCapacity] = useState<number>(0);
  const [mode, setMode] = useState<'estimate' | 'settlement'>('estimate');
  const [status, setStatus] = useState<OfferStatus>('planning');
  const [venueStreet, setVenueStreet] = useState('');
  const [venueCity, setVenueCity] = useState('');
  const [venueState, setVenueState] = useState('');
  const [venueZip, setVenueZip] = useState('');

  const [facilityFeePerTicket, setFacilityFeePerTicket] = useState<number>(2.00);
  const [ageLimit, setAgeLimit] = useState<string>('All Ages');
  const [doorsTime, setDoorsTime] = useState<string>('20:00');
  const [doorsDuration, setDoorsDuration] = useState<number>(60);
  const [showTime, setShowTime] = useState<string>('21:00');
  const [showDuration, setShowDuration] = useState<number>(240);
  const [curfewTime, setCurfewTime] = useState<string>('01:00');

  const [dealType, setDealType] = useState<string>('flat_fee');
  const [guarantee, setGuarantee] = useState<number>(0);
  const [artistPercentage, setArtistPercentage] = useState<number>(100);
  const [taxWithholdingPct, setTaxWithholdingPct] = useState<number>(2);
  const [depositPct, setDepositPct] = useState<number>(20);
  const [artistBackendPct, setArtistBackendPct] = useState<number>(85);
  const [promoterBackendPct, setPromoterBackendPct] = useState<number>(15);
  const [depositDueTiming, setDepositDueTiming] = useState<string>('30_days_before');
  const [customDepositDate, setCustomDepositDate] = useState<string>('');
  const [artistDepositStatus, setArtistDepositStatus] = useState<string>('pending');
  const [venueDeposit, setVenueDeposit] = useState<number>(0);
  const [venueDepositDueDate, setVenueDepositDueDate] = useState<string>('');
  const [venueDepositStatus, setVenueDepositStatus] = useState<string>('pending');
  const [supportActs, setSupportActs] = useState<SupportAct[]>([]);

  const [merchRateSoft, setMerchRateSoft] = useState<number>(100);
  const [merchRateHard, setMerchRateHard] = useState<number>(100);
  const [artistDeductions, setArtistDeductions] = useState<ArtistDeduction[]>([]);

  const [ticketTiers, setTicketTiers] = useState<TicketTier[]>([
    { type: 'GA', allotment: 0, comps: 0, price: 0 }
  ]);
  const [salesTaxPct, setSalesTaxPct] = useState<number>(13.18);
  const [compsArtist, setCompsArtist] = useState<number>(0);
  const [compsVenue, setCompsVenue] = useState<number>(0);
  const [compsPromoter, setCompsPromoter] = useState<number>(0);

  const [expenses, setExpenses] = useState<Expenses>({
    talent: { rider_hospitality: 0 },
    general: { security: 0, emt: 0, gate_staff: 0 },
    marketing: { radio: 0, marketing: 0, paid_social: 0 },
    production: { production: 0, crew_stagehands: 0, camera_operator: 0, technical_director: 0 }
  });

  const [ascapRate, setAscapRate] = useState<number>(0.0023);
  const [bmiRate, setBmiRate] = useState<number>(0.003);
  const [sesacRate, setSesacRate] = useState<number>(0.000214);
  const [insurancePerAttendee, setInsurancePerAttendee] = useState<number>(0.62);
  const [ccFeeRate, setCcFeeRate] = useState<number>(0.012);

  useEffect(() => {
    if (id) {
      loadOffer(id);
    }
  }, [id]);

  const loadOffer = async (offerId: string) => {
    try {
      const { data: offerData, error: offerError } = await supabase
        .from('offers')
        .select('*')
        .eq('id', offerId)
        .maybeSingle();

      if (offerError) throw offerError;
      if (!offerData) {
        navigate('/offers');
        return;
      }

      const { data: showData, error: showError } = await supabase
        .from('shows')
        .select('*')
        .eq('id', offerData.show_id)
        .maybeSingle();

      if (showError) throw showError;
      if (!showData) {
        navigate('/offers');
        return;
      }

      console.log('Loading offer data:', { showData, offerData });

      setShowId(showData.id);
      setEventName(showData.event_name || '');
      setArtistName(showData.artist_name || '');
      setVenueName(showData.venue_name || '');
      setEventDate(toLocalDateString(showData.event_date) || '');
      setCapacity(showData.capacity || 0);
      setMode(offerData.mode || 'estimate');
      setStatus(offerData.status || 'planning');
      setVenueStreet(offerData.venue_street || '');
      setVenueCity(offerData.venue_city || '');
      setVenueState(offerData.venue_state || '');
      setVenueZip(offerData.venue_zip || '');
      setFacilityFeePerTicket(offerData.facility_fee_per_ticket || 2.00);
      setAgeLimit(offerData.age_limit || 'All Ages');
      setDoorsTime(offerData.doors_time || '20:00');
      setDoorsDuration(offerData.doors_duration || 60);
      setShowTime(offerData.show_time || '21:00');
      setShowDuration(offerData.show_duration || 240);
      setCurfewTime(offerData.curfew_time || '01:00');
      setDealType(offerData.deal_type || 'flat_fee');
      setGuarantee(offerData.guarantee || 0);
      setArtistPercentage(offerData.artist_percentage || 100);
      setTaxWithholdingPct(offerData.tax_withholding_pct || 2);
      setDepositPct(offerData.deposit_pct || 20);
      setArtistBackendPct(offerData.artist_backend_pct || 85);
      setPromoterBackendPct(offerData.promoter_backend_pct || 15);
      setDepositDueTiming(offerData.deposit_due_timing || '30_days_before');
      setCustomDepositDate(toLocalDateString(offerData.deposit_due_date) || '');
      setArtistDepositStatus(offerData.artist_deposit_status || 'pending');
      setVenueDeposit(offerData.venue_deposit || 0);
      setVenueDepositDueDate(toLocalDateString(offerData.venue_deposit_due_date) || '');
      setVenueDepositStatus(offerData.venue_deposit_status || 'pending');
      setMerchRateSoft(offerData.merch_rate_soft || 100);
      setMerchRateHard(offerData.merch_rate_hard || 100);
      setArtistDeductions(offerData.artist_deductions || []);
      setTicketTiers(offerData.ticket_tiers || [{ type: 'GA', allotment: 0, comps: 0, price: 0 }]);
      setSalesTaxPct(offerData.sales_tax_pct || 13.18);
      setCompsArtist(offerData.comps_artist || 0);
      setCompsVenue(offerData.comps_venue || 0);
      setCompsPromoter(offerData.comps_promoter || 0);
      setExpenses(offerData.expenses || {
        talent: { rider_hospitality: 0 },
        general: { security: 0, emt: 0, gate_staff: 0 },
        marketing: { radio: 0, marketing: 0, paid_social: 0 },
        production: { production: 0, crew_stagehands: 0, camera_operator: 0, technical_director: 0 }
      });
      setAscapRate(offerData.ascap_rate || 0.0023);
      setBmiRate(offerData.bmi_rate || 0.003);
      setSesacRate(offerData.sesac_rate || 0.000214);
      setInsurancePerAttendee(offerData.insurance_per_attendee || 0.62);
      setCcFeeRate(offerData.cc_fee_rate || 0.012);
      setSupportActs(offerData.support_acts || []);

      console.log('State after loading:', {
        artistName: showData.artist_name,
        venueName: showData.venue_name,
        capacity: showData.capacity,
        eventDate: toLocalDateString(showData.event_date)
      });
    } catch (error) {
      console.error('Error loading offer:', error);
      navigate('/offers');
    } finally {
      setLoading(false);
    }
  };

  const calculations = calculateOffer(
    ticketTiers,
    salesTaxPct,
    expenses,
    guarantee,
    taxWithholdingPct,
    dealType,
    mode,
    artistBackendPct,
    promoterBackendPct,
    supportActs
  );

  const steps = [
    { number: 1, label: 'Event Details' },
    { number: 2, label: 'Artist Deal' },
    { number: 3, label: 'Deposits' },
    { number: 4, label: 'Ticket Scaling' },
    { number: 5, label: 'Expenses' },
    { number: 6, label: 'Summary' },
  ];

  const handleNext = () => {
    console.log('handleNext called, currentStep:', currentStep);
    console.log('Current form state:', { artistName, venueName, eventDate, capacity });

    if (currentStep === 1) {
      if (!artistName || !venueName || !eventDate || capacity === 0) {
        alert('Please fill in all event details');
        return;
      }
    }
    if (currentStep < 6) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    console.log('handlePrevious called, currentStep:', currentStep);
    console.log('Current form state:', { artistName, venueName, eventDate, capacity });

    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSave = async () => {
    if (!artistName || !venueName || !eventDate || capacity === 0) {
      alert('Please fill in all event details');
      return;
    }

    setSaving(true);

    try {
      const { error: showError } = await supabase
        .from('shows')
        .update({
          event_name: eventName || null,
          artist_name: artistName,
          venue_name: venueName,
          event_date: eventDate,
          capacity: capacity,
        })
        .eq('id', showId);

      if (showError) throw showError;

      const venueFullAddress = [
        venueStreet,
        `${venueCity}${venueState ? ', ' + venueState : ''}${venueZip ? ' ' + venueZip : ''}`
      ].filter(Boolean).join('\n');

      const { error: offerError } = await supabase
        .from('offers')
        .update({
          mode: mode,
          status: status,
          deal_type: dealType,
          guarantee: guarantee,
          artist_percentage: artistPercentage,
          tax_withholding_pct: taxWithholdingPct,
          deposit_pct: depositPct,
          artist_backend_pct: artistBackendPct,
          promoter_backend_pct: promoterBackendPct,
          deposit_due_timing: depositDueTiming,
          deposit_due_date: customDepositDate,
          venue_street: venueStreet,
          venue_city: venueCity,
          venue_state: venueState,
          venue_zip: venueZip,
          venue_full_address: venueFullAddress,
          artist_deposit_status: artistDepositStatus,
          venue_deposit: venueDeposit,
          venue_deposit_due_date: venueDepositDueDate,
          venue_deposit_status: venueDepositStatus,
          ticket_tiers: ticketTiers,
          sales_tax_pct: salesTaxPct,
          expenses: expenses,
          calculations: calculations,
          support_acts: supportActs,
          facility_fee_per_ticket: facilityFeePerTicket,
          comps_artist: compsArtist,
          comps_venue: compsVenue,
          comps_promoter: compsPromoter,
          doors_time: doorsTime,
          doors_duration: doorsDuration,
          show_time: showTime,
          show_duration: showDuration,
          curfew_time: curfewTime,
          age_limit: ageLimit,
          merch_rate_soft: merchRateSoft,
          merch_rate_hard: merchRateHard,
          artist_deductions: artistDeductions,
          ascap_rate: ascapRate,
          bmi_rate: bmiRate,
          sesac_rate: sesacRate,
          insurance_per_attendee: insurancePerAttendee,
          cc_fee_rate: ccFeeRate,
        })
        .eq('id', id);

      if (offerError) throw offerError;

      navigate(`/offers/${id}`);
    } catch (error) {
      console.error('Error saving offer:', error);
      alert('Failed to save offer. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">Loading offer...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4 mb-4">
            <button
              onClick={() => navigate(`/offers/${id}`)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Edit Offer</h1>
              <p className="text-sm text-slate-600">Step {currentStep} of {steps.length}: {steps[currentStep - 1].label}</p>
            </div>
          </div>

          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Step {currentStep} of {steps.length}</div>
            <div className="text-sm font-semibold text-slate-900">{steps[currentStep - 1].label}</div>
          </div>

          <div className="relative">
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-300 ease-out"
                style={{ width: `${(currentStep / steps.length) * 100}%` }}
              />
            </div>
            <div className="flex justify-between mt-3">
              {steps.map((step) => (
                <button
                  key={step.number}
                  onClick={() => setCurrentStep(step.number)}
                  className={`flex items-center justify-center w-10 h-10 rounded-full font-semibold transition-colors ${
                    step.number < currentStep
                      ? 'bg-blue-600 text-white'
                      : step.number === currentStep
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {step.number < currentStep ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    step.number
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sm:p-8">
          {currentStep === 1 && (
            <EventDetailsTab
              key="event-details"
              eventName={eventName}
              setEventName={setEventName}
              artistName={artistName}
              setArtistName={setArtistName}
              venueName={venueName}
              setVenueName={setVenueName}
              eventDate={eventDate}
              setEventDate={setEventDate}
              capacity={capacity}
              setCapacity={setCapacity}
              mode={mode}
              venueStreet={venueStreet}
              setVenueStreet={setVenueStreet}
              venueCity={venueCity}
              setVenueCity={setVenueCity}
              venueState={venueState}
              setVenueState={setVenueState}
              venueZip={venueZip}
              setVenueZip={setVenueZip}
              facilityFeePerTicket={facilityFeePerTicket}
              setFacilityFeePerTicket={setFacilityFeePerTicket}
              ageLimit={ageLimit}
              setAgeLimit={setAgeLimit}
              doorsTime={doorsTime}
              setDoorsTime={setDoorsTime}
              doorsDuration={doorsDuration}
              setDoorsDuration={setDoorsDuration}
              showTime={showTime}
              setShowTime={setShowTime}
              showDuration={showDuration}
              setShowDuration={setShowDuration}
              curfewTime={curfewTime}
              setCurfewTime={setCurfewTime}
            />
          )}

          {currentStep === 2 && (
            <ArtistDealTab
              key="artist-deal"
              dealType={dealType}
              setDealType={setDealType}
              guarantee={guarantee}
              setGuarantee={setGuarantee}
              artistPercentage={artistPercentage}
              setArtistPercentage={setArtistPercentage}
              taxWithholdingPct={taxWithholdingPct}
              setTaxWithholdingPct={setTaxWithholdingPct}
              depositPct={depositPct}
              setDepositPct={setDepositPct}
              artistBackendPct={artistBackendPct}
              setArtistBackendPct={setArtistBackendPct}
              promoterBackendPct={promoterBackendPct}
              setPromoterBackendPct={setPromoterBackendPct}
              supportActs={supportActs}
              setSupportActs={setSupportActs}
              merchRateSoft={merchRateSoft}
              setMerchRateSoft={setMerchRateSoft}
              merchRateHard={merchRateHard}
              setMerchRateHard={setMerchRateHard}
              artistDeductions={artistDeductions}
              setArtistDeductions={setArtistDeductions}
              ticketTiers={ticketTiers}
              salesTaxPct={salesTaxPct}
              expenses={expenses}
              facilityFeePerTicket={facilityFeePerTicket}
              ascapRate={ascapRate}
              bmiRate={bmiRate}
              sesacRate={sesacRate}
              insurancePerAttendee={insurancePerAttendee}
              ccFeeRate={ccFeeRate}
            />
          )}

          {currentStep === 3 && (
            <DepositsTab
              key="deposits"
              guarantee={guarantee}
              taxWithholdingPct={taxWithholdingPct}
              setTaxWithholdingPct={setTaxWithholdingPct}
              depositPct={depositPct}
              setDepositPct={setDepositPct}
              depositDueTiming={depositDueTiming}
              setDepositDueTiming={setDepositDueTiming}
              customDepositDate={customDepositDate}
              setCustomDepositDate={setCustomDepositDate}
              artistDepositStatus={artistDepositStatus}
              setArtistDepositStatus={setArtistDepositStatus}
              venueDeposit={venueDeposit}
              setVenueDeposit={setVenueDeposit}
              venueDepositDueDate={venueDepositDueDate}
              setVenueDepositDueDate={setVenueDepositDueDate}
              venueDepositStatus={venueDepositStatus}
              setVenueDepositStatus={setVenueDepositStatus}
              eventDate={eventDate}
            />
          )}

          {currentStep === 4 && (
            <TicketScalingTab
              key="ticket-scaling"
              ticketTiers={ticketTiers}
              setTicketTiers={setTicketTiers}
              salesTaxPct={salesTaxPct}
              setSalesTaxPct={setSalesTaxPct}
              mode={mode}
              compsArtist={compsArtist}
              setCompsArtist={setCompsArtist}
              compsVenue={compsVenue}
              setCompsVenue={setCompsVenue}
              compsPromoter={compsPromoter}
              setCompsPromoter={setCompsPromoter}
            />
          )}

          {currentStep === 5 && (
            <ExpensesTab
              key="expenses"
              expenses={expenses}
              setExpenses={setExpenses}
              ascapRate={ascapRate}
              setAscapRate={setAscapRate}
              bmiRate={bmiRate}
              setBmiRate={setBmiRate}
              sesacRate={sesacRate}
              setSesacRate={setSesacRate}
              insurancePerAttendee={insurancePerAttendee}
              setInsurancePerAttendee={setInsurancePerAttendee}
              ccFeeRate={ccFeeRate}
              setCcFeeRate={setCcFeeRate}
            />
          )}

          {currentStep === 6 && (
            <SummaryTab
              key="summary"
              calculations={calculations}
              dealType={dealType}
              guarantee={guarantee}
              taxWithholdingPct={taxWithholdingPct}
              depositPct={depositPct}
              mode={mode}
              ticketTiers={ticketTiers}
              salesTaxPct={salesTaxPct}
            />
          )}
        </div>

        <div className="mt-6 flex flex-col-reverse sm:flex-row justify-between gap-3">
          <button
            onClick={currentStep === 1 ? () => navigate(`/offers/${id}`) : handlePrevious}
            className="w-full sm:w-auto px-6 py-3 text-slate-700 hover:text-slate-900 font-medium text-center border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            {currentStep === 1 ? 'Cancel' : 'Previous'}
          </button>

          {currentStep < 6 ? (
            <button
              onClick={handleNext}
              className="w-full sm:w-auto px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              Next
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full sm:w-auto px-6 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
