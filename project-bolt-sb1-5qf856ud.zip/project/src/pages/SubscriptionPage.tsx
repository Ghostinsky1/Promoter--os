import React from 'react';
import { STRIPE_PRODUCTS } from '../stripe-config';
import { ProductCard } from '../components/subscription/ProductCard';
import { SubscriptionCard } from '../components/subscription/SubscriptionCard';
import { CreditCard, Crown, Check } from 'lucide-react';

export function SubscriptionPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <div className="w-20 h-20 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center mx-auto mb-6">
            <CreditCard className="h-10 w-10" />
          </div>
          <h1 className="text-4xl font-bold mb-3">Subscription Plans</h1>
          <p className="text-xl opacity-90">
            Choose the plan that works best for your concert promotion needs
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Current Subscription</h2>
          <SubscriptionCard />
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Available Plans</h2>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {STRIPE_PRODUCTS.map((product, index) => {
              const isPopular = index === 0;

              return (
                <div
                  key={product.id}
                  className={`bg-white rounded-2xl p-8 transition-all ${
                    isPopular
                      ? 'bg-gradient-to-br from-indigo-50 to-purple-50 border-4 border-indigo-600 shadow-2xl relative'
                      : 'border-2 border-gray-200 hover:shadow-2xl hover:border-gray-300'
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-indigo-600 text-white px-4 py-1 text-sm font-bold rounded-full">
                      RECOMMENDED
                    </div>
                  )}

                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold mb-2">{product.name}</h3>
                    <div
                      className={`text-5xl font-bold mb-2 ${
                        isPopular
                          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent'
                          : ''
                      }`}
                    >
                      ${product.price}
                    </div>
                    <div className="text-gray-600">per month</div>
                  </div>

                  <div className="space-y-4 mb-8">
                    {product.description?.split('\n').map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className={`text-sm ${isPopular ? 'font-semibold' : ''}`}>
                          {feature.replace(/^[•-]\s*/, '')}
                        </span>
                      </div>
                    ))}
                  </div>

                  <ProductCard product={product} />
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 text-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-4">Offer Generator</h3>
              <p className="text-gray-300 mb-6">
                Generate professional concert offers with detailed financial projections
                and settlement tracking.
              </p>
              <ul className="space-y-2 text-gray-300">
                <li>• Professional PDF generation</li>
                <li>• Multiple ticket tiers</li>
                <li>• Expense tracking</li>
                <li>• Real-time profit calculations</li>
              </ul>
            </div>
            <div className="bg-white rounded-xl p-4">
              <div className="aspect-video bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <CreditCard className="h-16 w-16 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Feature Preview</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
