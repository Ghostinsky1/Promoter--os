/*
  # Add Offer Status Field

  1. Changes
    - Add `status` column to `offers` table with enum type
    - Set default status to 'planning'
    - Add index on status for efficient filtering

  2. Status Values
    - planning: Pre-show financial projections for planning and decision-making
    - offer_sent: Offer has been sent to artist/agent
    - confirmed: Offer accepted and confirmed
    - active: Show is live/happening
    - settled: Show completed and financials settled
    - cancelled: Show cancelled
*/

DO $$ 
BEGIN
  -- Add status column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'offers' AND column_name = 'status'
  ) THEN
    ALTER TABLE offers ADD COLUMN status text DEFAULT 'planning';
    
    -- Add check constraint for valid statuses
    ALTER TABLE offers ADD CONSTRAINT offers_status_check 
      CHECK (status IN ('planning', 'offer_sent', 'confirmed', 'active', 'settled', 'cancelled'));
    
    -- Create index for efficient filtering
    CREATE INDEX IF NOT EXISTS idx_offers_status ON offers(status);
  END IF;
END $$;
