/*
  # Add Professional Offer Fields

  1. New Fields Added to offers table
    - facility_fee_per_ticket: Default $2.00 fee per ticket
    - comps_artist: Number of complimentary tickets for artist
    - comps_venue: Number of complimentary tickets for venue
    - comps_promoter: Number of complimentary tickets for promoter
    - doors_time: Time doors open
    - doors_duration: Duration doors are open (minutes)
    - show_time: Time show starts
    - show_duration: Duration of show (minutes)
    - curfew_time: Curfew time
    - age_limit: Age restriction for event
    - merch_rate_soft: Percentage artist keeps on soft merch sales
    - merch_rate_hard: Percentage artist keeps on hard merch sales
    - offer_sent_date: Date offer was sent
    - ascap_rate: ASCAP licensing rate (default 0.23%)
    - bmi_rate: BMI licensing rate (default 0.3%)
    - sesac_rate: SESAC licensing rate (default 0.0214%)
    - insurance_per_attendee: Insurance cost per attendee (default $0.62)
    - cc_fee_rate: Credit card processing fee rate (default 1.2%)
    - artist_deductions: Array of deductions from artist pay (equipment rentals, etc.)

  2. Purpose
    - Enable professional PDF generation matching industry standards
    - Track all costs and fees accurately
    - Calculate break-even points and split points
    - Provide complete offer documentation
*/

-- Add facility fee (default $2.00 per ticket)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'facility_fee_per_ticket'
  ) THEN
    ALTER TABLE offers ADD COLUMN facility_fee_per_ticket DECIMAL DEFAULT 2.00;
  END IF;
END $$;

-- Add comp tickets tracking
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'comps_artist'
  ) THEN
    ALTER TABLE offers ADD COLUMN comps_artist INTEGER DEFAULT 0;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'comps_venue'
  ) THEN
    ALTER TABLE offers ADD COLUMN comps_venue INTEGER DEFAULT 0;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'comps_promoter'
  ) THEN
    ALTER TABLE offers ADD COLUMN comps_promoter INTEGER DEFAULT 0;
  END IF;
END $$;

-- Add show timing fields
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'doors_time'
  ) THEN
    ALTER TABLE offers ADD COLUMN doors_time TIME;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'doors_duration'
  ) THEN
    ALTER TABLE offers ADD COLUMN doors_duration INTEGER;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'show_time'
  ) THEN
    ALTER TABLE offers ADD COLUMN show_time TIME;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'show_duration'
  ) THEN
    ALTER TABLE offers ADD COLUMN show_duration INTEGER;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'curfew_time'
  ) THEN
    ALTER TABLE offers ADD COLUMN curfew_time TIME;
  END IF;
END $$;

-- Add event details
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'age_limit'
  ) THEN
    ALTER TABLE offers ADD COLUMN age_limit TEXT DEFAULT 'All Ages';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'merch_rate_soft'
  ) THEN
    ALTER TABLE offers ADD COLUMN merch_rate_soft INTEGER DEFAULT 100;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'merch_rate_hard'
  ) THEN
    ALTER TABLE offers ADD COLUMN merch_rate_hard INTEGER DEFAULT 100;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'offer_sent_date'
  ) THEN
    ALTER TABLE offers ADD COLUMN offer_sent_date DATE;
  END IF;
END $$;

-- Add variable expense rates
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'ascap_rate'
  ) THEN
    ALTER TABLE offers ADD COLUMN ascap_rate DECIMAL DEFAULT 0.0023;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'bmi_rate'
  ) THEN
    ALTER TABLE offers ADD COLUMN bmi_rate DECIMAL DEFAULT 0.003;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'sesac_rate'
  ) THEN
    ALTER TABLE offers ADD COLUMN sesac_rate DECIMAL DEFAULT 0.000214;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'insurance_per_attendee'
  ) THEN
    ALTER TABLE offers ADD COLUMN insurance_per_attendee DECIMAL DEFAULT 0.62;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'cc_fee_rate'
  ) THEN
    ALTER TABLE offers ADD COLUMN cc_fee_rate DECIMAL DEFAULT 0.012;
  END IF;
END $$;

-- Add artist deductions (JSONB array)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'artist_deductions'
  ) THEN
    ALTER TABLE offers ADD COLUMN artist_deductions JSONB DEFAULT '[]';
  END IF;
END $$;