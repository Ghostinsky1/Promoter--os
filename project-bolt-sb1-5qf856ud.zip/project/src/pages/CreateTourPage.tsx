import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { TourStatus } from '../types';
import { useAuth } from '../hooks/useAuth';

export function CreateTourPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const [tourData, setTourData] = useState({
    name: '',
    artist_name: '',
    start_date: '',
    end_date: '',
    description: '',
    status: 'planning' as TourStatus
  });

  const createTour = async () => {
    if (!user || !tourData.name || !tourData.artist_name || !tourData.start_date || !tourData.end_date) {
      alert('Please fill in all required fields');
      return;
    }

    setSaving(true);
    try {
      const { data, error } = await supabase
        .from('tours')
        .insert([{
          ...tourData,
          user_id: user.id
        }])
        .select()
        .single();

      if (error) throw error;

      navigate(`/tours/${data.id}`);
    } catch (error) {
      console.error('Error creating tour:', error);
      alert('Failed to create tour. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/tours')}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Create New Tour</h1>
              <p className="text-slate-600">Set up a multi-city tour</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white border border-slate-200 rounded-xl p-8">
          <div className="space-y-6">
            <div>
              <label className="block text-base font-semibold mb-2 text-slate-700">Tour Name *</label>
              <input
                type="text"
                value={tourData.name}
                onChange={(e) => setTourData({...tourData, name: e.target.value})}
                placeholder="e.g., Summer 2025 World Tour"
                className="w-full text-lg px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-base font-semibold mb-2 text-slate-700">Artist Name *</label>
              <input
                type="text"
                value={tourData.artist_name}
                onChange={(e) => setTourData({...tourData, artist_name: e.target.value})}
                placeholder="e.g., Drake"
                className="w-full text-lg px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-base font-semibold mb-2 text-slate-700">Start Date *</label>
                <input
                  type="date"
                  value={tourData.start_date}
                  onChange={(e) => setTourData({...tourData, start_date: e.target.value})}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-base font-semibold mb-2 text-slate-700">End Date *</label>
                <input
                  type="date"
                  value={tourData.end_date}
                  onChange={(e) => setTourData({...tourData, end_date: e.target.value})}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-base font-semibold mb-2 text-slate-700">Description</label>
              <textarea
                value={tourData.description}
                onChange={(e) => setTourData({...tourData, description: e.target.value})}
                placeholder="Tour details, themes, special notes..."
                rows={4}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-base font-semibold mb-2 text-slate-700">Tour Status</label>
              <select
                value={tourData.status}
                onChange={(e) => setTourData({...tourData, status: e.target.value as TourStatus})}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="planning">📋 Planning</option>
                <option value="booking">📞 Booking</option>
                <option value="confirmed">✅ Confirmed</option>
                <option value="active">🎸 Active</option>
                <option value="completed">✓ Completed</option>
                <option value="cancelled">❌ Cancelled</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-4">
        <div className="max-w-4xl mx-auto flex justify-end gap-3">
          <button
            onClick={() => navigate('/tours')}
            className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium"
          >
            Cancel
          </button>
          <button
            onClick={createTour}
            disabled={saving}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium disabled:opacity-50"
          >
            {saving ? 'Creating...' : 'Create Tour'}
          </button>
        </div>
      </div>
    </div>
  );
}
