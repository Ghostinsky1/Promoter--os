/*
  # Add typical expenses to company settings

  1. Changes
    - Add `typical_expenses` JSONB column to `company_settings` table
    - This will store default expense values that can be loaded when creating new offers
  
  2. Structure
    - The typical_expenses field will store a JSONB object with the same structure as offer expenses:
      {
        "talent": { "rider_hospitality": 0 },
        "general": { "security": 0, "emt": 0, "gate_staff": 0 },
        "marketing": { "radio": 0, "marketing": 0, "paid_social": 0 },
        "production": { "production": 0, "crew_stagehands": 0, "camera_operator": 0, "technical_director": 0 }
      }
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'company_settings' AND column_name = 'typical_expenses'
  ) THEN
    ALTER TABLE company_settings ADD COLUMN typical_expenses jsonb DEFAULT '{
      "talent": {"rider_hospitality": 0},
      "general": {"security": 0, "emt": 0, "gate_staff": 0},
      "marketing": {"radio": 0, "marketing": 0, "paid_social": 0},
      "production": {"production": 0, "crew_stagehands": 0, "camera_operator": 0, "technical_director": 0}
    }'::jsonb;
  END IF;
END $$;