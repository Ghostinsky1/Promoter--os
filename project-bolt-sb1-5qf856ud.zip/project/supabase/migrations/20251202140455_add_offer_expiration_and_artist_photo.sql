/*
  # Add Offer Expiration and Artist Photo Fields

  1. Changes
    - Add `offer_expires_at` to offers table (when the offer deal ends)
    - Add `artist_photo_url` to shows table (artist image for cards)
  
  2. Notes
    - These fields enhance the offer cards display
    - Offer expiration helps track deal deadlines
    - Artist photos provide visual identification
*/

-- Add offer expiration date to offers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'offer_expires_at'
  ) THEN
    ALTER TABLE offers ADD COLUMN offer_expires_at timestamptz;
  END IF;
END $$;

-- Add artist photo URL to shows table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'shows' AND column_name = 'artist_photo_url'
  ) THEN
    ALTER TABLE shows ADD COLUMN artist_photo_url text;
  END IF;
END $$;
