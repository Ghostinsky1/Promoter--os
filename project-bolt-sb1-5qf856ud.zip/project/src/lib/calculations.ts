import { TicketTier, Expenses, Calculations, ProjectionResult, SupportAct } from '../types';

export function calculateOffer(
  ticketTiers: TicketTier[],
  salesTaxPct: number,
  expenses: Expenses,
  guarantee: number,
  taxWithholdingPct: number,
  dealType: 'flat_guarantee' | 'promoter_profit',
  mode: 'estimate' | 'settlement',
  artistBackendPct: number = 85,
  promoterBackendPct: number = 15,
  supportActs: SupportAct[] = []
): Calculations {
  const supportActsCost = supportActs.reduce((sum, act) => sum + act.guarantee, 0);
  const totalExpenses = calculateTotalExpenses(expenses) + supportActsCost;

  const grossPotential = ticketTiers.reduce((sum, tier) => {
    const tickets = mode === 'settlement' && tier.actualSold !== undefined
      ? tier.actualSold
      : (tier.allotment - tier.comps);
    return sum + (tickets * tier.price);
  }, 0);

  const salesTax = grossPotential * (salesTaxPct / 100);
  const netGross = grossPotential - salesTax;

  let artistTotalPayout = guarantee * (1 - taxWithholdingPct / 100);
  let promoterProfit = 0;
  let splitPoint = 0;
  let backend = 0;
  let artistBackend = 0;
  let promoterBackend = 0;

  if (dealType === 'promoter_profit') {
    promoterProfit = totalExpenses * (promoterBackendPct / 100);
    splitPoint = guarantee + totalExpenses + promoterProfit;

    if (netGross > splitPoint) {
      backend = netGross - splitPoint;
      artistBackend = backend * (artistBackendPct / 100);
      promoterBackend = backend * (promoterBackendPct / 100);
      artistTotalPayout = (guarantee + artistBackend) * (1 - taxWithholdingPct / 100);
    }
  }

  const netProfit = netGross - totalExpenses - guarantee;

  const projections = mode === 'estimate' ? {
    capacity70: calculateProjection(ticketTiers, 0.7, salesTaxPct, totalExpenses, guarantee, taxWithholdingPct, dealType, artistBackendPct, promoterBackendPct),
    capacity85: calculateProjection(ticketTiers, 0.85, salesTaxPct, totalExpenses, guarantee, taxWithholdingPct, dealType, artistBackendPct, promoterBackendPct),
    capacity100: calculateProjection(ticketTiers, 1.0, salesTaxPct, totalExpenses, guarantee, taxWithholdingPct, dealType, artistBackendPct, promoterBackendPct),
  } : undefined;

  return {
    grossPotential,
    salesTax,
    netGross,
    totalExpenses,
    netProfit,
    artistTotalPayout,
    promoterProfit: dealType === 'promoter_profit' ? promoterProfit : undefined,
    splitPoint: dealType === 'promoter_profit' ? splitPoint : undefined,
    backend: dealType === 'promoter_profit' ? backend : undefined,
    artistBackend: dealType === 'promoter_profit' ? artistBackend : undefined,
    promoterBackend: dealType === 'promoter_profit' ? promoterBackend : undefined,
    projections,
  };
}

function calculateProjection(
  ticketTiers: TicketTier[],
  capacityPct: number,
  salesTaxPct: number,
  totalExpenses: number,
  guarantee: number,
  taxWithholdingPct: number,
  dealType: 'flat_guarantee' | 'promoter_profit',
  artistBackendPct: number = 85,
  promoterBackendPct: number = 15
): ProjectionResult {
  const totalSellable = ticketTiers.reduce((sum, tier) => sum + (tier.allotment - tier.comps), 0);
  const projectedTickets = Math.floor(totalSellable * capacityPct);

  const grossPotential = ticketTiers.reduce((sum, tier) => {
    const tierSellable = tier.allotment - tier.comps;
    const tierProjected = Math.floor(tierSellable * capacityPct);
    return sum + (tierProjected * tier.price);
  }, 0);

  const salesTax = grossPotential * (salesTaxPct / 100);
  const netGross = grossPotential - salesTax;

  let artistPayout = guarantee * (1 - taxWithholdingPct / 100);
  let promoterProfit = 0;
  let splitPointHit = false;

  if (dealType === 'promoter_profit') {
    promoterProfit = totalExpenses * (promoterBackendPct / 100);
    const splitPoint = guarantee + totalExpenses + promoterProfit;

    if (netGross > splitPoint) {
      splitPointHit = true;
      const backend = netGross - splitPoint;
      const artistBackend = backend * (artistBackendPct / 100);
      promoterProfit += backend * (promoterBackendPct / 100);
      artistPayout = (guarantee + artistBackend) * (1 - taxWithholdingPct / 100);
    }
  }

  const netProfit = netGross - totalExpenses - guarantee;

  return {
    tickets: projectedTickets,
    grossPotential,
    netGross,
    artistPayout,
    promoterProfit,
    netProfit,
    splitPointHit,
  };
}

export function calculateTotalExpenses(expenses: Expenses): number {
  return Object.values(expenses).reduce((total, category) => {
    return total + Object.values(category).reduce((sum, val) => sum + val, 0);
  }, 0);
}

export function calculateCategoryTotal(category: Record<string, number>): number {
  return Object.values(category).reduce((sum, val) => sum + val, 0);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function formatPercent(value: number): string {
  return `${value.toFixed(2)}%`;
}
