import { Calendar, MapPin } from 'lucide-react';
import { calculateDepositDueDate, getDaysUntil, formatDate } from '../../lib/dateHelpers';

interface DepositsTabProps {
  guarantee: number;
  taxWithholdingPct: number;
  setTaxWithholdingPct: (value: number) => void;
  depositPct: number;
  setDepositPct: (value: number) => void;
  depositDueTiming: string;
  setDepositDueTiming: (value: string) => void;
  customDepositDate: string;
  setCustomDepositDate: (value: string) => void;
  artistDepositStatus: string;
  setArtistDepositStatus: (value: string) => void;
  venueDeposit: number;
  setVenueDeposit: (value: number) => void;
  venueDepositDueDate: string;
  setVenueDepositDueDate: (value: string) => void;
  venueDepositStatus: string;
  setVenueDepositStatus: (value: string) => void;
  eventDate: string;
}

export function DepositsTab(props: DepositsTabProps) {
  const {
    guarantee,
    taxWithholdingPct,
    setTaxWithholdingPct,
    depositPct,
    setDepositPct,
    depositDueTiming,
    setDepositDueTiming,
    customDepositDate,
    setCustomDepositDate,
    artistDepositStatus,
    setArtistDepositStatus,
    venueDeposit,
    setVenueDeposit,
    venueDepositDueDate,
    setVenueDepositDueDate,
    venueDepositStatus,
    setVenueDepositStatus,
    eventDate
  } = props;

  const calculatedArtistDepositDueDate = calculateDepositDueDate(eventDate, depositDueTiming, customDepositDate);
  const artistDepositAmount = (guarantee * depositPct) / 100;
  const taxWithholdingAmount = (guarantee * taxWithholdingPct) / 100;
  const totalPayout = guarantee - taxWithholdingAmount;

  return (
    <div className="space-y-6">
      {/* Tax Withholding */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-base font-semibold mb-2">Tax Withholding %</label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              value={taxWithholdingPct}
              onChange={(e) => {
                const val = e.target.value === '' ? 0 : Number(e.target.value);
                setTaxWithholdingPct(isNaN(val) ? 0 : val);
              }}
              placeholder="2"
              step="0.1"
              className="flex-1 py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
            <span className="text-gray-500 text-lg">%</span>
          </div>
        </div>
        <div>
          <label className="block text-sm text-gray-500 mb-2">Withholding Amount</label>
          <div className="text-2xl font-bold text-red-600">
            -${taxWithholdingAmount.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Artist Deposit Card */}
      <div className="bg-blue-50 border-2 border-blue-300 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-6">
          <Calendar className="h-5 w-5 text-blue-600" />
          <h4 className="font-bold text-lg">Artist Deposit</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-semibold mb-2">Percentage</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={depositPct}
                onChange={(e) => {
                  const val = e.target.value === '' ? 0 : Number(e.target.value);
                  setDepositPct(isNaN(val) ? 0 : val);
                }}
                placeholder="20"
                className="w-full text-center text-lg font-bold py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              <span className="text-gray-500 text-lg">%</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Deposit Amount</label>
            <div className="text-2xl font-bold text-blue-600">
              ${artistDepositAmount.toLocaleString()}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Status</label>
            <select
              value={artistDepositStatus}
              onChange={(e) => setArtistDepositStatus(e.target.value)}
              className="w-full py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="pending">⏳ Pending</option>
              <option value="paid">✅ Paid</option>
              <option value="overdue">⚠️ Overdue</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold mb-2 text-red-600">
            Due Date * (Required)
          </label>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <select
              value={depositDueTiming}
              onChange={(e) => setDepositDueTiming(e.target.value)}
              className="w-full py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="30_days_before">30 days before show</option>
              <option value="60_days_before">60 days before show</option>
              <option value="upon_signing">Upon contract signing</option>
              <option value="custom">Custom date</option>
            </select>

            {depositDueTiming === 'custom' && (
              <input
                type="date"
                value={customDepositDate}
                onChange={(e) => setCustomDepositDate(e.target.value)}
                className="w-full py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 text-lg"
              />
            )}
          </div>

          {calculatedArtistDepositDueDate && (
            <div className="mt-3 p-3 bg-white border border-blue-200 rounded-lg flex items-start gap-2">
              <Calendar className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <span className="font-semibold">Due date: </span>
                <span className="text-blue-600 font-bold">
                  {formatDate(calculatedArtistDepositDueDate)}
                </span>
                <span className="text-gray-600"> ({getDaysUntil(calculatedArtistDepositDueDate)})</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Venue Deposit Card */}
      <div className="bg-yellow-50 border-2 border-yellow-300 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-6">
          <MapPin className="h-5 w-5 text-yellow-600" />
          <h4 className="font-bold text-lg">Venue Deposit</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-semibold mb-2">Amount</label>
            <div className="flex items-center gap-2">
              <span className="text-gray-500">$</span>
              <input
                type="number"
                value={venueDeposit || ''}
                onChange={(e) => {
                  const val = e.target.value === '' ? 0 : Number(e.target.value);
                  setVenueDeposit(isNaN(val) ? 0 : val);
                }}
                placeholder="5000"
                className="w-full text-lg font-bold py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-yellow-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-red-600">
              Due Date * (Required)
            </label>
            <input
              type="date"
              value={venueDepositDueDate}
              onChange={(e) => setVenueDepositDueDate(e.target.value)}
              className="w-full py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-yellow-600 text-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Status</label>
            <select
              value={venueDepositStatus}
              onChange={(e) => setVenueDepositStatus(e.target.value)}
              className="w-full py-3 px-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-yellow-600"
            >
              <option value="pending">⏳ Pending</option>
              <option value="paid">✅ Paid</option>
              <option value="overdue">⚠️ Overdue</option>
            </select>
          </div>
        </div>

        {venueDepositDueDate && (
          <div className="p-3 bg-white border border-yellow-200 rounded-lg flex items-start gap-2">
            <Calendar className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <span className="font-semibold">Due date: </span>
              <span className="text-yellow-700 font-bold">
                {formatDate(venueDepositDueDate)}
              </span>
              <span className="text-gray-600"> ({getDaysUntil(venueDepositDueDate)})</span>
            </div>
          </div>
        )}
      </div>

      {/* Total Payout Summary */}
      <div className="bg-green-50 border border-green-200 rounded-xl p-6">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-sm text-gray-600 mb-1">Total Artist Payout</div>
            <div className="text-xs text-gray-500">After tax withholding</div>
          </div>
          <div className="text-3xl font-bold text-green-600">
            ${totalPayout.toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
}
