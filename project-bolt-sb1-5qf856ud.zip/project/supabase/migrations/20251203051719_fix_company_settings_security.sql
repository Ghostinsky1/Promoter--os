/*
  # Fix Company Settings Security

  1. Changes
    - Drop the insecure "Allow all" policies on company_settings
    - Add proper user-scoped policies that check user_id
    - Ensure users can only access their own company settings

  2. Security
    - Remove policies using `USING (true)` which allow access to all data
    - Add restrictive policies that verify auth.uid() matches user_id
    - Each user can only read/write their own company settings
*/

-- Drop the insecure policies
DROP POLICY IF EXISTS "Allow all to read company settings" ON company_settings;
DROP POLICY IF EXISTS "Allow all to insert company settings" ON company_settings;
DROP POLICY IF EXISTS "Allow all to update company settings" ON company_settings;
DROP POLICY IF EXISTS "Allow all to delete company settings" ON company_settings;

-- Add secure policies that check user ownership
CREATE POLICY "Users can view own company settings"
  ON company_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can create own company settings"
  ON company_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update own company settings"
  ON company_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = user_id)
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can delete own company settings"
  ON company_settings
  FOR DELETE
  TO authenticated
  USING (auth.uid()::text = user_id);