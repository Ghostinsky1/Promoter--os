/*
  # Create Settlements Tracking Table

  1. New Tables
    - `settlements`
      - `id` (text, primary key)
      - `offer_id` (text, foreign key to offers)
      - `user_id` (uuid, foreign key to auth.users)
      - `actual_attendance` (jsonb) - stores actual ticket sales per tier
      - `actual_expenses` (jsonb) - stores actual expenses by category
      - `actual_revenue` (decimal) - total actual revenue
      - `actual_total_expenses` (decimal) - total actual expenses
      - `actual_profit` (decimal) - actual profit/loss
      - `variance_revenue` (decimal) - projected vs actual revenue
      - `variance_expenses` (decimal) - projected vs actual expenses
      - `variance_profit` (decimal) - projected vs actual profit
      - `notes` (text) - settlement notes
      - `settled_at` (timestamp) - when settlement was completed
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `settlements` table
    - Add policies for authenticated users to manage their own settlements
*/

CREATE TABLE IF NOT EXISTS settlements (
  id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  offer_id text NOT NULL REFERENCES offers(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  actual_attendance jsonb NOT NULL DEFAULT '[]'::jsonb,
  actual_expenses jsonb NOT NULL DEFAULT '{}'::jsonb,
  actual_revenue decimal(15,2) NOT NULL DEFAULT 0,
  actual_total_expenses decimal(15,2) NOT NULL DEFAULT 0,
  actual_profit decimal(15,2) NOT NULL DEFAULT 0,
  variance_revenue decimal(15,2) NOT NULL DEFAULT 0,
  variance_expenses decimal(15,2) NOT NULL DEFAULT 0,
  variance_profit decimal(15,2) NOT NULL DEFAULT 0,
  notes text DEFAULT '',
  settled_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settlements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own settlements"
  ON settlements FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own settlements"
  ON settlements FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own settlements"
  ON settlements FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own settlements"
  ON settlements FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_settlements_offer_id ON settlements(offer_id);
CREATE INDEX IF NOT EXISTS idx_settlements_user_id ON settlements(user_id);