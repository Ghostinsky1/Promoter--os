import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { OfferWithShow, ScheduleItem, VenueContact, CompanySettings } from '../types';
import { convertTo12Hour } from './timeHelpers';

export function generateRunOfShowPDF(
  offerData: OfferWithShow,
  schedule: ScheduleItem[],
  venueContact: VenueContact,
  eventDate: string,
  companySettings?: CompanySettings
) {
  const doc = new jsPDF();
  let yPos = 20;

  doc.setFillColor(0, 0, 0);
  doc.rect(0, 0, 210, 40, 'F');

  if (companySettings?.logo_url) {
    try {
      doc.addImage(companySettings.logo_url, 'PNG', 15, 10, 20, 20);
    } catch (error) {
      console.error('Failed to add logo:', error);
    }
  }

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('RUN OF SHOW', 105, 20, { align: 'center' });

  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text(offerData.show.artist_name.toUpperCase(), 105, 30, { align: 'center' });

  if (companySettings?.company_name) {
    doc.setFontSize(8);
    doc.text(companySettings.company_name.toUpperCase(), 190, 12, { align: 'right' });
  }

  yPos = 50;

  doc.setTextColor(0, 0, 0);
  doc.setFillColor(240, 240, 240);
  doc.roundedRect(15, yPos, 180, 35, 3, 3, 'F');

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('EVENT INFORMATION', 20, yPos + 8);

  doc.setFont('helvetica', 'normal');
  doc.text(`Date: ${formatDate(eventDate)}`, 20, yPos + 16);
  doc.text(`Venue: ${offerData.show.venue_name}`, 20, yPos + 22);
  doc.text(`Capacity: ${offerData.show.capacity}`, 20, yPos + 28);

  doc.text(`Venue Contact: ${venueContact.name || 'N/A'}`, 110, yPos + 16);
  doc.text(`Phone: ${venueContact.phone || 'N/A'}`, 110, yPos + 22);
  doc.text(`Email: ${venueContact.email || 'N/A'}`, 110, yPos + 28);

  yPos += 45;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('SCHEDULE', 105, yPos, { align: 'center' });
  yPos += 8;

  doc.setFillColor(79, 70, 229);
  doc.rect(15, yPos, 180, 10, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('TIME', 20, yPos + 7);
  doc.text('DURATION', 45, yPos + 7);
  doc.text('ACTIVITY', 75, yPos + 7);
  doc.text('RESPONSIBLE', 150, yPos + 7);
  yPos += 12;

  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');

  schedule.forEach((item, index) => {
    if (index % 2 === 0) {
      doc.setFillColor(250, 250, 250);
      doc.rect(15, yPos - 2, 180, 8, 'F');
    }

    const categoryColors: Record<string, [number, number, number]> = {
      production: [59, 130, 246],
      technical: [168, 85, 247],
      artist: [236, 72, 153],
      performance: [34, 197, 94],
      venue: [249, 115, 22],
      other: [107, 114, 128]
    };
    const color = categoryColors[item.category] || categoryColors.other;
    doc.setFillColor(...color);
    doc.circle(17, yPos + 2, 1.5, 'F');

    doc.setTextColor(0, 0, 0);
    doc.text(convertTo12Hour(item.time), 20, yPos + 5);
    doc.text(`${item.duration} min`, 50, yPos + 5);

    const titleText = doc.splitTextToSize(item.title, 70);
    doc.text(titleText[0], 75, yPos + 5);

    const responsibleText = doc.splitTextToSize(item.responsible, 40);
    doc.text(responsibleText[0], 150, yPos + 5);

    yPos += 8;

    if (yPos > 270) {
      doc.addPage();
      yPos = 20;
    }
  });

  yPos += 10;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('LEGEND', 20, yPos);
  yPos += 8;

  const legend = [
    { category: 'production', label: 'Production', color: [59, 130, 246] as [number, number, number] },
    { category: 'technical', label: 'Technical', color: [168, 85, 247] as [number, number, number] },
    { category: 'artist', label: 'Artist', color: [236, 72, 153] as [number, number, number] },
    { category: 'performance', label: 'Performance', color: [34, 197, 94] as [number, number, number] },
    { category: 'venue', label: 'Venue', color: [249, 115, 22] as [number, number, number] }
  ];

  doc.setFont('helvetica', 'normal');
  legend.forEach((item, index) => {
    const x = 20 + (index * 35);
    doc.setFillColor(...item.color);
    doc.circle(x, yPos, 1.5, 'F');
    doc.setTextColor(0, 0, 0);
    doc.text(item.label, x + 5, yPos + 2);
  });

  if (yPos < 250) {
    yPos += 15;
    doc.setFont('helvetica', 'bold');
    doc.text('NOTES', 20, yPos);
    yPos += 8;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text('• All times are approximate and subject to change', 20, yPos);
    yPos += 5;
    doc.text('• Contact venue production manager for any schedule changes', 20, yPos);
    yPos += 5;
    doc.text('• Artist load-in and sound check times to be confirmed', 20, yPos);
  }

  if (companySettings?.legal_terms) {
    if (yPos > 240) {
      doc.addPage();
      yPos = 20;
    } else {
      yPos += 15;
    }

    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('TERMS & CONDITIONS', 20, yPos);
    yPos += 8;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(60);

    const terms = companySettings.legal_terms.split('\n').filter(line => line.trim());
    terms.forEach(term => {
      if (yPos > 280) {
        doc.addPage();
        yPos = 20;
      }
      const lines = doc.splitTextToSize(term, 170);
      lines.forEach((line: string) => {
        doc.text(line, 20, yPos);
        yPos += 4;
      });
    });
  }

  doc.setFontSize(8);
  doc.setTextColor(150, 150, 150);
  doc.text('Generated by Atlas', 105, 285, { align: 'center' });
  doc.text(new Date().toLocaleDateString(), 105, 290, { align: 'center' });

  const filename = `Run_of_Show_${offerData.show.artist_name.replace(/\s+/g, '_')}_${formatDate(eventDate)}.pdf`;
  doc.save(filename);
}

function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}
