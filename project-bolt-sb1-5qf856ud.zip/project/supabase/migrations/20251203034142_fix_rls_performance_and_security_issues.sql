/*
  # Fix RLS Performance and Security Issues

  ## Overview
  This migration optimizes Row Level Security (RLS) policies for better performance at scale
  and removes duplicate/conflicting policies.

  ## Changes

  ### 1. RLS Performance Optimization
  Replace all `auth.uid()` calls with `(select auth.uid())` to prevent re-evaluation for each row.
  This applies to all tables:
  - stripe_customers
  - stripe_subscriptions
  - stripe_orders
  - templates
  - shows
  - offers
  - user_roles
  - run_of_show
  - tours

  ### 2. Remove Duplicate Policies
  - Drop "Allow all operations on offers" policy (conflicts with specific CRUD policies)
  - Drop "Allow all operations on shows" policy (conflicts with specific CRUD policies)

  ### 3. Fix Function Security
  - Add immutable search_path to create_user_role() function

  ## Security Impact
  - Improves query performance by caching auth.uid() evaluation
  - Removes overly permissive "ALL" policies in favor of specific CRUD policies
  - Maintains same security posture with better performance
*/

-- ============================================================
-- PART 1: Remove Duplicate/Conflicting Policies
-- ============================================================

-- Drop overly broad policies that conflict with specific CRUD policies
DROP POLICY IF EXISTS "Allow all operations on offers" ON offers;
DROP POLICY IF EXISTS "Allow all operations on shows" ON shows;

-- ============================================================
-- PART 2: Optimize Stripe Tables RLS Policies
-- ============================================================

-- stripe_customers
DROP POLICY IF EXISTS "Users can view their own customer data" ON stripe_customers;
CREATE POLICY "Users can view their own customer data"
  ON stripe_customers
  FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()) AND deleted_at IS NULL);

-- stripe_subscriptions
DROP POLICY IF EXISTS "Users can view their own subscription data" ON stripe_subscriptions;
CREATE POLICY "Users can view their own subscription data"
  ON stripe_subscriptions
  FOR SELECT
  TO authenticated
  USING (
    customer_id IN (
      SELECT customer_id
      FROM stripe_customers
      WHERE user_id = (select auth.uid()) AND deleted_at IS NULL
    )
    AND deleted_at IS NULL
  );

-- stripe_orders
DROP POLICY IF EXISTS "Users can view their own order data" ON stripe_orders;
CREATE POLICY "Users can view their own order data"
  ON stripe_orders
  FOR SELECT
  TO authenticated
  USING (
    customer_id IN (
      SELECT customer_id
      FROM stripe_customers
      WHERE user_id = (select auth.uid()) AND deleted_at IS NULL
    )
    AND deleted_at IS NULL
  );

-- ============================================================
-- PART 3: Optimize Templates Table RLS Policies
-- ============================================================

DROP POLICY IF EXISTS "Users can view own templates" ON templates;
CREATE POLICY "Users can view own templates"
  ON templates FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can create own templates" ON templates;
CREATE POLICY "Users can create own templates"
  ON templates FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own templates" ON templates;
CREATE POLICY "Users can update own templates"
  ON templates FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own templates" ON templates;
CREATE POLICY "Users can delete own templates"
  ON templates FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- ============================================================
-- PART 4: Optimize Shows Table RLS Policies
-- ============================================================

DROP POLICY IF EXISTS "Users can view own shows" ON shows;
CREATE POLICY "Users can view own shows"
  ON shows FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can create own shows" ON shows;
CREATE POLICY "Users can create own shows"
  ON shows FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own shows" ON shows;
CREATE POLICY "Users can update own shows"
  ON shows FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own shows" ON shows;
CREATE POLICY "Users can delete own shows"
  ON shows FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- ============================================================
-- PART 5: Optimize Offers Table RLS Policies
-- ============================================================

DROP POLICY IF EXISTS "Users can view own offers" ON offers;
CREATE POLICY "Users can view own offers"
  ON offers FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can create own offers" ON offers;
CREATE POLICY "Users can create own offers"
  ON offers FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own offers" ON offers;
CREATE POLICY "Users can update own offers"
  ON offers FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own offers" ON offers;
CREATE POLICY "Users can delete own offers"
  ON offers FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- ============================================================
-- PART 6: Optimize User Roles Table RLS Policies
-- ============================================================

DROP POLICY IF EXISTS "Users can view own role" ON user_roles;
CREATE POLICY "Users can view own role"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Admins can view all roles" ON user_roles;
CREATE POLICY "Admins can view all roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = (select auth.uid())
      AND user_roles.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can update roles" ON user_roles;
CREATE POLICY "Admins can update roles"
  ON user_roles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = (select auth.uid())
      AND user_roles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = (select auth.uid())
      AND user_roles.is_admin = true
    )
  );

DROP POLICY IF EXISTS "System can insert roles" ON user_roles;
CREATE POLICY "System can insert roles"
  ON user_roles
  FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

-- ============================================================
-- PART 7: Optimize Run of Show Table RLS Policies
-- ============================================================

DROP POLICY IF EXISTS "Users can view own run of show" ON run_of_show;
CREATE POLICY "Users can view own run of show"
  ON run_of_show FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can create own run of show" ON run_of_show;
CREATE POLICY "Users can create own run of show"
  ON run_of_show FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own run of show" ON run_of_show;
CREATE POLICY "Users can update own run of show"
  ON run_of_show FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own run of show" ON run_of_show;
CREATE POLICY "Users can delete own run of show"
  ON run_of_show FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- ============================================================
-- PART 8: Optimize Tours Table RLS Policies
-- ============================================================

DROP POLICY IF EXISTS "Users can view own tours" ON tours;
CREATE POLICY "Users can view own tours"
  ON tours FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can create own tours" ON tours;
CREATE POLICY "Users can create own tours"
  ON tours FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own tours" ON tours;
CREATE POLICY "Users can update own tours"
  ON tours FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own tours" ON tours;
CREATE POLICY "Users can delete own tours"
  ON tours FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- ============================================================
-- PART 9: Fix Function Security
-- ============================================================

-- Recreate create_user_role function with immutable search_path
CREATE OR REPLACE FUNCTION create_user_role()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_roles (user_id, is_admin)
  VALUES (NEW.id, false)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public, pg_temp;

-- ============================================================
-- PART 10: Add Missing Indexes for Performance
-- ============================================================

-- Add indexes for offers status and show_id lookups
CREATE INDEX IF NOT EXISTS idx_offers_show_id ON offers(show_id);
CREATE INDEX IF NOT EXISTS idx_offers_status ON offers(status);
