export interface Show {
  id: string;
  event_name?: string;
  artist_name: string;
  venue_name: string;
  event_date: string;
  capacity: number;
  created_at: string;
}

export interface TicketTier {
  type: string;
  allotment: number;
  comps: number;
  price: number;
  actualSold?: number;
}

export interface Expenses {
  talent: Record<string, number>;
  general: Record<string, number>;
  marketing: Record<string, number>;
  production: Record<string, number>;
}

export interface Calculations {
  grossPotential: number;
  salesTax: number;
  netGross: number;
  totalExpenses: number;
  netProfit: number;
  artistTotalPayout: number;
  promoterProfit?: number;
  splitPoint?: number;
  backend?: number;
  artistBackend?: number;
  promoterBackend?: number;
  projections?: {
    capacity70: ProjectionResult;
    capacity85: ProjectionResult;
    capacity100: ProjectionResult;
  };
}

export interface ProjectionResult {
  tickets: number;
  grossPotential: number;
  netGross: number;
  artistPayout: number;
  promoterProfit: number;
  netProfit: number;
  splitPointHit: boolean;
}

export type OfferStatus = 'planning' | 'offer_sent' | 'confirmed' | 'active' | 'settled' | 'cancelled';

export interface SupportAct {
  name: string;
  type: 'dj' | 'band' | 'artist' | 'special_guest';
  guarantee: number;
  set_length: number;
  genre?: string;
  notes?: string;
}

export interface ScheduleItem {
  id: string;
  time: string;
  duration: number;
  title: string;
  category: 'production' | 'technical' | 'artist' | 'performance' | 'venue' | 'other';
  description: string;
  responsible: string;
}

export interface VenueContact {
  name: string;
  phone: string;
  email: string;
}

export interface RunOfShow {
  id: string;
  offer_id: string;
  event_date: string;
  venue_contact: VenueContact;
  schedule: ScheduleItem[];
  notes: string;
  created_at: string;
  updated_at?: string;
  user_id: string;
}

export interface Offer {
  id: string;
  show_id: string;
  mode: 'estimate' | 'settlement';
  status?: OfferStatus;
  event_type?: 'estimate' | 'budgeting' | 'active' | 'closeout';
  deal_type: 'flat_guarantee' | 'promoter_profit' | 'flat_fee' | 'guarantee_vs_percentage' | 'percentage_only' | 'door_deal';
  guarantee: number;
  artist_percentage?: number;
  promoter_profit?: number;
  artist_payout?: number;
  artist_backend_pct?: number;
  promoter_backend_pct?: number;
  tax_withholding_pct: number;
  deposit_pct: number;
  deposit_due_date?: string;
  deposit_due_timing?: string;
  venue_deposit?: number;
  venue_deposit_due_date?: string;
  venue_deposit_status?: 'pending' | 'paid' | 'refunded';
  venue_street?: string;
  venue_city?: string;
  venue_state?: string;
  venue_zip?: string;
  venue_full_address?: string;
  ticket_tiers: TicketTier[];
  sales_tax_pct: number;
  expenses: Expenses;
  calculations: Calculations;
  support_acts?: SupportAct[];
  facility_fee_per_ticket?: number;
  comps_artist?: number;
  comps_venue?: number;
  comps_promoter?: number;
  doors_time?: string;
  doors_duration?: number;
  show_time?: string;
  show_duration?: number;
  curfew_time?: string;
  age_limit?: string;
  merch_rate_soft?: number;
  merch_rate_hard?: number;
  artist_deductions?: any[];
  ascap_rate?: number;
  bmi_rate?: number;
  sesac_rate?: number;
  insurance_per_attendee?: number;
  cc_fee_rate?: number;
  offer_sent_date?: string;
  offer_expiration_date?: string;
  artist_photo_url?: string;
  holds?: string[];
  tour_id?: string;
  show_number?: number;
  created_at: string;
}

export type TourStatus = 'planning' | 'booking' | 'confirmed' | 'active' | 'completed' | 'cancelled';

export interface Tour {
  id: string;
  user_id: string;
  name: string;
  artist_name: string;
  start_date: string;
  end_date: string;
  description: string;
  status: TourStatus;
  projected_revenue: number;
  total_costs: number;
  net_profit: number;
  completed_count: number;
  settled_count: number;
  created_at: string;
  updated_at?: string;
}

export interface TourWithDates extends Tour {
  dates: TourDate[];
}

export interface TourDate {
  offer_id: string;
  event_date: string;
  venue_name: string;
  city: string;
  capacity: number;
  net_profit: number;
  status: string;
  show_number: number;
}

export interface OfferWithShow extends Offer {
  show: Show;
}

export interface CompanySettings {
  id: string;
  user_id?: string;
  company_name?: string;
  logo_url?: string;
  contact_name?: string;
  email?: string;
  phone?: string;
  website?: string;
  business_address?: string;
  legal_terms?: string;
  created_at?: string;
  updated_at?: string;
}

export interface TicketTierTemplate {
  type: string;
  price: number;
  default_allotment: number;
  default_comps: number;
}

export interface ExpenseCategoryTemplate {
  title: string;
  items: {
    name: string;
    default_amount: number;
  }[];
}

export interface Template {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  type: 'venue' | 'artist' | 'event';
  deal_type: 'flat_guarantee' | 'promoter_profit';
  deposit_pct: number;
  deposit_due_timing: string;
  tax_withholding_pct: number;
  sales_tax_pct: number;
  ticket_tier_templates: TicketTierTemplate[];
  expense_categories: ExpenseCategoryTemplate[];
  legal_terms?: string;
  created_at: string;
  updated_at?: string;
}
