import { MapPin } from 'lucide-react';

interface EventDetailsTabProps {
  eventName?: string;
  setEventName?: (value: string) => void;
  artistName: string;
  setArtistName: (value: string) => void;
  venueName: string;
  setVenueName: (value: string) => void;
  eventDate: string;
  setEventDate: (value: string) => void;
  capacity: number;
  setCapacity: (value: number) => void;
  mode: 'estimate' | 'settlement';
  venueStreet?: string;
  setVenueStreet?: (value: string) => void;
  venueCity?: string;
  setVenueCity?: (value: string) => void;
  venueState?: string;
  setVenueState?: (value: string) => void;
  venueZip?: string;
  setVenueZip?: (value: string) => void;
  facilityFeePerTicket?: number;
  setFacilityFeePerTicket?: (value: number) => void;
  ageLimit?: string;
  setAgeLimit?: (value: string) => void;
  doorsTime?: string;
  setDoorsTime?: (value: string) => void;
  doorsDuration?: number;
  setDoorsDuration?: (value: number) => void;
  showTime?: string;
  setShowTime?: (value: string) => void;
  showDuration?: number;
  setShowDuration?: (value: number) => void;
  curfewTime?: string;
  setCurfewTime?: (value: string) => void;
}

export function EventDetailsTab({
  eventName = '',
  setEventName = () => {},
  artistName,
  setArtistName,
  venueName,
  setVenueName,
  eventDate,
  setEventDate,
  capacity,
  setCapacity,
  mode,
  venueStreet = '',
  setVenueStreet = () => {},
  venueCity = '',
  setVenueCity = () => {},
  venueState = '',
  setVenueState = () => {},
  venueZip = '',
  setVenueZip = () => {},
  facilityFeePerTicket = 2.00,
  setFacilityFeePerTicket = () => {},
  ageLimit = 'All Ages',
  setAgeLimit = () => {},
  doorsTime = '20:00',
  setDoorsTime = () => {},
  doorsDuration = 60,
  setDoorsDuration = () => {},
  showTime = '21:00',
  setShowTime = () => {},
  showDuration = 240,
  setShowDuration = () => {},
  curfewTime = '01:00',
  setCurfewTime = () => {},
}: EventDetailsTabProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Event Information</h2>
        <p className="text-slate-600 mb-6">Enter the basic details for this show</p>
      </div>

      <div className="mb-6">
        <label className="block text-base font-semibold text-slate-700 mb-2">
          Event Name
        </label>
        <input
          type="text"
          value={eventName || ''}
          onChange={(e) => setEventName(e.target.value)}
          placeholder="e.g., Summer Festival 2024, Holiday Show (optional)"
          className="w-full px-4 py-3 text-lg border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
        />
        <p className="text-sm text-slate-500 mt-1">Optional - Give this event a custom name for easy identification</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-base font-semibold text-slate-700 mb-2">
            Artist Name *
          </label>
          <input
            type="text"
            value={artistName || ''}
            onChange={(e) => setArtistName(e.target.value)}
            placeholder="Enter artist name"
            className="w-full px-4 py-3 text-lg border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-base font-semibold text-slate-700 mb-2">
            Venue Name *
          </label>
          <input
            type="text"
            value={venueName || ''}
            onChange={(e) => setVenueName(e.target.value)}
            placeholder="Enter venue name"
            className="w-full px-4 py-3 text-lg border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-base font-semibold text-slate-700 mb-2">
            Event Date *
          </label>
          <input
            type="date"
            value={eventDate || ''}
            onChange={(e) => setEventDate(e.target.value)}
            className="w-full px-4 py-3 text-lg border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-base font-semibold text-slate-700 mb-2">
            Venue Capacity *
          </label>
          <input
            type="number"
            value={capacity || ''}
            onChange={(e) => setCapacity(Number(e.target.value))}
            placeholder="0"
            min="0"
            className="w-full px-4 py-3 text-lg border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
          />
        </div>
      </div>

      <div className="mt-6">
        <label className="block text-base font-semibold text-slate-700 mb-2">
          Venue Address *
        </label>
        <div className="space-y-4">
          <input
            type="text"
            value={venueStreet || ''}
            onChange={(e) => setVenueStreet(e.target.value)}
            placeholder="Street Address"
            className="w-full px-4 py-3 text-lg border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input
              type="text"
              value={venueCity || ''}
              onChange={(e) => setVenueCity(e.target.value)}
              placeholder="City"
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
            />
            <input
              type="text"
              value={venueState || ''}
              onChange={(e) => setVenueState(e.target.value)}
              placeholder="State"
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
            />
            <input
              type="text"
              value={venueZip || ''}
              onChange={(e) => setVenueZip(e.target.value)}
              placeholder="ZIP Code"
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent"
            />
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-600 bg-blue-50 border border-blue-200 rounded-lg p-3">
            <MapPin className="h-4 w-4 flex-shrink-0" />
            <span>This address will appear on offer PDFs and Run of Show documents</span>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-base font-semibold text-slate-700 mb-2">
            Facility Fee Per Ticket
          </label>
          <div className="flex items-center gap-2">
            <span className="text-slate-700">$</span>
            <input
              type="number"
              step="0.50"
              value={facilityFeePerTicket}
              onChange={(e) => setFacilityFeePerTicket(parseFloat(e.target.value))}
              className="flex-1 px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>
          <p className="text-xs text-slate-500 mt-1">Standard: $1.50-$3.00</p>
        </div>

        <div>
          <label className="block text-base font-semibold text-slate-700 mb-2">
            Age Limit
          </label>
          <select
            value={ageLimit}
            onChange={(e) => setAgeLimit(e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent"
          >
            <option>All Ages</option>
            <option>18+</option>
            <option>21+</option>
          </select>
        </div>
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h3 className="text-xl font-bold text-slate-900 mb-4">Show Schedule</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Doors Time</label>
            <input
              type="time"
              value={doorsTime}
              onChange={(e) => setDoorsTime(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Doors Duration (min)</label>
            <input
              type="number"
              value={doorsDuration}
              onChange={(e) => setDoorsDuration(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Show Time</label>
            <input
              type="time"
              value={showTime}
              onChange={(e) => setShowTime(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Show Duration (min)</label>
            <input
              type="number"
              value={showDuration}
              onChange={(e) => setShowDuration(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Curfew</label>
            <input
              type="time"
              value={curfewTime}
              onChange={(e) => setCurfewTime(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-800">
          <span className="font-semibold">Mode:</span> {mode === 'estimate' ? 'Estimate (Pre-Show)' : 'Settlement (Post-Show)'}
        </p>
      </div>
    </div>
  );
}
