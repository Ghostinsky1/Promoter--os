import { useNavigate } from 'react-router-dom';
import {
  CheckCircle2, X, FileText, DollarSign, Sparkles, Calendar,
  Upload, BarChart3, Clock, TrendingUp, Award, Target,
  Star, Music
} from 'lucide-react';

export function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0F1113]">
      <nav className="fixed top-0 w-full bg-[#1A1D1F]/95 backdrop-blur-lg border-b border-gray-800 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#C4FF0D] to-[#A3D60A] rounded-xl flex items-center justify-center">
              <span className="text-black font-bold text-xl">P</span>
            </div>
            <span className="text-2xl font-bold text-white">PromoterOS</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-[#A8B3B8] hover:text-[#C4FF0D] transition-colors">
              Features
            </a>
            <a href="#pricing" className="text-[#A8B3B8] hover:text-[#C4FF0D] transition-colors">
              Pricing
            </a>
            <button
              onClick={() => navigate('/login')}
              className="text-[#A8B3B8] hover:text-[#C4FF0D] transition-colors"
            >
              Login
            </button>
            <button
              onClick={() => navigate('/signup')}
              className="bg-[#C4FF0D] text-black hover:bg-[#A3D60A] font-semibold px-6 py-2 rounded-xl transition-colors"
            >
              Start Free Trial
            </button>
          </div>
        </div>
      </nav>

      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-block mb-6 px-6 py-3 bg-[#252A2E] rounded-full border border-gray-800">
              <span className="text-[#C4FF0D] font-semibold text-sm">
                Built By Promoters, For Promoters
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-white leading-tight">
              The Concert Promotion Software That Actually{' '}
              <span className="text-[#C4FF0D]">Makes You Money</span>
            </h1>

            <p className="text-xl text-[#A8B3B8] mb-10 max-w-3xl mx-auto leading-relaxed">
              Stop using spreadsheets. Start making more profit. PromoterOS helps you book more shows,
              track every dollar, and actually know if you're profitable.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <button
                onClick={() => navigate('/signup')}
                className="bg-[#C4FF0D] text-black hover:bg-[#A3D60A] text-lg px-10 py-7 rounded-2xl font-bold transition-colors"
              >
                Start Free Trial →
              </button>
              <button
                onClick={() => navigate('/login')}
                className="border-2 border-gray-700 text-white hover:bg-[#252A2E] text-lg px-10 py-7 rounded-2xl transition-colors"
              >
                See How It Works
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-[#A8B3B8]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-[#C4FF0D]" />
                <span>No credit card required</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-[#C4FF0D]" />
                <span>14-day free trial</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-[#C4FF0D]" />
                <span>Cancel anytime</span>
              </div>
            </div>
          </div>

          <div className="mt-20 relative">
            <div className="relative rounded-3xl overflow-hidden border-4 border-gray-800 shadow-2xl">
              <div className="aspect-video bg-[#1A1D1F] p-8">
                <div className="bg-[#252A2E] rounded-2xl shadow-xl p-8 border border-gray-800">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  </div>
                  <div className="space-y-4">
                    <div className="h-6 bg-gray-700 rounded-lg w-3/4"></div>
                    <div className="h-6 bg-gray-700 rounded-lg w-1/2"></div>
                    <div className="h-6 bg-[#C4FF0D]/20 rounded-lg w-2/3"></div>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute inset-0 bg-[#C4FF0D]/10 blur-3xl -z-10 rounded-full"></div>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-[#1A1D1F]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white">
              Sound Familiar?
            </h2>
            <p className="text-xl text-[#A8B3B8]">
              These are the problems every promoter faces
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-red-500/50 transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-red-500/10 rounded-xl">
                  <X className="h-6 w-6 text-red-500" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2 text-white">Spreadsheets Are a Nightmare</h3>
                  <p className="text-[#A8B3B8]">
                    Lost files, broken formulas, version confusion. Can't access on mobile when you need it.
                    No way to share with partners or artists.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-red-500/50 transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-red-500/10 rounded-xl">
                  <X className="h-6 w-6 text-red-500" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2 text-white">Never Know If You're Actually Profitable</h3>
                  <p className="text-[#A8B3B8]">
                    Can't track real numbers vs projections. Surprise expenses eat your profit.
                    No idea which venues or artists are worth it.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-red-500/50 transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-red-500/10 rounded-xl">
                  <X className="h-6 w-6 text-red-500" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2 text-white">Wasting Hours on Admin Work</h3>
                  <p className="text-[#A8B3B8]">
                    Manually creating offer sheets. Calculating break-even by hand.
                    Chasing down settlement numbers. No central place for everything.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-red-500/50 transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-red-500/10 rounded-xl">
                  <X className="h-6 w-6 text-red-500" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2 text-white">Missing Opportunities</h3>
                  <p className="text-[#A8B3B8]">
                    Can't quickly see available dates. No insights on what deals work.
                    Flying blind on pricing and deals.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-20 px-6 bg-[#0F1113]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white">
              Everything You Need to Run Your Business
            </h2>
            <p className="text-xl text-[#A8B3B8]">
              Professional tools that save you time and make you money
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-[#C4FF0D]/50 transition-all group">
              <div className="w-14 h-14 bg-[#C4FF0D]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#C4FF0D]/20 transition-colors">
                <FileText className="h-7 w-7 text-[#C4FF0D]" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-white">Professional Offer Creation</h3>
              <p className="text-[#A8B3B8] mb-6">
                Create industry-standard offers in 10 minutes. 4 deal structures, auto-calculated financials.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Flat Fee, Guarantee vs %, Percentage Only, Door Deal</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Break-even calculations per tier</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>All fees calculated automatically</span>
                </li>
              </ul>
            </div>

            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-[#C4FF0D]/50 transition-all group">
              <div className="w-14 h-14 bg-[#C4FF0D]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#C4FF0D]/20 transition-colors">
                <DollarSign className="h-7 w-7 text-[#C4FF0D]" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-white">Settlement Tracking</h3>
              <p className="text-[#A8B3B8] mb-6">
                Track actual numbers vs projections. See exactly where you made or lost money.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Actual vs projected comparison</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Variance analysis with indicators</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Learn from every show</span>
                </li>
              </ul>
            </div>

            <div className="p-8 bg-gradient-to-br from-[#C4FF0D]/10 to-[#C4FF0D]/5 border-2 border-[#C4FF0D]/50 rounded-2xl relative overflow-hidden">
              <div className="absolute top-4 right-4">
                <span className="px-3 py-1 bg-[#C4FF0D] text-black text-xs font-bold rounded-full">
                  TOUR PRO & UP
                </span>
              </div>
              <div className="w-14 h-14 bg-[#C4FF0D] rounded-xl flex items-center justify-center mb-6">
                <Sparkles className="h-7 w-7 text-black" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-white">AI-Powered Insights</h3>
              <p className="text-[#A8B3B8] mb-6">
                After 5+ shows, AI tells you which venues are profitable and scores every deal 0-100.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Venue performance rankings</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Deal Analyzer: STRONG BUY, PROCEED, CAUTION, PASS</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Smart recommendations before you book</span>
                </li>
              </ul>
            </div>

            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-[#C4FF0D]/50 transition-all group">
              <div className="w-14 h-14 bg-[#C4FF0D]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#C4FF0D]/20 transition-colors">
                <Calendar className="h-7 w-7 text-[#C4FF0D]" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-white">Tour Management</h3>
              <p className="text-[#A8B3B8] mb-6">
                Group shows into tours. Track total revenue, costs, and profit across markets.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Multi-show grouping</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Tour-level P&L tracking</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Average profit per show</span>
                </li>
              </ul>
            </div>

            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-[#C4FF0D]/50 transition-all group">
              <div className="w-14 h-14 bg-[#C4FF0D]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#C4FF0D]/20 transition-colors">
                <Upload className="h-7 w-7 text-[#C4FF0D]" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-white">Import From Anywhere</h3>
              <p className="text-[#A8B3B8] mb-6">
                Upload CSV, Excel, or PDF from Prism.fm. Auto-parse all data.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>CSV & Excel support</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Prism.fm PDF recognition</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>No re-entering data</span>
                </li>
              </ul>
            </div>

            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-[#C4FF0D]/50 transition-all group">
              <div className="w-14 h-14 bg-[#C4FF0D]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#C4FF0D]/20 transition-colors">
                <BarChart3 className="h-7 w-7 text-[#C4FF0D]" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-white">Dashboard & Analytics</h3>
              <p className="text-[#A8B3B8] mb-6">
                See all offers at a glance. Filter by status, venue, artist.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>All shows in one place</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Quick search and filter</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-[#A8B3B8]">
                  <CheckCircle2 className="h-4 w-4 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span>Mobile-friendly interface</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="pricing" className="py-20 px-6 bg-[#1A1D1F]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white">
              Choose the Plan That Matches Your Hustle
            </h2>
            <p className="text-xl text-[#A8B3B8] mb-2">
              Start with the basics, unlock AI when you're ready, scale when your roster blows up.
            </p>
            <p className="text-lg text-[#6B7280]">
              No long-term contracts. Upgrade or cancel anytime.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div className="p-8 bg-[#252A2E] border border-gray-800 rounded-2xl hover:border-gray-700 transition-all">
              <div className="mb-8">
                <h3 className="text-2xl font-bold mb-2 text-white">Starter</h3>
                <p className="text-[#A8B3B8] text-sm">
                  For independents running up to 10 shows at a time
                </p>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-6xl font-bold text-white">$49</span>
                  <span className="text-[#A8B3B8]">/ month</span>
                </div>
              </div>

              <button
                onClick={() => navigate('/signup')}
                className="w-full mb-8 bg-gray-700 hover:bg-gray-600 text-white py-6 rounded-xl font-semibold transition-colors"
              >
                Start with Starter
              </button>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-[#A8B3B8]">Up to 10 active events</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-[#A8B3B8]">1 seat (single user)</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-[#A8B3B8]">Full Offer Builder (all 4 deal structures)</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-[#A8B3B8]">Professional PDF generation</span>
                </div>
                <div className="flex items-start gap-3">
                  <X className="h-5 w-5 text-gray-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-gray-600">No AI tools</span>
                </div>
                <div className="flex items-start gap-3">
                  <X className="h-5 w-5 text-gray-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-gray-600">No Tour Management</span>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-800">
                <p className="text-xs font-semibold text-white mb-2">Perfect For:</p>
                <p className="text-xs text-[#A8B3B8]">
                  Independent promoters getting out of spreadsheets
                </p>
              </div>
            </div>

            <div className="p-8 bg-gradient-to-br from-[#C4FF0D]/20 to-[#C4FF0D]/5 border-2 border-[#C4FF0D] rounded-2xl relative transform scale-105 shadow-2xl shadow-[#C4FF0D]/20">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <div className="px-6 py-2 bg-[#C4FF0D] text-black rounded-full font-bold text-sm">
                  MOST POPULAR
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-2xl font-bold mb-2 text-white">Tour Pro</h3>
                <p className="text-[#A8B3B8] text-sm">
                  Unlimited offers, tours, and built-in AI deal intelligence
                </p>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-6xl font-bold text-[#C4FF0D]">$99</span>
                  <span className="text-[#A8B3B8]">/ month</span>
                </div>
              </div>

              <button
                onClick={() => navigate('/signup')}
                className="w-full mb-8 bg-[#C4FF0D] hover:bg-[#A3D60A] text-black py-6 rounded-xl font-bold transition-colors"
              >
                Upgrade to Tour Pro →
              </button>

              <div className="space-y-4">
                <p className="text-sm font-bold text-[#C4FF0D] mb-4">Everything in Starter, plus:</p>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-white font-semibold">Unlimited events & offers</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-white font-semibold">Unlimited tours</span>
                </div>
                <div className="flex items-start gap-3">
                  <Sparkles className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-white font-semibold">Tour Management tab</span>
                </div>
                <div className="flex items-start gap-3">
                  <Sparkles className="h-5 w-5 text-[#C4FF0D] mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-white font-semibold">AI Insights & Deal Analyzer</span>
                </div>
                <div className="pl-7 space-y-2 text-sm text-[#A8B3B8]">
                  <div>• Deals scored 0-100</div>
                  <div>• STRONG BUY / PROCEED / CAUTION / PASS</div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-gray-700">
                <p className="text-xs font-semibold text-white mb-2">Perfect For:</p>
                <p className="text-xs text-[#A8B3B8]">
                  Promoters running multiple shows who want AI to avoid bad deals
                </p>
              </div>
            </div>

            <div className="p-8 bg-[#252A2E]/50 border border-gray-800 rounded-2xl opacity-75">
              <div className="mb-8">
                <h3 className="text-2xl font-bold mb-2 text-white">Agency Scale</h3>
                <div className="inline-block px-3 py-1 bg-gray-700 rounded-full text-xs font-bold text-gray-400 mb-2">
                  COMING SOON
                </div>
                <p className="text-[#A8B3B8] text-sm">
                  For promotion companies running full rosters
                </p>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-6xl font-bold text-white">$297</span>
                  <span className="text-[#A8B3B8]">/ month</span>
                </div>
              </div>

              <button className="w-full mb-8 bg-gray-700 hover:bg-gray-600 text-white py-6 rounded-xl font-semibold transition-colors">
                Join Waitlist
              </button>

              <div className="space-y-4">
                <p className="text-sm font-bold text-gray-400 mb-4">Everything in Tour Pro, plus:</p>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-gray-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-gray-400">5+ seats (multi-user teams)</span>
                </div>
                <div className="flex items-start gap-3">
                  <Sparkles className="h-5 w-5 text-gray-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-gray-400">Advanced AI tools</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-gray-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-gray-400">Custom branding & white-label PDFs</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-6 bg-gradient-to-br from-[#C4FF0D] to-[#A3D60A]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-black">
            Ready to Stop Guessing and Start Profiting?
          </h2>
          <p className="text-xl mb-8 text-black/80">
            Join hundreds of promoters who ditched spreadsheets and started making more money.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <button
              onClick={() => navigate('/signup')}
              className="bg-black text-[#C4FF0D] hover:bg-gray-900 text-lg px-10 py-7 rounded-2xl font-bold transition-colors"
            >
              Start Free Trial - No Credit Card →
            </button>
            <button
              onClick={() => navigate('/login')}
              className="border-2 border-black text-black hover:bg-black/10 text-lg px-10 py-7 rounded-2xl font-bold transition-colors"
            >
              Book a Demo
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-black/70">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5" />
              <span>14-day free trial</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5" />
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5" />
              <span>Setup in 5 minutes</span>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-[#0F1113] border-t border-gray-800 py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-[#C4FF0D] to-[#A3D60A] rounded-lg flex items-center justify-center">
                  <span className="text-black font-bold">P</span>
                </div>
                <span className="text-xl font-bold text-white">PromoterOS</span>
              </div>
              <p className="text-sm text-[#A8B3B8]">
                Concert promotion software built by promoters, for promoters.
              </p>
            </div>

            <div>
              <h4 className="font-bold text-white mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-[#A8B3B8]">
                <li><a href="#features" className="hover:text-[#C4FF0D]">Features</a></li>
                <li><a href="#pricing" className="hover:text-[#C4FF0D]">Pricing</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-[#A8B3B8]">
                <li><a href="#" className="hover:text-[#C4FF0D]">About</a></li>
                <li><a href="#" className="hover:text-[#C4FF0D]">Contact</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-[#A8B3B8]">
                <li><a href="#" className="hover:text-[#C4FF0D]">Privacy</a></li>
                <li><a href="#" className="hover:text-[#C4FF0D]">Terms</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-sm text-[#6B7280]">
            <p>&copy; 2025 PromoterOS. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
