import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, MapPin, Calendar, DollarSign, Music2, TrendingUp } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Tour, TourWithDates } from '../types';
import { useAuth } from '../hooks/useAuth';
import { formatCurrency } from '../lib/calculations';

export function ToursPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [tours, setTours] = useState<TourWithDates[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadTours();
    }
  }, [user]);

  const loadTours = async () => {
    try {
      console.log('🔍 Loading tours...');

      if (!user) {
        console.log('⚠️ No user logged in');
        setTours([]);
        setLoading(false);
        return;
      }

      console.log('✅ User authenticated:', user.id);

      const { data: toursData, error: toursError } = await supabase
        .from('tours')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (toursError) {
        console.error('❌ Tours error:', toursError);
        throw toursError;
      }

      console.log('📊 Tours loaded:', toursData?.length || 0);

      if (toursData) {
        const toursWithDates = await Promise.all(
          toursData.map(async (tour) => {
            const { data: offers } = await supabase
              .from('offers')
              .select('*, show:shows(*)')
              .eq('tour_id', tour.id)
              .eq('user_id', user.id)
              .order('show_number', { ascending: true });

            const dates = offers?.map((offer: any) => ({
              offer_id: offer.id,
              event_date: offer.show.event_date,
              venue_name: offer.show.venue_name,
              city: offer.show.venue_name.split(',')[1]?.trim() || 'TBD',
              capacity: offer.show.capacity,
              net_profit: offer.calculations?.netProfit || 0,
              gross_potential: offer.calculations?.grossPotential || 0,
              total_expenses: offer.calculations?.totalExpenses || 0,
              status: offer.status || 'planning',
              show_number: offer.show_number || 0
            })) || [];

            const projected_revenue = dates.reduce((sum, d) => {
              const revenue = parseFloat(d.gross_potential) || 0;
              return sum + revenue;
            }, 0);

            const total_costs = dates.reduce((sum, d) => {
              const costs = parseFloat(d.total_expenses) || 0;
              return sum + costs;
            }, 0);

            const net_profit = dates.reduce((sum, d) => {
              const profit = parseFloat(d.net_profit) || 0;
              return sum + profit;
            }, 0);

            const settled_count = dates.filter(d => d.status === 'settled' || d.status === 'completed').length;

            console.log(`Tour: ${tour.name}`);
            console.log(`  Shows: ${dates.length}`);
            console.log(`  Revenue: ${projected_revenue}`);
            console.log(`  Costs: ${total_costs}`);
            console.log(`  Profit: ${net_profit}`);

            return {
              ...tour,
              dates,
              projected_revenue,
              total_costs,
              net_profit,
              settled_count
            };
          })
        );

        console.log('✅ Tours with dates loaded:', toursWithDates.length);
        setTours(toursWithDates);
      }
    } catch (error) {
      console.error('❌ Error loading tours:', error);
      setTours([]);
    } finally {
      setLoading(false);
    }
  };

  const calculateTotalProjectedProfit = () => {
    return tours.reduce((sum, tour) => sum + (tour.net_profit || 0), 0);
  };

  const getUniqueCities = () => {
    const cities = new Set<string>();
    tours.forEach(tour => {
      tour.dates?.forEach(date => cities.add(date.city));
    });
    return cities.size;
  };

  const getTotalShows = () => {
    return tours.reduce((sum, tour) => sum + (tour.dates?.length || 0), 0);
  };

  const getTourStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      planning: 'bg-slate-100 text-slate-700',
      booking: 'bg-blue-100 text-blue-700',
      confirmed: 'bg-green-100 text-green-700',
      active: 'bg-purple-100 text-purple-700',
      completed: 'bg-gray-100 text-gray-700',
      cancelled: 'bg-red-100 text-red-700'
    };
    return colors[status] || colors.planning;
  };

  const getTourProgress = (tour: TourWithDates) => {
    if (!tour.dates || tour.dates.length === 0) return 0;
    const completed = tour.dates.filter(d => d.status === 'settled' || d.status === 'completed').length;
    return Math.round((completed / tour.dates.length) * 100);
  };

  if (loading) {
    return <div className="min-h-screen bg-slate-50 flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Tours</h1>
              <p className="text-slate-600 mt-1">Manage multi-city tours and track performance</p>
            </div>
            <button
              onClick={() => navigate('/tours/create')}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
            >
              <Plus className="h-5 w-5" />
              Create Tour
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="p-4 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <Music2 className="h-8 w-8" />
              <div className="text-3xl font-bold">{tours.length}</div>
            </div>
            <div className="text-sm opacity-90">Active Tours</div>
          </div>

          <div className="p-4 bg-gradient-to-br from-blue-500 to-cyan-600 text-white rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="h-8 w-8" />
              <div className="text-3xl font-bold">{getTotalShows()}</div>
            </div>
            <div className="text-sm opacity-90">Total Shows</div>
          </div>

          <div className="p-4 bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="h-8 w-8" />
              <div className="text-3xl font-bold">
                ${Math.round(calculateTotalProjectedProfit() / 1000)}K
              </div>
            </div>
            <div className="text-sm opacity-90">Projected Profit</div>
          </div>

          <div className="p-4 bg-gradient-to-br from-orange-500 to-red-600 text-white rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <MapPin className="h-8 w-8" />
              <div className="text-3xl font-bold">{getUniqueCities()}</div>
            </div>
            <div className="text-sm opacity-90">Cities</div>
          </div>
        </div>

        {tours.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Music2 className="h-10 w-10 text-slate-400" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">No Tours Yet</h3>
            <p className="text-slate-600 mb-6">
              Create your first tour to manage multiple shows
            </p>
            <button
              onClick={() => navigate('/tours/create')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
            >
              <Plus className="h-5 w-5" />
              Create Tour
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {tours.map((tour) => (
              <div
                key={tour.id}
                className="bg-white border-2 border-slate-200 rounded-xl p-6 hover:shadow-xl hover:border-indigo-500 transition-all cursor-pointer"
                onClick={() => navigate(`/tours/${tour.id}`)}
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
                    {tour.artist_name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xl font-bold text-slate-900 mb-1 truncate">{tour.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Music2 className="h-4 w-4" />
                      <span>{tour.artist_name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-600 mt-1">
                      <Calendar className="h-4 w-4" />
                      <span>
                        {new Date(tour.start_date).toLocaleDateString()} - {new Date(tour.end_date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${getTourStatusColor(tour.status)}`}>
                    {tour.status}
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-3 mb-4">
                  <div className="bg-blue-50 rounded-lg p-3 text-center">
                    <div className="text-xl font-bold text-blue-600">
                      {tour.dates?.length || 0}
                    </div>
                    <div className="text-xs text-slate-600">Shows</div>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 text-center">
                    <div className="text-lg font-bold text-green-600">
                      ${Math.round((tour.projected_revenue || 0) / 1000)}K
                    </div>
                    <div className="text-xs text-slate-600">Revenue</div>
                  </div>
                  <div className="bg-orange-50 rounded-lg p-3 text-center">
                    <div className="text-lg font-bold text-orange-600">
                      ${Math.round((tour.total_costs || 0) / 1000)}K
                    </div>
                    <div className="text-xs text-slate-600">Costs</div>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-3 text-center">
                    <div className={`text-lg font-bold ${
                      (tour.net_profit || 0) >= 0 ? 'text-purple-600' : 'text-red-600'
                    }`}>
                      ${Math.round((tour.net_profit || 0) / 1000)}K
                    </div>
                    <div className="text-xs text-slate-600">Profit</div>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="flex justify-between text-xs text-slate-600 mb-1">
                    <span>Tour Progress</span>
                    <span>{getTourProgress(tour)}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-purple-600 transition-all"
                      style={{ width: `${getTourProgress(tour)}%` }}
                    />
                  </div>
                </div>

                {tour.dates && tour.dates.length > 0 && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    <span className="truncate">
                      {tour.dates.slice(0, 3).map(d => d.city).join(', ')}
                      {tour.dates.length > 3 && ` +${tour.dates.length - 3} more`}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
