import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, TrendingDown, DollarSign, Calendar, AlertCircle, Music2, MapPin, BarChart3, Bell, User } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { AIInsights } from './AIInsights';

interface DashboardStats {
  totalProfit: number;
  revenue: number;
  costs: number;
  margin: number;
  profitTrend: number;
  profitTrendPct: string;
  activeEvents: number;
  eventsToday: number;
  eventsWeek: number;
  eventsMonth: number;
  forecastRevenue: number;
  activeTours: number;
  totalShows: number;
  upcomingShows: number;
  completedShows: number;
  totalLosses: number;
  projectedProfit: number;
  healthScore: number;
}

export function Home() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [viewMode, setViewMode] = useState<'overview' | 'projections'>('overview');
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadDashboardStats();
    }
  }, [user, timeRange]);

  const loadDashboardStats = async () => {
    try {
      const { data: offers } = await supabase
        .from('offers')
        .select('*, show:shows(*)')
        .order('created_at', { ascending: false });

      const { data: tours } = await supabase
        .from('tours')
        .select('*');

      if (offers) {
        const totalRevenue = offers.reduce((sum, o) => sum + (o.calculations?.netGross || 0), 0);
        const totalCosts = offers.reduce((sum, o) => sum + (o.calculations?.totalExpenses || 0), 0);
        const totalProfit = offers.reduce((sum, o) => sum + (o.calculations?.netProfit || 0), 0);

        const today = new Date();
        const activeEvents = offers.filter(o =>
          new Date(o.show.event_date) >= today && o.status !== 'cancelled'
        ).length;

        const upcomingOffers = offers.filter(o => new Date(o.show.event_date) > today);
        const projectedProfit = upcomingOffers.reduce((sum, o) => sum + (o.calculations?.netProfit || 0), 0);

        const losses = offers.filter(o => (o.calculations?.netProfit || 0) < 0);
        const totalLosses = losses.reduce((sum, o) => sum + Math.abs(o.calculations?.netProfit || 0), 0);

        setStats({
          totalProfit,
          revenue: totalRevenue,
          costs: totalCosts,
          margin: totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100) : 0,
          profitTrend: totalProfit,
          profitTrendPct: '12.5',
          activeEvents,
          eventsToday: offers.filter(o => {
            const eventDate = new Date(o.show.event_date);
            return eventDate.toDateString() === today.toDateString();
          }).length,
          eventsWeek: offers.filter(o => {
            const eventDate = new Date(o.show.event_date);
            const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
            return eventDate >= today && eventDate <= weekFromNow;
          }).length,
          eventsMonth: offers.filter(o => {
            const eventDate = new Date(o.show.event_date);
            return eventDate.getMonth() === today.getMonth() && eventDate.getFullYear() === today.getFullYear();
          }).length,
          forecastRevenue: upcomingOffers.reduce((sum, o) => sum + (o.calculations?.grossPotential || 0), 0),
          activeTours: tours?.filter(t => t.status === 'active').length || 0,
          totalShows: offers.length,
          upcomingShows: upcomingOffers.length,
          completedShows: offers.filter(o => o.status === 'settled').length,
          totalLosses,
          projectedProfit,
          healthScore: Math.min(100, Math.max(0, 70 + (totalProfit / 10000)))
        });
      }
    } catch (error) {
      console.error('Error loading dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen bg-[#0F1113] text-white flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-[#0F1113] text-white">
      <div className="px-4 sm:px-6 py-6 sm:py-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-[#C4FF0D] to-[#A3D60A] rounded-2xl flex items-center justify-center">
                <span className="text-black font-bold text-xl">P</span>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Welcome back,</p>
                <h1 className="text-2xl font-bold text-white">{user?.email?.split('@')[0] || 'User'}</h1>
              </div>
            </div>

            <button className="w-10 h-10 rounded-full bg-[#1A1F1E] hover:bg-[#252A29] border border-gray-800 flex items-center justify-center transition-colors">
              <Bell className="h-5 w-5 text-gray-400" />
            </button>
          </div>

          <div className="flex items-center gap-3 mb-8">
            <button
              onClick={() => setViewMode('overview')}
              className={`px-6 py-2 rounded-full font-bold transition-all text-sm sm:text-base ${
                viewMode === 'overview'
                  ? 'bg-[#C4FF0D] text-black'
                  : 'text-gray-400 hover:text-white hover:bg-[#1A1F1E]'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setViewMode('projections')}
              className={`px-6 py-2 rounded-full font-bold transition-all text-sm sm:text-base ${
                viewMode === 'projections'
                  ? 'bg-[#C4FF0D] text-black'
                  : 'text-gray-400 hover:text-white hover:bg-[#1A1F1E]'
              }`}
            >
              Projections
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-6">
            <button
              onClick={() => navigate('/offers/create')}
              className="group bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 rounded-3xl p-3 sm:p-8 text-left transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <div className="text-[10px] sm:text-sm opacity-90 mb-0.5 sm:mb-2">Quick Action</div>
              <div className="text-base sm:text-2xl font-bold mb-0.5 sm:mb-2">Create New Offer</div>
              <div className="text-[10px] sm:text-sm opacity-75">Start a new event estimate</div>
            </button>

            <button
              onClick={() => navigate('/tours')}
              className="group bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 rounded-3xl p-3 sm:p-8 text-left transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <div className="text-[10px] sm:text-sm opacity-90 mb-0.5 sm:mb-2">Quick Action</div>
              <div className="text-base sm:text-2xl font-bold mb-0.5 sm:mb-2">View Tours</div>
              <div className="text-[10px] sm:text-sm opacity-75">Manage multi-city tours</div>
            </button>

            <button
              onClick={() => navigate('/offers')}
              className="group bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 rounded-3xl p-3 sm:p-8 text-left transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <div className="text-[10px] sm:text-sm opacity-90 mb-0.5 sm:mb-2">Quick Action</div>
              <div className="text-base sm:text-2xl font-bold mb-0.5 sm:mb-2">All Offers</div>
              <div className="text-[10px] sm:text-sm opacity-75">Browse all events</div>
            </button>
          </div>

          <div className="flex items-center gap-3 mb-8">
            {['week', 'month', 'year'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range as any)}
                className={`flex-1 sm:flex-none px-6 py-2 rounded-full font-semibold transition-all text-xs sm:text-sm ${
                  timeRange === range
                    ? 'bg-[#C4FF0D] text-black'
                    : 'bg-[#1A1F1E] text-gray-400 hover:bg-[#252A29] hover:text-white border border-gray-800'
                }`}
              >
                {range.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 sm:px-6 pb-12">
        <div className="max-w-7xl mx-auto">
          {viewMode === 'overview' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              <div className="lg:col-span-2 bg-[#F5F5DC] rounded-3xl p-6 sm:p-8 shadow-2xl text-black relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30"></div>

                <div className="relative z-10">
                  <div className="text-sm text-gray-600 mb-2">Total Profit</div>
                  <div className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-4 text-purple-600">
                    ${Math.round((stats?.totalProfit || 0) / 1000)}K
                  </div>

                  <div className="flex items-center gap-2 mb-6">
                    <div className="flex items-center gap-2">
                      {(stats?.profitTrend || 0) >= 0 ? (
                        <>
                          <TrendingUp className="h-6 w-6 text-green-600" />
                          <span className="text-2xl font-bold text-green-600">
                            +{stats?.profitTrendPct}%
                          </span>
                        </>
                      ) : (
                        <>
                          <TrendingDown className="h-6 w-6 text-red-600" />
                          <span className="text-2xl font-bold text-red-600">
                            {stats?.profitTrendPct}%
                          </span>
                        </>
                      )}
                    </div>
                    <span className="text-gray-600">vs last {timeRange}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-white/50 border border-gray-300 rounded-xl p-4">
                      <div className="text-xs text-gray-600 mb-1">Revenue</div>
                      <div className="text-xl font-bold">${Math.round((stats?.revenue || 0) / 1000)}K</div>
                    </div>
                    <div className="bg-white/50 border border-gray-300 rounded-xl p-4">
                      <div className="text-xs text-gray-600 mb-1">Costs</div>
                      <div className="text-xl font-bold">${Math.round((stats?.costs || 0) / 1000)}K</div>
                    </div>
                    <div className="bg-white/50 border border-gray-300 rounded-xl p-4">
                      <div className="text-xs text-gray-600 mb-1">Margin</div>
                      <div className="text-xl font-bold">{Math.round(stats?.margin || 0)}%</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#1A1F1E] border border-gray-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
                <div className="text-sm text-gray-400 mb-2">Active Events</div>
                <div className="text-5xl sm:text-6xl font-bold mb-6">{stats?.activeEvents || 0}</div>

                <div className="relative h-32 mb-6 flex items-center justify-center">
                  <div className="absolute w-24 h-24 bg-gradient-to-br from-orange-500 to-orange-400 rounded-full animate-pulse shadow-2xl shadow-orange-500/50"></div>
                  <div className="absolute w-24 h-24 bg-gradient-to-br from-orange-500/30 to-orange-400/30 rounded-full animate-ping"></div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Today</span>
                    <span className="font-bold">{stats?.eventsToday || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">This Week</span>
                    <span className="font-bold">{stats?.eventsWeek || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">This Month</span>
                    <span className="font-bold">{stats?.eventsMonth || 0}</span>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-600 to-cyan-500 rounded-3xl p-6 sm:p-8 shadow-2xl text-white">
                <div className="text-sm opacity-90 mb-2">Revenue Forecast</div>
                <div className="text-4xl sm:text-5xl font-bold mb-4">
                  ${Math.round((stats?.forecastRevenue || 0) / 1000)}K
                </div>

                <div className="relative h-32 mb-4 flex items-end justify-around">
                  {[30, 50, 45, 70, 60].map((height, i) => (
                    <div
                      key={i}
                      className="bg-white/20 rounded-t-lg animate-pulse"
                      style={{
                        width: '15%',
                        height: `${height}%`,
                        animationDelay: `${i * 0.2}s`
                      }}
                    />
                  ))}
                </div>

                <div className="text-sm opacity-90">Next 30 days projection</div>
              </div>

              <div className="bg-[#F5F5DC] rounded-3xl p-6 sm:p-8 shadow-2xl text-black">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                    {stats?.activeTours || 0}
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Active Tours</div>
                    <div className="text-2xl font-bold">{stats?.totalShows || 0} Shows</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="bg-white/50 border border-gray-300 rounded-lg p-3">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-semibold">Upcoming</span>
                      <span className="font-bold">{stats?.upcomingShows || 0}</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-purple-400"
                        style={{ width: `${((stats?.upcomingShows || 0) / (stats?.totalShows || 1)) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div className="bg-white/50 border border-gray-300 rounded-lg p-3">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-semibold">Completed</span>
                      <span className="font-bold text-green-600">{stats?.completedShows || 0}</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-green-500"
                        style={{ width: `${((stats?.completedShows || 0) / (stats?.totalShows || 1)) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#1A1F1E] border-2 border-orange-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <AlertCircle className="h-8 w-8 text-orange-500" />
                  <div>
                    <div className="text-sm text-gray-400">Total Losses</div>
                    <div className="text-4xl font-bold text-orange-500">
                      ${Math.round((stats?.totalLosses || 0) / 1000)}K
                    </div>
                  </div>
                </div>

                {(stats?.totalLosses || 0) > 10000 && (
                  <div className="mt-4 p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg">
                    <div className="text-xs text-orange-300">
                      High loss rate detected. Review underperforming events.
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
              <div className="lg:col-span-2 bg-[#1A1F1E] border border-gray-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
                <h3 className="text-xl sm:text-2xl font-bold mb-2">Profit Projection</h3>
                <p className="text-gray-400 text-sm mb-6">Next {timeRange} forecast</p>

                <div className="text-center mb-8">
                  <div className="text-5xl sm:text-6xl lg:text-7xl font-bold text-green-400 mb-2">
                    ${Math.round((stats?.projectedProfit || 0) / 1000)}K
                  </div>
                  <div className="text-sm text-gray-400">Expected profit from upcoming events</div>
                </div>

                <div className="mb-6">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Confidence Level</span>
                    <span className="font-bold text-green-400">85%</span>
                  </div>
                  <div className="w-full h-3 bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-500 to-emerald-400 transition-all duration-1000"
                      style={{ width: '85%' }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-gray-800/50 rounded-xl p-4 text-center border border-gray-700">
                    <div className="text-xs text-gray-400 mb-2">Best Case</div>
                    <div className="text-2xl font-bold text-green-400">
                      +${Math.round(((stats?.projectedProfit || 0) * 1.3) / 1000)}K
                    </div>
                  </div>
                  <div className="bg-gray-800/50 rounded-xl p-4 text-center border-2 border-green-500">
                    <div className="text-xs text-gray-400 mb-2">Expected</div>
                    <div className="text-2xl font-bold text-green-400">
                      +${Math.round((stats?.projectedProfit || 0) / 1000)}K
                    </div>
                  </div>
                  <div className="bg-gray-800/50 rounded-xl p-4 text-center border border-gray-700">
                    <div className="text-xs text-gray-400 mb-2">Worst Case</div>
                    <div className="text-2xl font-bold text-orange-400">
                      +${Math.round(((stats?.projectedProfit || 0) * 0.7) / 1000)}K
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4 sm:space-y-6">
                <div className="bg-[#F5F5DC] rounded-3xl p-6 shadow-2xl text-black">
                  <div className="text-sm text-gray-600 mb-2">Company Health</div>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="relative w-24 h-24">
                      <svg viewBox="0 0 100 100" className="transform -rotate-90">
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke="#e5e7eb"
                          strokeWidth="8"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke="#22c55e"
                          strokeWidth="8"
                          strokeDasharray={`${((stats?.healthScore || 0) / 100) * 251} 251`}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-2xl font-bold">{Math.round(stats?.healthScore || 0)}</div>
                      </div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-green-600">HEALTHY</div>
                      <div className="text-sm text-gray-600">Company Score</div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-3xl p-6 shadow-2xl text-white">
                  <div className="text-sm opacity-90 mb-2">Upcoming Revenue</div>
                  <div className="text-4xl font-bold mb-4">
                    ${Math.round((stats?.forecastRevenue || 0) / 1000)}K
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="opacity-90">Next 30 days</span>
                      <span className="font-bold">${Math.round((stats?.forecastRevenue || 0) / 3000)}K</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="opacity-90">Next 90 days</span>
                      <span className="font-bold">${Math.round((stats?.forecastRevenue || 0) / 1000)}K</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="mt-8">
            <AIInsights />
          </div>
        </div>
      </div>
    </div>
  );
}
