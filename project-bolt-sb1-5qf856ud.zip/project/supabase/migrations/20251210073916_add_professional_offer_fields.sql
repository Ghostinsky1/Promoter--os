/*
  # Add Professional Offer Fields

  1. New Columns Added to `offers` table:
    - `facility_fee_per_ticket` (decimal) - Fee per ticket, default $2.00
    - `comps_artist` (integer) - Artist complimentary tickets
    - `comps_venue` (integer) - Venue complimentary tickets
    - `comps_promoter` (integer) - Promoter complimentary tickets
    - `doors_time` (text) - Time doors open
    - `doors_duration` (integer) - Duration doors are open in minutes
    - `show_time` (text) - Show start time
    - `show_duration` (integer) - Show duration in minutes
    - `curfew_time` (text) - Venue curfew time
    - `age_limit` (text) - Age restriction (All Ages, 18+, 21+)
    - `merch_rate_soft` (integer) - Percentage of soft merch artist keeps
    - `merch_rate_hard` (integer) - Percentage of hard merch artist keeps
    - `artist_deductions` (jsonb) - Equipment costs deducted from artist
    - `ascap_rate` (decimal) - ASCAP licensing rate percentage
    - `bmi_rate` (decimal) - BMI licensing rate percentage
    - `sesac_rate` (decimal) - SESAC licensing rate percentage
    - `insurance_per_attendee` (decimal) - Insurance cost per attendee
    - `cc_fee_rate` (decimal) - Credit card processing fee percentage

  2. Purpose:
    - Capture comprehensive professional concert booking details
    - Enable accurate financial modeling with variable expenses
    - Track complimentary ticket distribution
    - Document show schedule and timing requirements
*/

-- Add facility fee
ALTER TABLE offers ADD COLUMN IF NOT EXISTS facility_fee_per_ticket DECIMAL DEFAULT 2.00;

-- Add complimentary tickets
ALTER TABLE offers ADD COLUMN IF NOT EXISTS comps_artist INTEGER DEFAULT 0;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS comps_venue INTEGER DEFAULT 0;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS comps_promoter INTEGER DEFAULT 0;

-- Add show schedule fields
ALTER TABLE offers ADD COLUMN IF NOT EXISTS doors_time TEXT;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS doors_duration INTEGER DEFAULT 60;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS show_time TEXT;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS show_duration INTEGER DEFAULT 240;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS curfew_time TEXT;

-- Add age limit
ALTER TABLE offers ADD COLUMN IF NOT EXISTS age_limit TEXT DEFAULT 'All Ages';

-- Add merchandise rates
ALTER TABLE offers ADD COLUMN IF NOT EXISTS merch_rate_soft INTEGER DEFAULT 100;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS merch_rate_hard INTEGER DEFAULT 100;

-- Add artist deductions
ALTER TABLE offers ADD COLUMN IF NOT EXISTS artist_deductions JSONB DEFAULT '[]';

-- Add variable expense rates
ALTER TABLE offers ADD COLUMN IF NOT EXISTS ascap_rate DECIMAL DEFAULT 0.0023;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS bmi_rate DECIMAL DEFAULT 0.003;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS sesac_rate DECIMAL DEFAULT 0.000214;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS insurance_per_attendee DECIMAL DEFAULT 0.62;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS cc_fee_rate DECIMAL DEFAULT 0.012;
