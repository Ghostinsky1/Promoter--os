/*
  # Add Event Types, Deposits, and Company Settings

  ## New Features
  1. Event Types (estimate, budgeting, active, closeout)
  2. Deposit tracking with due dates
  3. Venue deposit management
  4. Company branding settings

  ## Changes to offers table
  - Add event_type field
  - Add deposit_due_date and deposit_due_timing fields
  - Add venue deposit tracking fields

  ## New Tables
  - company_settings for branding and company info

  ## Security
  - Enable RLS on company_settings
  - Add policies for authenticated users
*/

-- Add new columns to offers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'event_type'
  ) THEN
    ALTER TABLE offers ADD COLUMN event_type text DEFAULT 'estimate';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'deposit_due_date'
  ) THEN
    ALTER TABLE offers ADD COLUMN deposit_due_date text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'deposit_due_timing'
  ) THEN
    ALTER TABLE offers ADD COLUMN deposit_due_timing text DEFAULT '30_days_before';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_deposit'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_deposit real DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_deposit_due_date'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_deposit_due_date text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_deposit_status'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_deposit_status text DEFAULT 'pending';
  END IF;
END $$;

-- Create company_settings table
CREATE TABLE IF NOT EXISTS company_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text,
  company_name text,
  logo_url text,
  contact_name text,
  email text,
  phone text,
  website text,
  business_address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on company_settings
ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view own company settings" ON company_settings;
DROP POLICY IF EXISTS "Users can insert own company settings" ON company_settings;
DROP POLICY IF EXISTS "Users can update own company settings" ON company_settings;
DROP POLICY IF EXISTS "Users can delete own company settings" ON company_settings;

-- Policies for company_settings
CREATE POLICY "Users can view own company settings"
  ON company_settings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own company settings"
  ON company_settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update own company settings"
  ON company_settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete own company settings"
  ON company_settings FOR DELETE
  TO authenticated
  USING (true);
