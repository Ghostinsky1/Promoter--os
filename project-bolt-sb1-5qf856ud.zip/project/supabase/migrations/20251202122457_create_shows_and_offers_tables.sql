/*
  # Concert Promoter Offer System - Database Schema

  ## Overview
  Creates the database structure for managing concert offers with estimate and settlement tracking.

  ## New Tables

  ### `shows`
  Core event information that doesn't change between estimate and settlement.
  - `id` (text, primary key) - Unique show identifier
  - `artist_name` (text) - Name of performing artist
  - `venue_name` (text) - Venue location
  - `event_date` (text) - Date of show (ISO format)
  - `capacity` (integer) - Total venue capacity
  - `created_at` (timestamptz) - Record creation timestamp

  ### `offers`
  Deal terms, financials, and calculations for both estimates and settlements.
  - `id` (text, primary key) - Unique offer identifier
  - `show_id` (text, foreign key) - Links to shows table
  - `mode` (text) - Either 'estimate' or 'settlement'
  - `deal_type` (text) - Either 'flat_guarantee' or 'promoter_profit'
  - `guarantee` (numeric) - Artist guarantee amount
  - `tax_withholding_pct` (numeric) - Tax withholding percentage
  - `deposit_pct` (numeric) - Deposit percentage (due 30 days before)
  - `ticket_tiers` (jsonb) - Array of ticket tier objects with allotment, comps, price, actualSold
  - `sales_tax_pct` (numeric) - Sales tax percentage
  - `expenses` (jsonb) - Nested object with 4 categories (talent, general, marketing, production)
  - `calculations` (jsonb) - All calculated values (gross, net, profit, backend splits, projections)
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - Enable RLS on both tables
  - For MVP: Allow all operations (auth will be added post-MVP)

  ## Notes
  - Estimates and settlements are separate records linked by show_id
  - ticket_tiers uses jsonb for flexible tier structure
  - expenses uses jsonb for nested category structure
  - calculations stores all computed values for historical reference
*/

-- Create shows table
CREATE TABLE IF NOT EXISTS shows (
  id text PRIMARY KEY,
  artist_name text NOT NULL,
  venue_name text NOT NULL,
  event_date text NOT NULL,
  capacity integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create offers table
CREATE TABLE IF NOT EXISTS offers (
  id text PRIMARY KEY,
  show_id text NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
  mode text NOT NULL CHECK (mode IN ('estimate', 'settlement')),
  deal_type text NOT NULL CHECK (deal_type IN ('flat_guarantee', 'promoter_profit')),
  guarantee numeric NOT NULL,
  tax_withholding_pct numeric NOT NULL DEFAULT 0,
  deposit_pct numeric NOT NULL DEFAULT 0,
  ticket_tiers jsonb NOT NULL DEFAULT '[]'::jsonb,
  sales_tax_pct numeric NOT NULL DEFAULT 0,
  expenses jsonb NOT NULL DEFAULT '{}'::jsonb,
  calculations jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create index for faster lookups by show_id
CREATE INDEX IF NOT EXISTS idx_offers_show_id ON offers(show_id);

-- Enable RLS
ALTER TABLE shows ENABLE ROW LEVEL SECURITY;
ALTER TABLE offers ENABLE ROW LEVEL SECURITY;

-- MVP policies: Allow all operations (will be restricted when auth is added)
CREATE POLICY "Allow all operations on shows"
  ON shows
  FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on offers"
  ON offers
  FOR ALL
  USING (true)
  WITH CHECK (true);
