/*
  # Add Venue Address Fields to Offers

  1. New Columns
    - `venue_street` (text) - Street address of venue
    - `venue_city` (text) - City
    - `venue_state` (text) - State/Province
    - `venue_zip` (text) - ZIP/Postal code
    - `venue_full_address` (text) - Computed full address for display
  
  2. Notes
    - These fields will appear on offer PDFs and Run of Show documents
    - venue_full_address will be populated by application code
*/

-- Add venue address fields to offers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_street'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_street text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_city'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_city text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_state'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_state text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_zip'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_zip text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'venue_full_address'
  ) THEN
    ALTER TABLE offers ADD COLUMN venue_full_address text;
  END IF;
END $$;