import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Calendar, MapPin, DollarSign, FileText, Plus } from 'lucide-react';
import { OfferWithShow, OfferStatus } from '../types';
import { formatCurrency } from '../lib/calculations';
import { parseLocalDate } from '../lib/dateHelpers';

interface OffersCalendarProps {
  offers: OfferWithShow[];
}

const STATUS_COLORS: Record<OfferStatus, string> = {
  planning: 'from-blue-500 to-cyan-500',
  offer_sent: 'from-purple-500 to-pink-500',
  confirmed: 'from-green-500 to-emerald-500',
  active: 'from-orange-500 to-amber-500',
  settled: 'from-teal-500 to-cyan-500',
  cancelled: 'from-red-500 to-rose-500'
};

const STATUS_BADGES: Record<OfferStatus, { label: string; color: string }> = {
  planning: { label: 'Planning', color: 'bg-blue-100 text-blue-800' },
  offer_sent: { label: 'Offer Sent', color: 'bg-purple-100 text-purple-800' },
  confirmed: { label: 'Confirmed', color: 'bg-green-100 text-green-800' },
  active: { label: 'Active', color: 'bg-orange-100 text-orange-800' },
  settled: { label: 'Settled', color: 'bg-teal-100 text-teal-800' },
  cancelled: { label: 'Cancelled', color: 'bg-red-100 text-red-800' }
};

export function OffersCalendar({ offers }: OffersCalendarProps) {
  const navigate = useNavigate();
  const [currentDate, setCurrentDate] = useState(new Date());

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    return { daysInMonth, startingDayOfWeek, year, month };
  };

  const { daysInMonth, startingDayOfWeek, year, month } = getDaysInMonth(currentDate);

  const getOffersForDay = (day: number) => {
    return offers.filter(offer => {
      const offerDate = parseLocalDate(offer.show.event_date);
      if (!offerDate) return false;
      return (
        offerDate.getFullYear() === year &&
        offerDate.getMonth() === month &&
        offerDate.getDate() === day
      );
    });
  };

  const getOffersInMonth = () => {
    return offers.filter(offer => {
      const offerDate = parseLocalDate(offer.show.event_date);
      if (!offerDate) return false;
      return (
        offerDate.getFullYear() === year &&
        offerDate.getMonth() === month
      );
    });
  };

  const previousMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const today = () => {
    setCurrentDate(new Date());
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const monthOffers = getOffersInMonth();

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border-2 border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold">
              {monthNames[month]} {year}
            </h2>

            <div className="flex items-center gap-2">
              <button
                onClick={today}
                className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur px-4 py-2 rounded-lg font-medium transition-colors"
              >
                Today
              </button>

              <div className="flex items-center gap-1 bg-white/20 rounded-lg p-1">
                <button
                  onClick={previousMonth}
                  className="text-white hover:bg-white/20 p-2 rounded-md transition-colors"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  onClick={nextMonth}
                  className="text-white hover:bg-white/20 p-2 rounded-md transition-colors"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {dayNames.map(day => (
              <div key={day} className="text-center font-semibold py-2 opacity-90">
                {day}
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 bg-slate-50">
          <div className="grid grid-cols-7 gap-3">
            {Array.from({ length: startingDayOfWeek }).map((_, index) => (
              <div key={`empty-${index}`} className="aspect-square" />
            ))}

            {Array.from({ length: daysInMonth }).map((_, index) => {
              const day = index + 1;
              const dayOffers = getOffersForDay(day);
              const todayDate = new Date();
              const isToday =
                todayDate.getFullYear() === year &&
                todayDate.getMonth() === month &&
                todayDate.getDate() === day;

              return (
                <div
                  key={day}
                  className={`aspect-square border-2 rounded-xl p-2 transition-all bg-white ${
                    isToday
                      ? 'border-blue-600 shadow-lg ring-2 ring-blue-200'
                      : dayOffers.length > 0
                      ? 'border-slate-200 hover:border-blue-400 hover:shadow-md cursor-pointer'
                      : 'border-slate-100'
                  }`}
                >
                  <div className="flex flex-col h-full">
                    <div className={`text-sm font-bold mb-1 ${
                      isToday
                        ? 'text-blue-600'
                        : dayOffers.length > 0
                        ? 'text-slate-900'
                        : 'text-slate-400'
                    }`}>
                      {day}
                    </div>

                    <div className="flex-1 flex flex-col gap-1 overflow-hidden">
                      {dayOffers.slice(0, 2).map((offer, i) => {
                        const status = (offer.status || 'planning') as OfferStatus;
                        return (
                          <div
                            key={i}
                            className={`text-xs px-2 py-1 rounded-md bg-gradient-to-r ${STATUS_COLORS[status]} text-white truncate font-semibold cursor-pointer hover:scale-105 transition-transform`}
                            onClick={() => navigate(`/offers/${offer.id}`)}
                            title={`${offer.show.artist_name} at ${offer.show.venue_name}`}
                          >
                            {offer.show.artist_name}
                          </div>
                        );
                      })}
                      {dayOffers.length > 2 && (
                        <div className="text-xs text-blue-600 font-bold px-2">
                          +{dayOffers.length - 2} more
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {monthOffers.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-slate-900">
              Offers This Month ({monthOffers.length})
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {monthOffers
              .sort((a, b) => {
                const dateA = parseLocalDate(a.show.event_date);
                const dateB = parseLocalDate(b.show.event_date);
                if (!dateA || !dateB) return 0;
                return dateA.getTime() - dateB.getTime();
              })
              .map((offer) => {
                const status = (offer.status || 'planning') as OfferStatus;
                const statusBadge = STATUS_BADGES[status];
                const offerDate = parseLocalDate(offer.show.event_date);
                const dateDisplay = offerDate ? offerDate.toLocaleDateString('en-US', {
                  weekday: 'short',
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                }) : 'Invalid date';
                return (
                  <div
                    key={offer.id}
                    className="border-2 border-slate-200 rounded-lg p-4 hover:shadow-lg transition-all cursor-pointer border-l-4 border-l-blue-500"
                    onClick={() => navigate(`/offers/${offer.id}`)}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-lg mb-1 truncate">{offer.show.artist_name}</h4>
                        <div className="flex items-center gap-2 text-sm text-slate-600 mb-1">
                          <Calendar className="h-4 w-4 flex-shrink-0" />
                          <span>{dateDisplay}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-600">
                          <MapPin className="h-4 w-4 flex-shrink-0" />
                          <span className="truncate">{offer.show.venue_name}</span>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusBadge.color}`}>
                        {statusBadge.label}
                      </span>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                      <div className="text-sm text-slate-600">Net Profit</div>
                      <div className={`text-xl font-bold ${
                        offer.calculations.netProfit >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {formatCurrency(offer.calculations.netProfit)}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {monthOffers.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="h-10 w-10 text-slate-400" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">No Offers in {monthNames[month]}</h3>
          <p className="text-slate-600 mb-6">Create your first offer for this month</p>
          <button
            onClick={() => navigate('/offers/create')}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:shadow-lg transition-all inline-flex items-center gap-2"
          >
            <Plus className="h-5 w-5" />
            Create Offer
          </button>
        </div>
      )}
    </div>
  );
}
