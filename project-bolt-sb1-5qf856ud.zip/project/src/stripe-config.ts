export const STRIPE_PRODUCTS = [
  {
    id: 'prod_TWz6FttdA8zmct',
    priceId: 'price_1SZv8NK0rX2Uf9BVDhRmDFcN',
    name: 'Offer generator',
    description: 'For independents running up to 10 shows at a time',
    price: 39.00,
    currency: 'usd',
    mode: 'subscription' as const,
    features: [
      'Up to 10 active events (offers + shows)',
      '1 seat (single user)',
      'Full Offer Builder (all 4 deal structures)',
      'Professional PDF generation',
      'Settlement tracking (actual vs projected)',
      'Calendar view',
      'Venue & artist database',
      'Expense templates',
      'Import from spreadsheets/Prism'
    ]
  },
  {
    id: 'prod_TaCkDOjKZfrycS',
    priceId: 'price_1Sd2LGK0rX2Uf9BVwPgHLijQ',
    name: 'Tier 2',
    description: 'Unlimited offers, tours, and built-in AI deal intelligence',
    price: 99.00,
    currency: 'usd',
    mode: 'subscription' as const,
    features: [
      'Everything in Offer generator, plus:',
      'Unlimited events & offers',
      'Unlimited tours',
      '2 seats included (add team members)',
      'Tour Management tab',
      'AI Insights & Deal Analyzer',
      'Venue & day-of-week profitability',
      'Genre & artist performance tracking',
      'Deals scored 0-100 with recommendations',
      'Enhanced analytics for multiple markets',
      'Priority email support'
    ]
  }
];

export const getProductByPriceId = (priceId: string) => {
  return STRIPE_PRODUCTS.find(product => product.priceId === priceId);
};

export const getProductById = (id: string) => {
  return STRIPE_PRODUCTS.find(product => product.id === id);
};