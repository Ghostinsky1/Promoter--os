/*
  # Add Support Acts and Run of Show System

  1. Changes to Existing Tables
    - Add `support_acts` column to `offers` table (JSONB)
      - Stores array of support act objects with name, type, guarantee, set_length, genre, notes

  2. New Tables
    - `run_of_show`
      - `id` (text, primary key)
      - `offer_id` (text, foreign key to offers)
      - `event_date` (date)
      - `venue_contact` (jsonb) - stores name, phone, email
      - `schedule` (jsonb) - array of schedule items with time, duration, title, category, description, responsible
      - `notes` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `user_id` (uuid, foreign key to auth.users)

  3. Security
    - Enable RLS on `run_of_show` table
    - Add policies for authenticated users to manage their own run of show data
*/

-- Add support_acts column to offers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'support_acts'
  ) THEN
    ALTER TABLE offers ADD COLUMN support_acts JSONB DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Create run_of_show table
CREATE TABLE IF NOT EXISTS run_of_show (
  id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  offer_id text NOT NULL REFERENCES offers(id) ON DELETE CASCADE,
  event_date date,
  venue_contact jsonb DEFAULT '{}'::jsonb,
  schedule jsonb DEFAULT '[]'::jsonb NOT NULL,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Enable RLS
ALTER TABLE run_of_show ENABLE ROW LEVEL SECURITY;

-- Policies for run_of_show
CREATE POLICY "Users can view own run of show"
  ON run_of_show FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own run of show"
  ON run_of_show FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own run of show"
  ON run_of_show FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own run of show"
  ON run_of_show FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_run_of_show_offer_id ON run_of_show(offer_id);
CREATE INDEX IF NOT EXISTS idx_run_of_show_user_id ON run_of_show(user_id);
