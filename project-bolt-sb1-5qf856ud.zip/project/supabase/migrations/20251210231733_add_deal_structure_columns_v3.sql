/*
  # Add Deal Structure Columns to Offers Table

  1. New Columns
    - `deal_type` (text) - Type of deal: flat_fee, guarantee_vs_percentage, percentage_only, door_deal
    - `artist_percentage` (decimal) - Percentage of net revenue for artist (0-100)
    - `promoter_profit` (decimal) - Calculated profit for promoter
    - `artist_payout` (decimal) - Calculated payout for artist
    
  2. Changes
    - Add deal structure tracking columns to offers table
    - Map old deal_type values to new ones
    - Add constraints for data validation
*/

-- Drop existing check constraints if they exist
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'offers_deal_type_check') THEN
    ALTER TABLE offers DROP CONSTRAINT offers_deal_type_check;
  END IF;
  
  IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'valid_deal_type') THEN
    ALTER TABLE offers DROP CONSTRAINT valid_deal_type;
  END IF;
  
  IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'valid_artist_percentage') THEN
    ALTER TABLE offers DROP CONSTRAINT valid_artist_percentage;
  END IF;
END $$;

-- Add deal structure columns if they don't exist
ALTER TABLE offers ADD COLUMN IF NOT EXISTS artist_percentage DECIMAL;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS promoter_profit DECIMAL;
ALTER TABLE offers ADD COLUMN IF NOT EXISTS artist_payout DECIMAL;

-- Update existing deal_type values to match new structure
-- Map 'flat_guarantee' to 'flat_fee'
UPDATE offers 
SET deal_type = 'flat_fee' 
WHERE deal_type = 'flat_guarantee' OR deal_type IS NULL OR deal_type = '';

-- Update existing rows to have valid artist_percentage
UPDATE offers 
SET artist_percentage = 100.00 
WHERE artist_percentage IS NULL;

-- Set default values for future inserts
ALTER TABLE offers ALTER COLUMN deal_type SET DEFAULT 'flat_fee';
ALTER TABLE offers ALTER COLUMN artist_percentage SET DEFAULT 100.00;

-- Add check constraint for valid deal types
ALTER TABLE offers 
ADD CONSTRAINT valid_deal_type 
CHECK (deal_type IN ('flat_fee', 'guarantee_vs_percentage', 'percentage_only', 'door_deal'));

-- Add check constraint for artist percentage
ALTER TABLE offers 
ADD CONSTRAINT valid_artist_percentage 
CHECK (artist_percentage >= 0 AND artist_percentage <= 100);
