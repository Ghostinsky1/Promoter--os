/*
  # Create Tours System

  1. New Tables
    - `tours`
      - `id` (text, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text) - Tour name
      - `artist_name` (text) - Artist name
      - `start_date` (date) - Tour start date
      - `end_date` (date) - Tour end date
      - `description` (text) - Tour description
      - `status` (text) - Tour status (planning, booking, confirmed, active, completed, cancelled)
      - `projected_revenue` (numeric) - Total projected revenue
      - `total_costs` (numeric) - Total costs
      - `net_profit` (numeric) - Net profit
      - `completed_count` (integer) - Number of completed shows
      - `settled_count` (integer) - Number of settled shows
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Changes to Existing Tables
    - Add `tour_id` column to `offers` table (links offers to tours)
    - Add `show_number` column to `offers` table (show sequence in tour)

  3. Security
    - Enable RLS on `tours` table
    - Add policies for authenticated users to manage their own tours
*/

-- Create tours table
CREATE TABLE IF NOT EXISTS tours (
  id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  artist_name text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'planning',
  projected_revenue numeric DEFAULT 0,
  total_costs numeric DEFAULT 0,
  net_profit numeric DEFAULT 0,
  completed_count integer DEFAULT 0,
  settled_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add tour fields to offers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'tour_id'
  ) THEN
    ALTER TABLE offers ADD COLUMN tour_id text REFERENCES tours(id) ON DELETE SET NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'show_number'
  ) THEN
    ALTER TABLE offers ADD COLUMN show_number integer;
  END IF;
END $$;

-- Enable RLS
ALTER TABLE tours ENABLE ROW LEVEL SECURITY;

-- Policies for tours
CREATE POLICY "Users can view own tours"
  ON tours FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own tours"
  ON tours FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tours"
  ON tours FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own tours"
  ON tours FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_tours_user_id ON tours(user_id);
CREATE INDEX IF NOT EXISTS idx_tours_status ON tours(status);
CREATE INDEX IF NOT EXISTS idx_offers_tour_id ON offers(tour_id);
