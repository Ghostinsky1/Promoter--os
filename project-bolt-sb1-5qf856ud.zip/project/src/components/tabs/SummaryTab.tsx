import { Calculations, TicketTier } from '../../types';
import { formatCurrency } from '../../lib/calculations';
import { CalculationsBreakdown } from '../CalculationsBreakdown';
import { DealAnalyzer } from '../DealAnalyzer';

interface SummaryTabProps {
  calculations: Calculations;
  dealType: 'flat_guarantee' | 'promoter_profit';
  guarantee: number;
  taxWithholdingPct: number;
  depositPct: number;
  mode: 'estimate' | 'settlement';
  ticketTiers: TicketTier[];
  salesTaxPct: number;
  artistName: string;
  venueName: string;
  capacity: number;
}

export function SummaryTab({
  calculations,
  dealType,
  guarantee,
  taxWithholdingPct,
  depositPct,
  mode,
  ticketTiers,
  salesTaxPct,
  artistName,
  venueName,
  capacity,
}: SummaryTabProps) {
  const depositAmount = guarantee * (depositPct / 100);
  const taxWithholding = guarantee * (taxWithholdingPct / 100);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900 mb-4">Offer Summary</h2>
        <p className="text-slate-600 mb-6">Review all calculations and projections</p>
      </div>

      <DealAnalyzer
        offerData={{
          artist_name: artistName,
          venue_name: venueName,
          capacity: capacity,
          guarantee: guarantee,
          gross_potential: calculations.netGross,
          net_profit: calculations.netProfit,
          total_costs: calculations.totalExpenses + guarantee,
          ticket_tiers: ticketTiers,
        }}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Artist Payout Breakdown</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-slate-600">Guarantee</span>
              <span className="font-medium">{formatCurrency(guarantee)}</span>
            </div>

            {dealType === 'promoter_profit' && calculations.artistBackend && calculations.artistBackend > 0 && (
              <div className="flex justify-between">
                <span className="text-slate-600">Backend (85%)</span>
                <span className="font-medium text-green-600">+{formatCurrency(calculations.artistBackend)}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span className="text-slate-600">Tax Withholding ({taxWithholdingPct}%)</span>
              <span className="font-medium text-red-600">-{formatCurrency(taxWithholding)}</span>
            </div>

            <div className="border-t border-slate-300 pt-3 flex justify-between">
              <span className="font-semibold text-slate-900">Artist Total Payout</span>
              <span className="font-semibold text-slate-900 text-lg">
                {formatCurrency(calculations.artistTotalPayout)}
              </span>
            </div>

            <div className="border-t border-slate-200 pt-3 mt-3">
              <div className="text-sm text-slate-600 mb-2">Deposit Due (30 days before)</div>
              <div className="font-semibold text-slate-900">{formatCurrency(depositAmount)}</div>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Financial Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-slate-600">Net Gross Potential</span>
              <span className="font-medium">{formatCurrency(calculations.netGross)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Total Expenses</span>
              <span className="font-medium text-red-600">-{formatCurrency(calculations.totalExpenses)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Artist Guarantee</span>
              <span className="font-medium text-red-600">-{formatCurrency(guarantee)}</span>
            </div>

            {dealType === 'promoter_profit' && (
              <>
                <div className="flex justify-between">
                  <span className="text-slate-600">Promoter Profit (15%)</span>
                  <span className="font-medium text-green-600">
                    +{formatCurrency(calculations.promoterProfit || 0)}
                  </span>
                </div>
                {calculations.promoterBackend && calculations.promoterBackend > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">Promoter Backend (15%)</span>
                    <span className="font-medium text-green-600">
                      +{formatCurrency(calculations.promoterBackend)}
                    </span>
                  </div>
                )}
              </>
            )}

            <div className={`border-t border-slate-300 pt-3 flex justify-between ${
              calculations.netProfit >= 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              <span className="font-semibold text-lg">NET PROFIT</span>
              <span className="font-bold text-xl">
                {formatCurrency(calculations.netProfit)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {dealType === 'promoter_profit' && calculations.splitPoint && (
        <div className={`border rounded-lg p-6 ${
          calculations.netGross > calculations.splitPoint
            ? 'bg-green-50 border-green-200'
            : 'bg-amber-50 border-amber-200'
        }`}>
          <h3 className="font-semibold text-slate-900 mb-2">Split Point Analysis</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-700">Split Point</span>
              <span className="font-medium">{formatCurrency(calculations.splitPoint)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-700">Net Gross</span>
              <span className="font-medium">{formatCurrency(calculations.netGross)}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold text-slate-900">Status</span>
              <span className={`font-semibold ${
                calculations.netGross > calculations.splitPoint ? 'text-green-600' : 'text-amber-600'
              }`}>
                {calculations.netGross > calculations.splitPoint
                  ? `Split Point Hit! +${formatCurrency(calculations.backend || 0)} Backend`
                  : `Need ${formatCurrency(calculations.splitPoint - calculations.netGross)} more to hit split`
                }
              </span>
            </div>
          </div>
        </div>
      )}

      <CalculationsBreakdown
        ticketTiers={ticketTiers}
        salesTaxPct={salesTaxPct}
        calculations={calculations}
        guarantee={guarantee}
        mode={mode}
      />

      {mode === 'estimate' && calculations.projections && (
        <div>
          <h3 className="font-semibold text-slate-900 mb-4">Capacity Projections</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: '70% Capacity', data: calculations.projections.capacity70 },
              { label: '85% Capacity', data: calculations.projections.capacity85 },
              { label: '100% Sellout', data: calculations.projections.capacity100 },
            ].map(({ label, data }) => (
              <div
                key={label}
                className={`border rounded-lg p-5 ${
                  data.netProfit >= 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                }`}
              >
                <h4 className="font-semibold text-slate-900 mb-3">{label}</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Tickets</span>
                    <span className="font-medium">{data.tickets}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Artist</span>
                    <span className="font-medium">{formatCurrency(data.artistPayout)}</span>
                  </div>
                  {dealType === 'promoter_profit' && (
                    <div className="flex justify-between">
                      <span className="text-slate-600">Promoter</span>
                      <span className="font-medium">{formatCurrency(data.promoterProfit)}</span>
                    </div>
                  )}
                  <div className={`flex justify-between pt-2 border-t ${
                    data.netProfit >= 0 ? 'border-green-300' : 'border-red-300'
                  }`}>
                    <span className="font-semibold">Profit</span>
                    <span className={`font-bold ${
                      data.netProfit >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {formatCurrency(data.netProfit)}
                    </span>
                  </div>
                  {dealType === 'promoter_profit' && (
                    <div className="text-xs text-center pt-2">
                      {data.splitPointHit ? (
                        <span className="text-green-600 font-medium">Split Point Hit</span>
                      ) : (
                        <span className="text-amber-600">Below Split Point</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
