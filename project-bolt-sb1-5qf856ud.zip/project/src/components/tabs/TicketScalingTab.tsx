import { Plus, Trash2 } from 'lucide-react';
import { TicketTier } from '../../types';
import { formatCurrency } from '../../lib/calculations';

interface TicketScalingTabProps {
  ticketTiers: TicketTier[];
  setTicketTiers: (tiers: TicketTier[]) => void;
  salesTaxPct: number;
  setSalesTaxPct: (value: number) => void;
  mode: 'estimate' | 'settlement';
  compsArtist?: number;
  setCompsArtist?: (value: number) => void;
  compsVenue?: number;
  setCompsVenue?: (value: number) => void;
  compsPromoter?: number;
  setCompsPromoter?: (value: number) => void;
}

export function TicketScalingTab({
  ticketTiers,
  setTicketTiers,
  salesTaxPct,
  setSalesTaxPct,
  mode,
  compsArtist = 0,
  setCompsArtist = () => {},
  compsVenue = 0,
  setCompsVenue = () => {},
  compsPromoter = 0,
  setCompsPromoter = () => {},
}: TicketScalingTabProps) {
  const addTier = () => {
    setTicketTiers([...ticketTiers, { type: '', allotment: 0, comps: 0, price: 0 }]);
  };

  const removeTier = (index: number) => {
    if (ticketTiers.length > 1) {
      setTicketTiers(ticketTiers.filter((_, i) => i !== index));
    }
  };

  const updateTier = (index: number, field: keyof TicketTier, value: string | number) => {
    const updated = [...ticketTiers];
    updated[index] = { ...updated[index], [field]: value };
    setTicketTiers(updated);
  };

  const grossPotential = ticketTiers.reduce((sum, tier) => {
    const sellable = tier.allotment - tier.comps;
    return sum + (sellable * tier.price);
  }, 0);

  const salesTax = grossPotential * (salesTaxPct / 100);
  const netGross = grossPotential - salesTax;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900 mb-4">Ticket Scaling</h2>
        <p className="text-slate-600 mb-6">Configure ticket tiers and pricing</p>
      </div>

      <div className="space-y-4">
        {ticketTiers.map((tier, index) => (
          <div key={index} className="border border-slate-200 rounded-lg p-4">
            <div className="flex items-start justify-between mb-4">
              <h3 className="font-medium text-slate-900">Tier {index + 1}</h3>
              {ticketTiers.length > 1 && (
                <button
                  onClick={() => removeTier(index)}
                  className="text-red-600 hover:text-red-700 p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Type</label>
                <input
                  type="text"
                  value={tier.type}
                  onChange={(e) => updateTier(index, 'type', e.target.value)}
                  placeholder="GA, VIP, etc."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Allotment</label>
                <input
                  type="number"
                  value={tier.allotment || ''}
                  onChange={(e) => updateTier(index, 'allotment', Number(e.target.value))}
                  placeholder="0"
                  min="0"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Comps</label>
                <input
                  type="number"
                  value={tier.comps || ''}
                  onChange={(e) => updateTier(index, 'comps', Number(e.target.value))}
                  placeholder="0"
                  min="0"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Price</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
                  <input
                    type="number"
                    value={tier.price || ''}
                    onChange={(e) => updateTier(index, 'price', Number(e.target.value))}
                    placeholder="0.00"
                    min="0"
                    step="0.01"
                    className="w-full pl-7 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Sellable</label>
                <div className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium">
                  {tier.allotment - tier.comps}
                </div>
              </div>
            </div>

            <div className="mt-3 flex justify-between items-center">
              <span className="text-sm text-slate-600">Gross Potential</span>
              <span className="font-semibold text-slate-900">
                {formatCurrency((tier.allotment - tier.comps) * tier.price)}
              </span>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={addTier}
        className="w-full py-3 border-2 border-dashed border-slate-300 rounded-lg text-slate-600 hover:border-blue-500 hover:text-blue-600 transition-colors flex items-center justify-center gap-2"
      >
        <Plus className="w-5 h-5" />
        Add Ticket Tier
      </button>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="font-bold text-slate-900 mb-4">Complimentary Tickets</h3>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Artist Comps</label>
            <input
              type="number"
              value={compsArtist}
              onChange={(e) => setCompsArtist(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Venue Comps</label>
            <input
              type="number"
              value={compsVenue}
              onChange={(e) => setCompsVenue(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Promoter Comps</label>
            <input
              type="number"
              value={compsPromoter}
              onChange={(e) => setCompsPromoter(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="border-t border-slate-200 pt-6">
        <div className="max-w-md">
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Sales Tax (%)
          </label>
          <input
            type="number"
            value={salesTaxPct}
            onChange={(e) => setSalesTaxPct(Number(e.target.value))}
            placeholder="0"
            min="0"
            max="100"
            step="0.01"
            className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
        <h3 className="font-semibold text-slate-900 mb-4">Revenue Summary</h3>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-slate-600">Gross Potential</span>
            <span className="font-medium">{formatCurrency(grossPotential)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-600">Sales Tax ({salesTaxPct}%)</span>
            <span className="font-medium text-red-600">-{formatCurrency(salesTax)}</span>
          </div>
          <div className="border-t border-slate-300 pt-3 flex justify-between">
            <span className="font-semibold text-slate-900">Net Gross Potential</span>
            <span className="font-semibold text-slate-900 text-lg">{formatCurrency(netGross)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
