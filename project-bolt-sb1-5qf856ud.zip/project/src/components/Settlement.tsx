import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { OfferWithShow, CompanySettings } from '../types';
import { formatCurrency } from '../lib/calculations';
import { generateSettlementPDF } from '../lib/generateSettlementPDF';
import { parseLocalDate } from '../lib/dateHelpers';
import { ArrowLeft, Save, FileDown, TrendingUp, TrendingDown, AlertCircle, Plus, Trash2 } from 'lucide-react';

interface ActualTicketTier {
  type: string;
  price: number;
  actual_sold: number;
  projected_sold: number;
}

interface Settlement {
  id?: string;
  offer_id: string;
  actual_attendance: ActualTicketTier[];
  actual_expenses: {
    talent: Record<string, number>;
    general: Record<string, number>;
    marketing: Record<string, number>;
    production: Record<string, number>;
  };
  actual_revenue: number;
  actual_total_expenses: number;
  actual_profit: number;
  variance_revenue: number;
  variance_expenses: number;
  variance_profit: number;
  notes: string;
  settled_at?: string;
}

export function Settlement() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [offer, setOffer] = useState<OfferWithShow | null>(null);
  const [settlement, setSettlement] = useState<Settlement | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [companySettings, setCompanySettings] = useState<CompanySettings | undefined>(undefined);

  useEffect(() => {
    if (id) {
      loadOfferAndSettlement(id);
    }
  }, [id]);

  const loadOfferAndSettlement = async (offerId: string) => {
    try {
      const { data: offerData, error: offerError } = await supabase
        .from('offers')
        .select('*')
        .eq('id', offerId)
        .maybeSingle();

      if (offerError) throw offerError;
      if (!offerData) {
        navigate('/offers');
        return;
      }

      const { data: showData, error: showError } = await supabase
        .from('shows')
        .select('*')
        .eq('id', offerData.show_id)
        .maybeSingle();

      if (showError) throw showError;
      if (!showData) {
        navigate('/offers');
        return;
      }

      const offerWithShow = {
        ...offerData,
        show: showData,
      };

      setOffer(offerWithShow);

      const { data: settings } = await supabase
        .from('company_settings')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (settings) {
        setCompanySettings(settings);
      }

      const { data: settlementData } = await supabase
        .from('settlements')
        .select('*')
        .eq('offer_id', offerId)
        .maybeSingle();

      if (settlementData) {
        setSettlement(settlementData);
      } else {
        const initialAttendance: ActualTicketTier[] = offerWithShow.ticket_tiers.map((tier: any) => ({
          type: tier.type,
          price: tier.price,
          actual_sold: 0,
          projected_sold: tier.allotment - tier.comps,
        }));

        const initialExpenses: any = {};
        Object.keys(offerWithShow.expenses).forEach((category) => {
          initialExpenses[category] = {};
          Object.keys(offerWithShow.expenses[category]).forEach((expenseKey) => {
            initialExpenses[category][expenseKey] = 0;
          });
        });

        setSettlement({
          offer_id: offerId,
          actual_attendance: initialAttendance,
          actual_expenses: initialExpenses,
          actual_revenue: 0,
          actual_total_expenses: 0,
          actual_profit: 0,
          variance_revenue: 0,
          variance_expenses: 0,
          variance_profit: 0,
          notes: '',
        });
      }
    } catch (error) {
      console.error('Error loading data:', error);
      navigate('/offers');
    } finally {
      setLoading(false);
    }
  };

  const calculateActuals = (updatedSettlement: Settlement) => {
    const actualRevenue = updatedSettlement.actual_attendance.reduce(
      (sum, tier) => sum + tier.actual_sold * tier.price,
      0
    );

    const actualTotalExpenses = Object.values(updatedSettlement.actual_expenses).reduce(
      (sum, category) => sum + Object.values(category).reduce((catSum, val) => catSum + val, 0),
      0
    );

    const actualProfit = actualRevenue - actualTotalExpenses;

    const projectedRevenue = offer?.calculations.grossRevenue || 0;
    const projectedExpenses = offer?.calculations.totalExpenses || 0;
    const projectedProfit = offer?.calculations.netProfit || 0;

    return {
      ...updatedSettlement,
      actual_revenue: actualRevenue,
      actual_total_expenses: actualTotalExpenses,
      actual_profit: actualProfit,
      variance_revenue: actualRevenue - projectedRevenue,
      variance_expenses: actualTotalExpenses - projectedExpenses,
      variance_profit: actualProfit - projectedProfit,
    };
  };

  const handleAttendanceChange = (index: number, value: string) => {
    if (!settlement) return;

    const updated = { ...settlement };
    updated.actual_attendance[index].actual_sold = parseInt(value) || 0;
    setSettlement(calculateActuals(updated));
  };

  const handleExpenseChange = (category: keyof Settlement['actual_expenses'], key: string, value: string) => {
    if (!settlement) return;

    const updated = { ...settlement };
    updated.actual_expenses[category][key] = parseFloat(value) || 0;
    setSettlement(calculateActuals(updated));
  };

  const handleNotesChange = (value: string) => {
    if (!settlement) return;
    setSettlement({ ...settlement, notes: value });
  };

  const handleDeleteExpense = (category: keyof Settlement['actual_expenses'], key: string) => {
    if (!settlement) return;
    if (!confirm(`Delete expense "${key}"?`)) return;

    const updated = { ...settlement };
    delete updated.actual_expenses[category][key];
    setSettlement(calculateActuals(updated));
  };

  const handleAddExpense = (category: keyof Settlement['actual_expenses']) => {
    if (!settlement) return;

    const expenseName = prompt('Enter expense name:');
    if (!expenseName || expenseName.trim() === '') return;

    const key = expenseName.trim().toLowerCase().replace(/\s+/g, '_');

    if (settlement.actual_expenses[category][key] !== undefined) {
      alert('An expense with this name already exists in this category');
      return;
    }

    const updated = { ...settlement };
    updated.actual_expenses[category][key] = 0;
    setSettlement(calculateActuals(updated));
  };

  const handleAddCategory = () => {
    if (!settlement) return;

    const categoryName = prompt('Enter new category name:');
    if (!categoryName || categoryName.trim() === '') return;

    const key = categoryName.trim().toLowerCase().replace(/\s+/g, '_') as keyof Settlement['actual_expenses'];

    if (settlement.actual_expenses[key] !== undefined) {
      alert('A category with this name already exists');
      return;
    }

    const updated = { ...settlement };
    updated.actual_expenses[key] = {};
    setSettlement(calculateActuals(updated));
  };

  const handleSave = async () => {
    if (!settlement || !offer) return;

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const settlementData = {
        ...settlement,
        user_id: user.id,
        settled_at: new Date().toISOString(),
      };

      if (settlement.id) {
        const { error } = await supabase
          .from('settlements')
          .update(settlementData)
          .eq('id', settlement.id);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('settlements')
          .insert([settlementData])
          .select()
          .single();

        if (error) throw error;
        setSettlement({ ...settlement, id: data.id });
      }

      const { error: offerError } = await supabase
        .from('offers')
        .update({
          is_settled: true,
          actual_profit: settlement.actual_profit,
          status: 'settled'
        })
        .eq('id', offer.id);

      if (offerError) throw offerError;

      alert('Settlement saved successfully!');
    } catch (error) {
      console.error('Error saving settlement:', error);
      alert('Failed to save settlement');
    } finally {
      setSaving(false);
    }
  };

  const handleExportPDF = () => {
    if (offer && settlement) {
      generateSettlementPDF(offer, settlement, companySettings);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">Loading settlement data...</div>
      </div>
    );
  }

  if (!offer || !settlement) {
    return null;
  }

  const VarianceIndicator = ({ variance }: { variance: number }) => {
    if (variance === 0) return <span className="text-slate-500">—</span>;
    const isPositive = variance > 0;
    return (
      <div className={`flex items-center gap-1 ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
        {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
        <span className="font-semibold">{formatCurrency(Math.abs(variance))}</span>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-3 py-4">
        <div className="mb-4">
          <button
            onClick={() => navigate(`/offers/${id}`)}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-3 text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Offer
          </button>

          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <button
              onClick={handleSave}
              disabled={saving}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Save className="h-5 w-5" />
              {saving ? 'Saving...' : 'Save Settlement'}
            </button>

            <button
              onClick={handleExportPDF}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2"
            >
              <FileDown className="h-5 w-5" />
              Export PDF
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 mb-4">
          <h1 className="text-xl font-bold text-slate-900 mb-2">Settlement - {offer.show.artist_name}</h1>
          <p className="text-sm text-slate-600">{offer.show.venue_name} • {(() => {
            const eventDate = parseLocalDate(offer.show.event_date);
            return eventDate ? eventDate.toLocaleDateString() : 'Invalid date';
          })()}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <div className="text-sm text-slate-600 mb-1">Revenue</div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {formatCurrency(settlement.actual_revenue)}
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-500">vs Projected:</span>
              <VarianceIndicator variance={settlement.variance_revenue} />
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Projected: {formatCurrency(offer.calculations.grossRevenue)}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <div className="text-sm text-slate-600 mb-1">Expenses</div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {formatCurrency(settlement.actual_total_expenses)}
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-500">vs Projected:</span>
              <VarianceIndicator variance={-settlement.variance_expenses} />
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Projected: {formatCurrency(offer.calculations.totalExpenses)}
            </div>
          </div>

          <div className={`rounded-lg shadow-sm border p-4 ${
            settlement.actual_profit >= 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
          }`}>
            <div className="text-sm text-slate-600 mb-1">Net Profit</div>
            <div className={`text-2xl font-bold mb-2 ${
              settlement.actual_profit >= 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {formatCurrency(settlement.actual_profit)}
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-500">vs Projected:</span>
              <VarianceIndicator variance={settlement.variance_profit} />
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Projected: {formatCurrency(offer.calculations.netProfit)}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <h2 className="text-lg font-bold text-slate-900 mb-4">Actual Attendance</h2>
            <div className="space-y-3">
              {settlement.actual_attendance.map((tier, index) => (
                <div key={index} className="border border-slate-200 rounded-lg p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-semibold text-slate-900">{tier.type}</div>
                      <div className="text-xs text-slate-500">{formatCurrency(tier.price)} per ticket</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-slate-600">Projected: {tier.projected_sold}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <label className="text-sm text-slate-600 flex-shrink-0">Actual Sold:</label>
                    <input
                      type="number"
                      min="0"
                      value={tier.actual_sold}
                      onChange={(e) => handleAttendanceChange(index, e.target.value)}
                      className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div className="mt-2 text-right text-sm font-semibold text-slate-900">
                    Revenue: {formatCurrency(tier.actual_sold * tier.price)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900">Actual Expenses</h2>
              <button
                onClick={handleAddCategory}
                className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                <Plus className="w-4 h-4" />
                Add Category
              </button>
            </div>
            <div className="space-y-4">
              {Object.keys(settlement.actual_expenses).map((category) => {
                const categoryKey = category as keyof Settlement['actual_expenses'];
                const categoryExpenses = settlement.actual_expenses[categoryKey];
                const estimatedExpenses = offer.expenses[categoryKey] || {};

                return (
                  <div key={category} className="border border-slate-200 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-slate-900 capitalize">{category.replace(/_/g, ' ')}</h3>
                      <button
                        onClick={() => handleAddExpense(categoryKey)}
                        className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700 font-medium"
                      >
                        <Plus className="w-3 h-3" />
                        Add Expense
                      </button>
                    </div>
                    <div className="space-y-2">
                      {Object.keys(categoryExpenses).length === 0 ? (
                        <div className="text-sm text-slate-400 italic py-2">No expenses in this category</div>
                      ) : (
                        Object.keys(categoryExpenses).map((expenseKey) => (
                          <div key={expenseKey} className="flex items-center gap-2">
                            <label className="text-sm text-slate-600 flex-1">{expenseKey.replace(/_/g, ' ')}:</label>
                            <div className="flex items-center gap-2">
                              {estimatedExpenses[expenseKey] !== undefined && (
                                <span className="text-xs text-slate-500">
                                  Est: {formatCurrency(estimatedExpenses[expenseKey])}
                                </span>
                              )}
                              <input
                                type="number"
                                step="0.01"
                                min="0"
                                value={categoryExpenses[expenseKey] || 0}
                                onChange={(e) => handleExpenseChange(categoryKey, expenseKey, e.target.value)}
                                className="w-32 px-2 py-1 border border-slate-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                              <button
                                onClick={() => handleDeleteExpense(categoryKey, expenseKey)}
                                className="text-red-500 hover:text-red-700 p-1"
                                title="Delete expense"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 mb-4">
          <h2 className="text-lg font-bold text-slate-900 mb-3">Settlement Notes</h2>
          <textarea
            value={settlement.notes}
            onChange={(e) => handleNotesChange(e.target.value)}
            placeholder="Add any notes about the settlement, issues encountered, or other relevant information..."
            rows={6}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
          />
        </div>

        {settlement.variance_profit !== 0 && (
          <div className={`rounded-lg p-4 mb-4 flex items-start gap-3 ${
            settlement.variance_profit > 0 ? 'bg-green-50 border border-green-200' : 'bg-amber-50 border border-amber-200'
          }`}>
            <AlertCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
              settlement.variance_profit > 0 ? 'text-green-600' : 'text-amber-600'
            }`} />
            <div>
              <div className={`font-semibold ${
                settlement.variance_profit > 0 ? 'text-green-900' : 'text-amber-900'
              }`}>
                {settlement.variance_profit > 0 ? 'Performance Above Projection' : 'Performance Below Projection'}
              </div>
              <div className={`text-sm mt-1 ${
                settlement.variance_profit > 0 ? 'text-green-700' : 'text-amber-700'
              }`}>
                The actual profit is {formatCurrency(Math.abs(settlement.variance_profit))} {settlement.variance_profit > 0 ? 'higher' : 'lower'} than projected.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
