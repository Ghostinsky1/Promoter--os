/*
  # Add Settlement Tracking to Offers Table

  1. Changes
    - Add `is_settled` column to track whether an offer has been settled
    - Add `actual_profit` column to store the actual profit from settlement
  
  2. Purpose
    - Support settlement tracking workflow
    - Enable AI insights to filter settled vs unsettled offers
    - Store actual profit alongside projected profit
*/

-- Add settlement tracking columns to offers table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'offers' AND column_name = 'is_settled'
  ) THEN
    ALTER TABLE offers ADD COLUMN is_settled BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'offers' AND column_name = 'actual_profit'
  ) THEN
    ALTER TABLE offers ADD COLUMN actual_profit DECIMAL DEFAULT 0;
  END IF;
END $$;
