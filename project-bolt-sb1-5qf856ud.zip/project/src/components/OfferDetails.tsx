import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { OfferWithShow, CompanySettings } from '../types';
import { formatCurrency, calculateCategoryTotal } from '../lib/calculations';
import { getProfitIndicator } from '../lib/profitIndicators';
import { CalculationsBreakdown } from './CalculationsBreakdown';
import { generateOfferPDF } from '../lib/generateOfferPDF';
import { parseLocalDate } from '../lib/dateHelpers';
import { ArrowLeft, Calendar, MapPin, Users, Edit, FileDown, Eye, BarChart3, Copy, Film, Trash2, Calculator, Sparkles } from 'lucide-react';

export function OfferDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [offer, setOffer] = useState<OfferWithShow | null>(null);
  const [loading, setLoading] = useState(true);
  const [companySettings, setCompanySettings] = useState<CompanySettings | null>(null);
  const [costsOnly, setCostsOnly] = useState(false);
  const [dealScore, setDealScore] = useState<number | null>(null);

  useEffect(() => {
    if (id) {
      loadOffer(id);
    }
    loadCompanySettings();
  }, [id]);

  useEffect(() => {
    if (offer && offer.show.capacity > 0) {
      analyzeDeal();
    }
  }, [offer]);

  const loadCompanySettings = async () => {
    try {
      const { data } = await supabase
        .from('company_settings')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (data) {
        setCompanySettings(data);
      }
    } catch (error) {
      console.error('Error loading company settings:', error);
    }
  };

  const handleDownloadPDF = () => {
    if (offer) {
      generateOfferPDF(offer, companySettings || undefined, false, costsOnly);
    }
  };

  const handlePreviewPDF = () => {
    if (offer) {
      generateOfferPDF(offer, companySettings || undefined, true, costsOnly);
    }
  };

  const handleSaveAsTemplate = async () => {
    if (!offer) return;

    const templateName = prompt('Enter a name for this template:', `${offer.show.artist_name} Template`);
    if (!templateName) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const expenseCategories = Object.keys(offer.expenses).map(category => ({
        title: category.charAt(0).toUpperCase() + category.slice(1),
        items: Object.entries(offer.expenses[category as keyof typeof offer.expenses]).map(([name, amount]) => ({
          name,
          default_amount: amount
        }))
      }));

      const { error } = await supabase
        .from('templates')
        .insert([{
          user_id: user.id,
          name: templateName,
          description: `Template based on ${offer.show.artist_name} at ${offer.show.venue_name}`,
          type: 'event',
          deal_type: offer.deal_type,
          deposit_pct: offer.deposit_pct,
          deposit_due_timing: offer.deposit_due_timing || '30_days_before',
          tax_withholding_pct: offer.tax_withholding_pct,
          sales_tax_pct: offer.sales_tax_pct,
          ticket_tier_templates: offer.ticket_tiers.map(tier => ({
            type: tier.type,
            price: tier.price,
            default_allotment: tier.allotment,
            default_comps: tier.comps
          })),
          expense_categories: expenseCategories,
          legal_terms: companySettings?.legal_terms || ''
        }]);

      if (error) throw error;

      alert('Template saved successfully!');
      navigate('/templates');
    } catch (error) {
      console.error('Error saving template:', error);
      alert('Failed to save template');
    }
  };

  const handleDeleteOffer = async () => {
    if (!offer) return;

    const confirmed = window.confirm(
      `Are you sure you want to delete the offer for "${offer.show.artist_name}" at "${offer.show.venue_name}"?\n\nThis action cannot be undone.`
    );

    if (!confirmed) return;

    try {
      console.log('🗑️ Deleting offer:', offer.id);

      const { error: offerError } = await supabase
        .from('offers')
        .delete()
        .eq('id', offer.id);

      if (offerError) throw offerError;

      const { error: showError } = await supabase
        .from('shows')
        .delete()
        .eq('id', offer.show_id);

      if (showError) throw showError;

      console.log('✅ Offer deleted successfully');
      alert('Offer deleted successfully');
      navigate('/offers');
    } catch (error) {
      console.error('❌ Error deleting offer:', error);
      alert('Failed to delete offer. Please try again.');
    }
  };

  const loadOffer = async (offerId: string) => {
    try {
      const { data: offerData, error: offerError } = await supabase
        .from('offers')
        .select('*')
        .eq('id', offerId)
        .maybeSingle();

      if (offerError) throw offerError;
      if (!offerData) {
        navigate('/offers');
        return;
      }

      const { data: showData, error: showError } = await supabase
        .from('shows')
        .select('*')
        .eq('id', offerData.show_id)
        .maybeSingle();

      if (showError) throw showError;
      if (!showData) {
        navigate('/offers');
        return;
      }

      setOffer({
        ...offerData,
        show: showData,
      });
    } catch (error) {
      console.error('Error loading offer:', error);
      navigate('/offers');
    } finally {
      setLoading(false);
    }
  };

  const analyzeDeal = async () => {
    if (!offer) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const offerData = {
        artist_name: offer.show.artist_name,
        venue_name: offer.show.venue_name,
        capacity: offer.show.capacity,
        guarantee: offer.guarantee,
        gross_potential: offer.calculations.grossPotential,
        net_profit: offer.calculations.netProfit,
        total_costs: offer.calculations.totalExpenses,
        ticket_tiers: offer.ticket_tiers,
      };

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-deal`;
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(offerData)
      });

      if (!res.ok) return;

      const data = await res.json();
      setDealScore(data.overall_score);
    } catch (error) {
      console.error('Error analyzing deal:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">Loading offer details...</div>
      </div>
    );
  }

  if (!offer) {
    return null;
  }

  const taxWithholding = offer.guarantee * (offer.tax_withholding_pct / 100);
  const depositAmount = offer.guarantee * (offer.deposit_pct / 100);
  const indicator = getProfitIndicator(offer.calculations.netProfit, offer.calculations.netGross);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-3 py-4">
        <div className="mb-4">
          <button
            onClick={() => navigate('/offers')}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-3 text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Offers
          </button>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
            <button
              onClick={() => navigate(`/offers/${id}/analytics`)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-6 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all flex flex-col sm:flex-row items-center justify-center gap-2"
            >
              <BarChart3 className="h-5 w-5" />
              <span className="text-xs sm:text-base">Analytics</span>
            </button>

            <button
              onClick={() => navigate(`/offers/${id}/run-of-show`)}
              className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-6 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all flex flex-col sm:flex-row items-center justify-center gap-2"
            >
              <Film className="h-5 w-5" />
              <span className="text-xs sm:text-base">Run of Show</span>
            </button>

            {(() => {
              const eventDate = parseLocalDate(offer.show.event_date);
              const today = new Date();
              today.setHours(0, 0, 0, 0);
              return eventDate && eventDate < today;
            })() && (
              <button
                onClick={() => navigate(`/offers/${id}/settlement`)}
                className="bg-gradient-to-r from-green-600 to-emerald-600 text-white py-6 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all flex flex-col sm:flex-row items-center justify-center gap-2 relative"
              >
                <Calculator className="h-5 w-5" />
                <span className="text-xs sm:text-base">
                  {offer.is_settled ? 'View Settlement' : 'Settle Event'}
                </span>
                {offer.is_settled && (
                  <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">
                    ✓
                  </span>
                )}
              </button>
            )}

            <button
              onClick={handlePreviewPDF}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-6 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all flex flex-col sm:flex-row items-center justify-center gap-2"
            >
              <Eye className="h-5 w-5" />
              <span className="text-xs sm:text-base">Preview</span>
            </button>

            <button
              onClick={() => navigate(`/offers/${id}/edit`)}
              className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-6 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all flex flex-col sm:flex-row items-center justify-center gap-2"
            >
              <Edit className="h-5 w-5" />
              <span className="text-xs sm:text-base">Edit</span>
            </button>

            <button
              onClick={handleSaveAsTemplate}
              className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-6 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all flex flex-col sm:flex-row items-center justify-center gap-2"
            >
              <Copy className="h-5 w-5" />
              <span className="text-xs sm:text-base">Template</span>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 mb-4">
          <div className="mb-4">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h1 className="text-xl font-bold text-slate-900">{offer.show.event_name || offer.show.artist_name}</h1>
                {offer.show.event_name && (
                  <p className="text-sm text-slate-600 mt-0.5">{offer.show.artist_name}</p>
                )}
              </div>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={costsOnly}
                    onChange={(e) => setCostsOnly(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                  <span className="font-medium">Costs Only</span>
                </label>
                <button
                  onClick={handleDownloadPDF}
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 text-sm"
                >
                  <FileDown className="h-4 w-4" />
                  Download
                </button>
              </div>
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-slate-600 text-xs">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="break-words">{offer.show.venue_name}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{(() => {
                  const eventDate = parseLocalDate(offer.show.event_date);
                  return eventDate ? eventDate.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  }) : 'Invalid date';
                })()}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 flex-shrink-0" />
                <span>Capacity: {offer.show.capacity}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mt-3">
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-medium whitespace-nowrap ${
                offer.mode === 'estimate'
                  ? 'bg-blue-100 text-blue-700'
                  : 'bg-green-100 text-green-700'
              }`}>
                {offer.mode === 'estimate' ? 'Estimate' : 'Settlement'}
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full font-medium bg-slate-100 text-slate-700 whitespace-nowrap">
                {offer.deal_type === 'flat_guarantee' ? 'Flat Guarantee' : 'Promoter Profit Deal'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-slate-50 rounded-lg p-3">
              <div className="text-xs text-slate-600 mb-1">Net Gross Potential</div>
              <div className="text-lg font-bold text-slate-900">
                {formatCurrency(offer.calculations.netGross)}
              </div>
            </div>

            <div className="bg-slate-50 rounded-lg p-3">
              <div className="text-xs text-slate-600 mb-1">Artist Total Payout</div>
              <div className="text-lg font-bold text-slate-900">
                {formatCurrency(offer.calculations.artistTotalPayout)}
              </div>
            </div>

            <div className={`rounded-lg p-3 ${
              offer.calculations.netProfit >= 0 ? 'bg-green-50' : 'bg-red-50'
            }`}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">{indicator.emoji}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${indicator.badge.bgColor} ${indicator.badge.textColor}`}>
                  {indicator.badge.text}
                </span>
              </div>
              <div className="text-xs text-slate-600 mb-1">Net Profit</div>
              <div className={`text-lg font-bold ${
                offer.calculations.netProfit >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {formatCurrency(offer.calculations.netProfit)}
              </div>
              <div className="mt-2">
                <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-full ${indicator.meterColor} transition-all`}
                    style={{ width: `${indicator.meterPercentage}%` }}
                  />
                </div>
              </div>
            </div>

            <div className={`rounded-lg p-3 ${
              dealScore === null ? 'bg-slate-50' :
              dealScore >= 80 ? 'bg-green-50' :
              dealScore >= 60 ? 'bg-blue-50' :
              dealScore >= 40 ? 'bg-yellow-50' : 'bg-red-50'
            }`}>
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className={`h-4 w-4 ${
                  dealScore === null ? 'text-slate-400' :
                  dealScore >= 80 ? 'text-green-600' :
                  dealScore >= 60 ? 'text-blue-600' :
                  dealScore >= 40 ? 'text-yellow-600' : 'text-red-600'
                }`} />
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                  dealScore === null ? 'bg-slate-200 text-slate-600' :
                  dealScore >= 80 ? 'bg-green-200 text-green-800' :
                  dealScore >= 60 ? 'bg-blue-200 text-blue-800' :
                  dealScore >= 40 ? 'bg-yellow-200 text-yellow-800' : 'bg-red-200 text-red-800'
                }`}>
                  {dealScore === null ? 'Calculating...' :
                   dealScore >= 80 ? 'STRONG BUY' :
                   dealScore >= 60 ? 'PROCEED' :
                   dealScore >= 40 ? 'CAUTION' : 'PASS'}
                </span>
              </div>
              <div className="text-xs text-slate-600 mb-1">AI Deal Score</div>
              <div className={`text-lg font-bold ${
                dealScore === null ? 'text-slate-400' :
                dealScore >= 80 ? 'text-green-600' :
                dealScore >= 60 ? 'text-blue-600' :
                dealScore >= 40 ? 'text-yellow-600' : 'text-red-600'
              }`}>
                {dealScore === null ? '—' : `${dealScore}/100`}
              </div>
              <div className="mt-2">
                <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      dealScore === null ? 'bg-slate-300' :
                      dealScore >= 80 ? 'bg-green-500' :
                      dealScore >= 60 ? 'bg-blue-500' :
                      dealScore >= 40 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: dealScore === null ? '0%' : `${dealScore}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <h2 className="text-base font-bold text-slate-900 mb-3">Artist Deal</h2>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Guarantee</span>
                <span className="font-medium">{formatCurrency(offer.guarantee)}</span>
              </div>

              {offer.deal_type === 'promoter_profit' && offer.calculations.artistBackend && offer.calculations.artistBackend > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Backend (85%)</span>
                  <span className="font-medium text-green-600">
                    +{formatCurrency(offer.calculations.artistBackend)}
                  </span>
                </div>
              )}

              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Tax Withholding ({offer.tax_withholding_pct}%)</span>
                <span className="font-medium text-red-600">-{formatCurrency(taxWithholding)}</span>
              </div>

              <div className="border-t border-slate-200 pt-2 flex justify-between">
                <span className="font-semibold text-slate-900 text-sm">Total Payout</span>
                <span className="font-bold text-slate-900">
                  {formatCurrency(offer.calculations.artistTotalPayout)}
                </span>
              </div>

              <div className="border-t border-slate-200 pt-2">
                <div className="text-xs text-slate-600 mb-1">Deposit Due (30 days before)</div>
                <div className="font-semibold text-slate-900 text-sm">{formatCurrency(depositAmount)}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <h2 className="text-base font-bold text-slate-900 mb-3">Ticket Scaling</h2>
            <div className="space-y-2">
              {offer.ticket_tiers.map((tier, index) => (
                <div key={index} className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <div>
                    <div className="font-medium text-slate-900 text-sm">{tier.type}</div>
                    <div className="text-xs text-slate-600">
                      {tier.allotment - tier.comps} sellable × {formatCurrency(tier.price)}
                    </div>
                  </div>
                  <div className="font-semibold text-slate-900 text-sm">
                    {formatCurrency((tier.allotment - tier.comps) * tier.price)}
                  </div>
                </div>
              ))}
              <div className="flex justify-between pt-1">
                <span className="text-xs text-slate-600">Sales Tax ({offer.sales_tax_pct}%)</span>
                <span className="font-medium text-red-600 text-sm">
                  -{formatCurrency(offer.calculations.salesTax)}
                </span>
              </div>
              <div className="border-t border-slate-200 pt-2 flex justify-between">
                <span className="font-semibold text-slate-900 text-sm">Net Gross</span>
                <span className="font-bold text-slate-900">
                  {formatCurrency(offer.calculations.netGross)}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <h2 className="text-base font-bold text-slate-900 mb-3">Expenses Breakdown</h2>
            <div className="space-y-2">
              {[
                { label: 'Talent', category: 'talent', color: 'text-purple-600' },
                { label: 'General', category: 'general', color: 'text-blue-600' },
                { label: 'Marketing', category: 'marketing', color: 'text-green-600' },
                { label: 'Production', category: 'production', color: 'text-orange-600' },
              ].map(({ label, category, color }) => {
                const total = calculateCategoryTotal(offer.expenses[category as keyof typeof offer.expenses]);
                return (
                  <div key={category} className="flex justify-between items-center">
                    <span className={`font-medium text-sm ${color}`}>{label}</span>
                    <span className="font-semibold text-slate-900 text-sm">{formatCurrency(total)}</span>
                  </div>
                );
              })}
              <div className="border-t border-slate-200 pt-2 flex justify-between">
                <span className="font-semibold text-slate-900 text-sm">Total Expenses</span>
                <span className="font-bold text-slate-900">
                  {formatCurrency(offer.calculations.totalExpenses)}
                </span>
              </div>
            </div>
          </div>

          <CalculationsBreakdown
            ticketTiers={offer.ticket_tiers}
            salesTaxPct={offer.sales_tax_pct}
            calculations={offer.calculations}
            guarantee={offer.guarantee}
            mode={offer.mode}
          />

          {offer.mode === 'estimate' && offer.calculations.projections && (
            <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
              <h2 className="text-base font-bold text-slate-900 mb-3">Capacity Projections</h2>
              <div className="space-y-2">
                {[
                  { label: '70% Capacity', data: offer.calculations.projections.capacity70 },
                  { label: '85% Capacity', data: offer.calculations.projections.capacity85 },
                  { label: '100% Sellout', data: offer.calculations.projections.capacity100 },
                ].map(({ label, data }) => (
                  <div key={label} className="border border-slate-200 rounded-lg p-3">
                    <div className="font-semibold text-slate-900 mb-2 text-sm">{label}</div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <div className="text-slate-600">Tickets</div>
                        <div className="font-medium">{data.tickets}</div>
                      </div>
                      <div>
                        <div className="text-slate-600">Artist</div>
                        <div className="font-medium">{formatCurrency(data.artistPayout)}</div>
                      </div>
                      {offer.deal_type === 'promoter_profit' && (
                        <div>
                          <div className="text-slate-600">Promoter</div>
                          <div className="font-medium">{formatCurrency(data.promoterProfit)}</div>
                        </div>
                      )}
                      <div>
                        <div className="text-slate-600">Net Profit</div>
                        <div className={`font-bold ${
                          data.netProfit >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {formatCurrency(data.netProfit)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 flex justify-center">
          <button
            onClick={handleDeleteOffer}
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-2.5 rounded-lg font-medium transition-colors flex items-center gap-2 text-sm"
          >
            <Trash2 className="h-4 w-4" />
            Delete Offer
          </button>
        </div>
      </div>
    </div>
  );
}
