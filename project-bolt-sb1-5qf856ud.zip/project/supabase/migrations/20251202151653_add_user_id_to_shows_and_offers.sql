/*
  # Add user_id to shows and offers tables for proper data isolation

  1. Changes
    - Add user_id column to shows table
    - Add user_id column to offers table
    - Update RLS policies to filter by user_id
    - Backfill existing data (if any) with a default user
  
  2. Security
    - All RLS policies now check auth.uid() = user_id
    - Each user can only see and manage their own data
*/

-- Add user_id to shows table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'shows' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE shows ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Add user_id to offers table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE offers ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view all shows" ON shows;
DROP POLICY IF EXISTS "Users can create shows" ON shows;
DROP POLICY IF EXISTS "Users can update all shows" ON shows;
DROP POLICY IF EXISTS "Users can delete all shows" ON shows;
DROP POLICY IF EXISTS "Users can view all offers" ON offers;
DROP POLICY IF EXISTS "Users can create offers" ON offers;
DROP POLICY IF EXISTS "Users can update all offers" ON offers;
DROP POLICY IF EXISTS "Users can delete all offers" ON offers;

-- Create user-specific RLS policies for shows
CREATE POLICY "Users can view own shows"
  ON shows FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own shows"
  ON shows FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own shows"
  ON shows FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own shows"
  ON shows FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create user-specific RLS policies for offers
CREATE POLICY "Users can view own offers"
  ON offers FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own offers"
  ON offers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own offers"
  ON offers FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own offers"
  ON offers FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_shows_user_id ON shows(user_id);
CREATE INDEX IF NOT EXISTS idx_offers_user_id ON offers(user_id);