import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { TicketTier, Expenses, OfferStatus, SupportAct } from '../types';
import { calculateOffer } from '../lib/calculations';
import { EventDetailsTab } from './tabs/EventDetailsTab';
import { ArtistDealTab } from './tabs/ArtistDealTab';
import { DepositsTab } from './tabs/DepositsTab';
import { TicketScalingTab } from './tabs/TicketScalingTab';
import { ExpensesTab } from './tabs/ExpensesTab';
import { SummaryTab } from './tabs/SummaryTab';
import { ArrowLeft, ArrowRight, Check, FileText } from 'lucide-react';

interface ArtistDeduction {
  name: string;
  amount: number;
}

interface Template {
  id: string;
  name: string;
  description: string;
  template_data: any;
}

export function CreateOffer() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [showTemplateSelector, setShowTemplateSelector] = useState(false);

  const [eventName, setEventName] = useState('');
  const [artistName, setArtistName] = useState('');
  const [venueName, setVenueName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [capacity, setCapacity] = useState<number>(0);
  const [mode] = useState<'estimate' | 'settlement'>('estimate');
  const [status] = useState<OfferStatus>('planning');
  const [venueStreet, setVenueStreet] = useState('');
  const [venueCity, setVenueCity] = useState('');
  const [venueState, setVenueState] = useState('');
  const [venueZip, setVenueZip] = useState('');

  const [facilityFeePerTicket, setFacilityFeePerTicket] = useState<number>(2.00);
  const [ageLimit, setAgeLimit] = useState<string>('All Ages');
  const [doorsTime, setDoorsTime] = useState<string>('20:00');
  const [doorsDuration, setDoorsDuration] = useState<number>(60);
  const [showTime, setShowTime] = useState<string>('21:00');
  const [showDuration, setShowDuration] = useState<number>(240);
  const [curfewTime, setCurfewTime] = useState<string>('01:00');

  const [dealType, setDealType] = useState<string>('flat_fee');
  const [guarantee, setGuarantee] = useState<number>(0);
  const [artistPercentage, setArtistPercentage] = useState<number>(100);
  const [taxWithholdingPct, setTaxWithholdingPct] = useState<number>(2);
  const [depositPct, setDepositPct] = useState<number>(20);
  const [artistBackendPct, setArtistBackendPct] = useState<number>(85);
  const [promoterBackendPct, setPromoterBackendPct] = useState<number>(15);
  const [depositDueTiming, setDepositDueTiming] = useState<string>('30_days_before');
  const [customDepositDate, setCustomDepositDate] = useState<string>('');
  const [artistDepositStatus, setArtistDepositStatus] = useState<string>('pending');
  const [venueDeposit, setVenueDeposit] = useState<number>(0);
  const [venueDepositDueDate, setVenueDepositDueDate] = useState<string>('');
  const [venueDepositStatus, setVenueDepositStatus] = useState<string>('pending');

  const [merchRateSoft, setMerchRateSoft] = useState<number>(100);
  const [merchRateHard, setMerchRateHard] = useState<number>(100);
  const [artistDeductions, setArtistDeductions] = useState<ArtistDeduction[]>([]);

  const [ticketTiers, setTicketTiers] = useState<TicketTier[]>([
    { type: 'GA', allotment: 0, comps: 0, price: 0 }
  ]);
  const [salesTaxPct, setSalesTaxPct] = useState<number>(13.18);
  const [compsArtist, setCompsArtist] = useState<number>(0);
  const [compsVenue, setCompsVenue] = useState<number>(0);
  const [compsPromoter, setCompsPromoter] = useState<number>(0);

  const [expenses, setExpenses] = useState<Expenses>({
    talent: { rider_hospitality: 0 },
    general: { security: 0, emt: 0, gate_staff: 0 },
    marketing: { radio: 0, marketing: 0, paid_social: 0 },
    production: { production: 0, crew_stagehands: 0, camera_operator: 0, technical_director: 0 }
  });

  const [ascapRate, setAscapRate] = useState<number>(0.0023);
  const [bmiRate, setBmiRate] = useState<number>(0.003);
  const [sesacRate, setSesacRate] = useState<number>(0.000214);
  const [insurancePerAttendee, setInsurancePerAttendee] = useState<number>(0.62);
  const [ccFeeRate, setCcFeeRate] = useState<number>(0.012);

  const [supportActs, setSupportActs] = useState<SupportAct[]>([]);

  useEffect(() => {
    loadTemplates();
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.template-selector-container')) {
        setShowTemplateSelector(false);
      }
    };

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowTemplateSelector(false);
      }
    };

    if (showTemplateSelector) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [showTemplateSelector]);

  const loadTemplates = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('templates')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error loading templates:', error);
    }
  };

  const loadTemplate = (template: Template) => {
    const data = template.template_data;

    setDealType(data.deal_type || 'flat_fee');
    setGuarantee(data.guarantee || 0);
    setArtistPercentage(data.artist_percentage || 100);
    setTaxWithholdingPct(data.tax_withholding_pct || 2);
    setDepositPct(data.deposit_pct || 20);
    setArtistBackendPct(data.artist_backend_pct || 85);
    setPromoterBackendPct(data.promoter_backend_pct || 15);
    setDepositDueTiming(data.deposit_due_timing || '30_days_before');
    setVenueDeposit(data.venue_deposit || 0);
    setMerchRateSoft(data.merch_rate_soft || 100);
    setMerchRateHard(data.merch_rate_hard || 100);
    setTicketTiers(data.ticket_tiers || [{ type: 'GA', allotment: 0, comps: 0, price: 0 }]);
    setSalesTaxPct(data.sales_tax_pct || 13.18);
    setCompsArtist(data.comps_artist || 0);
    setCompsVenue(data.comps_venue || 0);
    setCompsPromoter(data.comps_promoter || 0);
    setExpenses(data.expenses || {
      talent: { rider_hospitality: 0 },
      general: { security: 0, emt: 0, gate_staff: 0 },
      marketing: { radio: 0, marketing: 0, paid_social: 0 },
      production: { production: 0, crew_stagehands: 0, camera_operator: 0, technical_director: 0 }
    });
    setAscapRate(data.ascap_rate || 0.0023);
    setBmiRate(data.bmi_rate || 0.003);
    setSesacRate(data.sesac_rate || 0.000214);
    setInsurancePerAttendee(data.insurance_per_attendee || 0.62);
    setCcFeeRate(data.cc_fee_rate || 0.012);
    setSupportActs(data.support_acts || []);
    setFacilityFeePerTicket(data.facility_fee_per_ticket || 2.00);
    setAgeLimit(data.age_limit || 'All Ages');
    setDoorsTime(data.doors_time || '20:00');
    setDoorsDuration(data.doors_duration || 60);
    setShowTime(data.show_time || '21:00');
    setShowDuration(data.show_duration || 240);
    setCurfewTime(data.curfew_time || '01:00');

    setShowTemplateSelector(false);
    alert(`Template "${template.name}" loaded successfully!`);
  };

  const calculations = calculateOffer(
    ticketTiers,
    salesTaxPct,
    expenses,
    guarantee,
    taxWithholdingPct,
    dealType,
    mode,
    artistBackendPct,
    promoterBackendPct,
    supportActs
  );

  const steps = [
    { number: 1, label: 'Event Details' },
    { number: 2, label: 'Artist Deal' },
    { number: 3, label: 'Deposits' },
    { number: 4, label: 'Ticket Scaling' },
    { number: 5, label: 'Expenses' },
    { number: 6, label: 'Summary' },
  ];

  const handleNext = () => {
    if (currentStep === 1) {
      if (!artistName || !venueName || !eventDate || capacity === 0) {
        alert('Please fill in all event details');
        return;
      }
    }
    if (currentStep < 6) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSave = async () => {
    if (!artistName || !venueName || !eventDate || capacity === 0) {
      alert('Please fill in all event details');
      return;
    }

    setSaving(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        alert('You must be logged in to create an offer');
        navigate('/');
        return;
      }

      const showId = `show_${Date.now()}`;
      const offerId = `offer_${Date.now()}`;

      const venueFullAddress = [
        venueStreet,
        `${venueCity}${venueState ? ', ' + venueState : ''}${venueZip ? ' ' + venueZip : ''}`
      ].filter(Boolean).join('\n');

      const { error: showError } = await supabase.from('shows').insert({
        id: showId,
        event_name: eventName || null,
        artist_name: artistName,
        venue_name: venueName,
        event_date: eventDate,
        capacity: capacity,
        user_id: user.id,
      });

      if (showError) throw showError;

      const { error: offerError } = await supabase.from('offers').insert({
        id: offerId,
        show_id: showId,
        mode: mode,
        status: status,
        deal_type: dealType,
        guarantee: guarantee,
        artist_percentage: artistPercentage,
        tax_withholding_pct: taxWithholdingPct,
        deposit_pct: depositPct,
        artist_backend_pct: artistBackendPct,
        promoter_backend_pct: promoterBackendPct,
        deposit_due_timing: depositDueTiming,
        deposit_due_date: customDepositDate,
        venue_street: venueStreet,
        venue_city: venueCity,
        venue_state: venueState,
        venue_zip: venueZip,
        venue_full_address: venueFullAddress,
        artist_deposit_status: artistDepositStatus,
        venue_deposit: venueDeposit,
        venue_deposit_due_date: venueDepositDueDate,
        venue_deposit_status: venueDepositStatus,
        ticket_tiers: ticketTiers,
        sales_tax_pct: salesTaxPct,
        expenses: expenses,
        calculations: calculations,
        support_acts: supportActs,
        user_id: user.id,
        facility_fee_per_ticket: facilityFeePerTicket,
        comps_artist: compsArtist,
        comps_venue: compsVenue,
        comps_promoter: compsPromoter,
        doors_time: doorsTime,
        doors_duration: doorsDuration,
        show_time: showTime,
        show_duration: showDuration,
        curfew_time: curfewTime,
        age_limit: ageLimit,
        merch_rate_soft: merchRateSoft,
        merch_rate_hard: merchRateHard,
        artist_deductions: artistDeductions,
        ascap_rate: ascapRate,
        bmi_rate: bmiRate,
        sesac_rate: sesacRate,
        insurance_per_attendee: insurancePerAttendee,
        cc_fee_rate: ccFeeRate,
        offer_sent_date: new Date().toISOString().split('T')[0],
      });

      if (offerError) throw offerError;

      navigate('/offers');
    } catch (error) {
      console.error('Error saving offer:', error);
      alert('Failed to save offer. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/')}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Create Offer</h1>
                <p className="text-sm text-slate-600">Step {currentStep} of {steps.length}: {steps[currentStep - 1].label}</p>
              </div>
            </div>

            {templates.length > 0 && (
              <div className="relative template-selector-container">
                <button
                  onClick={() => setShowTemplateSelector(!showTemplateSelector)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition-colors flex items-center gap-2"
                >
                  <FileText className="w-4 h-4" />
                  Load Template
                </button>

                {showTemplateSelector && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-lg border border-slate-200 z-20">
                    <div className="p-2 max-h-96 overflow-y-auto">
                      {templates.map((template) => (
                        <button
                          key={template.id}
                          onClick={() => loadTemplate(template)}
                          className="w-full text-left p-3 hover:bg-slate-50 rounded-lg transition-colors"
                        >
                          <div className="font-medium text-slate-900">{template.name}</div>
                          {template.description && (
                            <div className="text-sm text-slate-600 mt-1">{template.description}</div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Step {currentStep} of {steps.length}</div>
            <div className="text-sm font-semibold text-slate-900">{steps[currentStep - 1].label}</div>
          </div>

          <div className="relative">
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-300 ease-out"
                style={{ width: `${(currentStep / steps.length) * 100}%` }}
              />
            </div>
            <div className="flex justify-between mt-3">
              {steps.map((step) => (
                <button
                  key={step.number}
                  onClick={() => setCurrentStep(step.number)}
                  className={`flex items-center justify-center w-10 h-10 rounded-full font-semibold transition-colors ${
                    step.number < currentStep
                      ? 'bg-blue-600 text-white'
                      : step.number === currentStep
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {step.number < currentStep ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    step.number
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sm:p-8">
          {currentStep === 1 && (
            <EventDetailsTab
              eventName={eventName}
              setEventName={setEventName}
              artistName={artistName}
              setArtistName={setArtistName}
              venueName={venueName}
              setVenueName={setVenueName}
              eventDate={eventDate}
              setEventDate={setEventDate}
              capacity={capacity}
              setCapacity={setCapacity}
              mode={mode}
              venueStreet={venueStreet}
              setVenueStreet={setVenueStreet}
              venueCity={venueCity}
              setVenueCity={setVenueCity}
              venueState={venueState}
              setVenueState={setVenueState}
              venueZip={venueZip}
              setVenueZip={setVenueZip}
              facilityFeePerTicket={facilityFeePerTicket}
              setFacilityFeePerTicket={setFacilityFeePerTicket}
              ageLimit={ageLimit}
              setAgeLimit={setAgeLimit}
              doorsTime={doorsTime}
              setDoorsTime={setDoorsTime}
              doorsDuration={doorsDuration}
              setDoorsDuration={setDoorsDuration}
              showTime={showTime}
              setShowTime={setShowTime}
              showDuration={showDuration}
              setShowDuration={setShowDuration}
              curfewTime={curfewTime}
              setCurfewTime={setCurfewTime}
            />
          )}

          {currentStep === 2 && (
            <ArtistDealTab
              dealType={dealType}
              setDealType={setDealType}
              guarantee={guarantee}
              setGuarantee={setGuarantee}
              artistPercentage={artistPercentage}
              setArtistPercentage={setArtistPercentage}
              taxWithholdingPct={taxWithholdingPct}
              setTaxWithholdingPct={setTaxWithholdingPct}
              depositPct={depositPct}
              setDepositPct={setDepositPct}
              artistBackendPct={artistBackendPct}
              setArtistBackendPct={setArtistBackendPct}
              promoterBackendPct={promoterBackendPct}
              setPromoterBackendPct={setPromoterBackendPct}
              supportActs={supportActs}
              setSupportActs={setSupportActs}
              merchRateSoft={merchRateSoft}
              setMerchRateSoft={setMerchRateSoft}
              merchRateHard={merchRateHard}
              setMerchRateHard={setMerchRateHard}
              artistDeductions={artistDeductions}
              setArtistDeductions={setArtistDeductions}
              ticketTiers={ticketTiers}
              salesTaxPct={salesTaxPct}
              expenses={expenses}
              facilityFeePerTicket={facilityFeePerTicket}
              ascapRate={ascapRate}
              bmiRate={bmiRate}
              sesacRate={sesacRate}
              insurancePerAttendee={insurancePerAttendee}
              ccFeeRate={ccFeeRate}
            />
          )}

          {currentStep === 3 && (
            <DepositsTab
              guarantee={guarantee}
              taxWithholdingPct={taxWithholdingPct}
              setTaxWithholdingPct={setTaxWithholdingPct}
              depositPct={depositPct}
              setDepositPct={setDepositPct}
              depositDueTiming={depositDueTiming}
              setDepositDueTiming={setDepositDueTiming}
              customDepositDate={customDepositDate}
              setCustomDepositDate={setCustomDepositDate}
              artistDepositStatus={artistDepositStatus}
              setArtistDepositStatus={setArtistDepositStatus}
              venueDeposit={venueDeposit}
              setVenueDeposit={setVenueDeposit}
              venueDepositDueDate={venueDepositDueDate}
              setVenueDepositDueDate={setVenueDepositDueDate}
              venueDepositStatus={venueDepositStatus}
              setVenueDepositStatus={setVenueDepositStatus}
              eventDate={eventDate}
            />
          )}

          {currentStep === 4 && (
            <TicketScalingTab
              ticketTiers={ticketTiers}
              setTicketTiers={setTicketTiers}
              salesTaxPct={salesTaxPct}
              setSalesTaxPct={setSalesTaxPct}
              mode={mode}
              compsArtist={compsArtist}
              setCompsArtist={setCompsArtist}
              compsVenue={compsVenue}
              setCompsVenue={setCompsVenue}
              compsPromoter={compsPromoter}
              setCompsPromoter={setCompsPromoter}
            />
          )}

          {currentStep === 5 && (
            <ExpensesTab
              expenses={expenses}
              setExpenses={setExpenses}
              ascapRate={ascapRate}
              setAscapRate={setAscapRate}
              bmiRate={bmiRate}
              setBmiRate={setBmiRate}
              sesacRate={sesacRate}
              setSesacRate={setSesacRate}
              insurancePerAttendee={insurancePerAttendee}
              setInsurancePerAttendee={setInsurancePerAttendee}
              ccFeeRate={ccFeeRate}
              setCcFeeRate={setCcFeeRate}
            />
          )}

          {currentStep === 6 && (
            <SummaryTab
              calculations={calculations}
              dealType={dealType}
              guarantee={guarantee}
              taxWithholdingPct={taxWithholdingPct}
              depositPct={depositPct}
              mode={mode}
              ticketTiers={ticketTiers}
              salesTaxPct={salesTaxPct}
              artistName={artistName}
              venueName={venueName}
              capacity={capacity}
            />
          )}
        </div>

        <div className="mt-6 flex flex-col-reverse sm:flex-row justify-between gap-3">
          <button
            onClick={currentStep === 1 ? () => navigate('/') : handlePrevious}
            className="w-full sm:w-auto px-6 py-3 text-slate-700 hover:text-slate-900 font-medium text-center border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            {currentStep === 1 ? 'Cancel' : 'Previous'}
          </button>

          {currentStep < 6 ? (
            <button
              onClick={handleNext}
              className="w-full sm:w-auto px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              Next
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full sm:w-auto px-6 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              {saving ? 'Saving...' : 'Save Offer'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
