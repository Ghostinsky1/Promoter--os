import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { OfferWithShow, OfferStatus } from '../types';
import { formatCurrency } from '../lib/calculations';
import { Search, Calendar, MapPin, Plus, DollarSign, FileText, CheckCircle, Send, Activity, CircleDollarSign, XCircle, LayoutGrid, Copy } from 'lucide-react';
import { OffersCalendar } from './OffersCalendar';
import { parseLocalDate } from '../lib/dateHelpers';

const STATUS_CONFIG: Record<OfferStatus, { label: string; icon: any; color: string; bgColor: string; borderColor: string }> = {
  planning: {
    label: 'Planning',
    icon: FileText,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200'
  },
  offer_sent: {
    label: 'Offer Sent',
    icon: Send,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    borderColor: 'border-purple-200'
  },
  confirmed: {
    label: 'Confirmed',
    icon: CheckCircle,
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200'
  },
  active: {
    label: 'Active',
    icon: Activity,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200'
  },
  settled: {
    label: 'Settled',
    icon: CircleDollarSign,
    color: 'text-teal-600',
    bgColor: 'bg-teal-50',
    borderColor: 'border-teal-200'
  },
  cancelled: {
    label: 'Cancelled',
    icon: XCircle,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200'
  }
};

export function OffersList() {
  const navigate = useNavigate();
  const [offers, setOffers] = useState<OfferWithShow[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState<OfferStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');

  useEffect(() => {
    loadOffers();
    const savedView = localStorage.getItem('offersViewMode');
    if (savedView === 'list' || savedView === 'calendar') {
      setViewMode(savedView);
    }
  }, []);

  const loadOffers = async () => {
    try {
      console.log('🔍 Loading offers...');

      const { data: { user }, error: authError } = await supabase.auth.getUser();

      if (authError) {
        console.error('❌ Auth error:', authError);
        throw authError;
      }

      if (!user) {
        console.log('⚠️ No user logged in');
        setOffers([]);
        setLoading(false);
        return;
      }

      console.log('✅ User authenticated:', user.id);

      const { data: offersData, error: offersError } = await supabase
        .from('offers')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      console.log('📊 Offers response:', { count: offersData?.length || 0, offersError });

      if (offersError) throw offersError;

      if (!offersData || offersData.length === 0) {
        console.log('📭 No offers found');
        setOffers([]);
        setLoading(false);
        return;
      }

      const showIds = [...new Set(offersData.map(o => o.show_id))];
      console.log('🎭 Fetching shows:', showIds.length);

      const { data: showsData, error: showsError } = await supabase
        .from('shows')
        .select('*')
        .in('id', showIds);

      console.log('🎪 Shows response:', { count: showsData?.length || 0, showsError });

      if (showsError) throw showsError;

      const showsMap = new Map(showsData?.map(s => [s.id, s]) || []);

      const combined = offersData
        .map(offer => ({
          ...offer,
          show: showsMap.get(offer.show_id),
        }))
        .filter(o => o.show) as OfferWithShow[];

      console.log('✅ Combined offers loaded:', combined.length);
      setOffers(combined);
    } catch (error) {
      console.error('❌ Error loading offers:', error);
      setOffers([]);
    } finally {
      setLoading(false);
    }
  };

  const updateOfferStatus = async (offerId: string, newStatus: OfferStatus) => {
    try {
      const { error } = await supabase
        .from('offers')
        .update({ status: newStatus })
        .eq('id', offerId);

      if (error) throw error;

      setOffers(offers.map(offer =>
        offer.id === offerId ? { ...offer, status: newStatus } : offer
      ));
    } catch (error) {
      console.error('Error updating offer status:', error);
      alert('Failed to update status');
    }
  };

  const duplicateOffer = async (offer: OfferWithShow) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        alert('You must be logged in to duplicate an offer');
        return;
      }

      const newShowId = `show_${Date.now()}`;
      const newOfferId = `offer_${Date.now()}`;

      const newEventName = offer.show.event_name
        ? `${offer.show.event_name} (Copy)`
        : null;
      const newArtistName = `${offer.show.artist_name} (Copy)`;

      const { error: showError } = await supabase.from('shows').insert({
        id: newShowId,
        event_name: newEventName,
        artist_name: newArtistName,
        venue_name: offer.show.venue_name,
        event_date: offer.show.event_date,
        capacity: offer.show.capacity,
        user_id: user.id,
      });

      if (showError) throw showError;

      const { error: offerError } = await supabase.from('offers').insert({
        id: newOfferId,
        show_id: newShowId,
        mode: offer.mode,
        status: 'planning',
        deal_type: offer.deal_type,
        guarantee: offer.guarantee,
        tax_withholding_pct: offer.tax_withholding_pct,
        deposit_pct: offer.deposit_pct,
        artist_backend_pct: offer.artist_backend_pct,
        promoter_backend_pct: offer.promoter_backend_pct,
        deposit_due_timing: offer.deposit_due_timing,
        deposit_due_date: offer.deposit_due_date,
        venue_street: offer.venue_street,
        venue_city: offer.venue_city,
        venue_state: offer.venue_state,
        venue_zip: offer.venue_zip,
        venue_full_address: offer.venue_full_address,
        artist_deposit_status: 'pending',
        venue_deposit: offer.venue_deposit,
        venue_deposit_due_date: offer.venue_deposit_due_date,
        venue_deposit_status: 'pending',
        ticket_tiers: offer.ticket_tiers,
        sales_tax_pct: offer.sales_tax_pct,
        expenses: offer.expenses,
        calculations: offer.calculations,
        support_acts: offer.support_acts,
        user_id: user.id,
        facility_fee_per_ticket: offer.facility_fee_per_ticket,
        comps_artist: offer.comps_artist,
        comps_venue: offer.comps_venue,
        comps_promoter: offer.comps_promoter,
        doors_time: offer.doors_time,
        doors_duration: offer.doors_duration,
        show_time: offer.show_time,
        show_duration: offer.show_duration,
        curfew_time: offer.curfew_time,
        age_limit: offer.age_limit,
        merch_rate_soft: offer.merch_rate_soft,
        merch_rate_hard: offer.merch_rate_hard,
        artist_deductions: offer.artist_deductions,
        ascap_rate: offer.ascap_rate,
        bmi_rate: offer.bmi_rate,
        sesac_rate: offer.sesac_rate,
        insurance_per_attendee: offer.insurance_per_attendee,
        cc_fee_rate: offer.cc_fee_rate,
        offer_sent_date: new Date().toISOString().split('T')[0],
      });

      if (offerError) throw offerError;

      await loadOffers();
      alert('Offer duplicated successfully!');
    } catch (error) {
      console.error('Error duplicating offer:', error);
      alert('Failed to duplicate offer');
    }
  };

  const filteredOffers = offers.filter(offer => {
    const matchesStatus = selectedStatus === 'all' || (offer.status || 'planning') === selectedStatus;
    const matchesSearch = !searchQuery ||
      (offer.show.event_name && offer.show.event_name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      offer.show.artist_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      offer.show.venue_name.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesStatus && matchesSearch;
  });

  const statusCounts = offers.reduce((acc, offer) => {
    const status = offer.status || 'planning';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const handleViewChange = (mode: 'list' | 'calendar') => {
    setViewMode(mode);
    localStorage.setItem('offersViewMode', mode);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">Loading offers...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Offers</h1>
            <p className="text-slate-600 mt-1">Manage your event offers and track their progress</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-1">
              <button
                onClick={() => handleViewChange('list')}
                className={`px-4 py-2 rounded-md font-semibold transition-all flex items-center gap-2 ${
                  viewMode === 'list'
                    ? 'bg-white shadow-sm text-blue-600'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LayoutGrid className="h-4 w-4" />
                List
              </button>
              <button
                onClick={() => handleViewChange('calendar')}
                className={`px-4 py-2 rounded-md font-semibold transition-all flex items-center gap-2 ${
                  viewMode === 'calendar'
                    ? 'bg-white shadow-sm text-blue-600'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Calendar className="h-4 w-4" />
                Calendar
              </button>
            </div>

            <button
              onClick={() => navigate('/offers/create')}
              className="w-full sm:w-auto bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Create Offer
            </button>
          </div>
        </div>

        {viewMode === 'calendar' ? (
          <OffersCalendar offers={offers} />
        ) : (
          <>
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search by artist or venue..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="mb-6 overflow-x-auto">
              <div className="flex gap-2 pb-2">
                <button
                  onClick={() => setSelectedStatus('all')}
                  className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    selectedStatus === 'all'
                      ? 'bg-slate-900 text-white'
                      : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  All ({offers.length})
                </button>
                {(Object.keys(STATUS_CONFIG) as OfferStatus[]).map((status) => {
                  const config = STATUS_CONFIG[status];
                  const Icon = config.icon;
                  const count = statusCounts[status] || 0;

                  return (
                    <button
                      key={status}
                      onClick={() => setSelectedStatus(status)}
                      className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-2 ${
                        selectedStatus === status
                          ? `${config.bgColor} ${config.color} border-2 ${config.borderColor}`
                          : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {config.label} ({count})
                    </button>
                  );
                })}
              </div>
            </div>

            {filteredOffers.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
                <FileText className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">
                  {searchQuery || selectedStatus !== 'all' ? 'No offers found' : 'No offers yet'}
                </h3>
                <p className="text-slate-600 mb-6">
                  {searchQuery || selectedStatus !== 'all'
                    ? 'Try adjusting your filters or search terms'
                    : 'Create your first offer to get started'}
                </p>
                {!searchQuery && selectedStatus === 'all' && (
                  <button
                    onClick={() => navigate('/offers/create')}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Create Your First Offer
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredOffers.map((offer) => {
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);

                  const eventDate = parseLocalDate(offer.show.event_date);
                  const formattedDate = eventDate ? eventDate.toLocaleDateString('en-US', {
                    year: 'numeric',
                    day: 'numeric',
                    month: 'short'
                  }) : 'Invalid date';

                  const artistDeposit = (offer.guarantee * offer.deposit_pct) / 100;
                  const venueDeposit = offer.venue_deposit || 0;
                  const marketingTotal = Object.values(offer.expenses.marketing || {}).reduce((sum, val) => sum + val, 0);
                  const upfrontMoney = artistDeposit + venueDeposit + marketingTotal;

                  const currentStatus = (offer.status || 'planning') as OfferStatus;
                  const statusConfig = STATUS_CONFIG[currentStatus];
                  const StatusIcon = statusConfig.icon;

                  return (
                    <div
                      key={offer.id}
                      className="bg-white rounded-lg shadow-sm border border-slate-200 hover:shadow-md transition-shadow overflow-hidden"
                    >
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1 min-w-0">
                            <h3 className="text-lg font-bold text-slate-900 truncate">
                              {offer.show.event_name || offer.show.artist_name}
                            </h3>
                            {offer.show.event_name && (
                              <p className="text-sm text-slate-600">{offer.show.artist_name}</p>
                            )}
                            <div className="flex items-center gap-1 text-sm text-slate-600 mt-1">
                              <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                              <span className="truncate">{offer.show.venue_name}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
                          <Calendar className="w-4 h-4 flex-shrink-0" />
                          <span>{formattedDate}</span>
                        </div>

                        <div className="mb-3">
                          <select
                            value={currentStatus}
                            onChange={(e) => updateOfferStatus(offer.id, e.target.value as OfferStatus)}
                            className={`w-full px-3 py-2 rounded-lg border-2 ${statusConfig.borderColor} ${statusConfig.bgColor} ${statusConfig.color} font-medium text-sm focus:outline-none focus:ring-2 focus:ring-blue-500`}
                            onClick={(e) => e.stopPropagation()}
                          >
                            {(Object.keys(STATUS_CONFIG) as OfferStatus[]).map((status) => (
                              <option key={status} value={status}>
                                {STATUS_CONFIG[status].label}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-2 mb-3">
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-slate-600">Guarantee</span>
                            <span className="font-semibold text-slate-900">
                              {formatCurrency(offer.guarantee)}
                            </span>
                          </div>
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-slate-600">Upfront Needed</span>
                            <span className="font-semibold text-orange-600">
                              {formatCurrency(upfrontMoney)}
                            </span>
                          </div>
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-slate-600">Net Profit</span>
                            <span className={`font-semibold ${
                              offer.calculations.netProfit >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {formatCurrency(offer.calculations.netProfit)}
                            </span>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <button
                            onClick={() => navigate(`/offers/${offer.id}`)}
                            className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-900 px-4 py-2 rounded-lg font-medium transition-colors text-sm"
                          >
                            View Details
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              duplicateOffer(offer);
                            }}
                            className="bg-blue-100 hover:bg-blue-200 text-blue-700 px-3 py-2 rounded-lg transition-colors"
                            title="Duplicate offer"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
