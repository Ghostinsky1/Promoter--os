/*
  # Add Backend Split Percentages

  1. Changes
    - Add `artist_backend_pct` column to `offers` table (default 85%)
    - Add `promoter_backend_pct` column to `offers` table (default 15%)
  
  2. Purpose
    - Allow customization of backend split percentages in Promoter Profit deals
    - Previously hardcoded to 85/15, now fully customizable per offer
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'artist_backend_pct'
  ) THEN
    ALTER TABLE offers ADD COLUMN artist_backend_pct numeric DEFAULT 85;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'offers' AND column_name = 'promoter_backend_pct'
  ) THEN
    ALTER TABLE offers ADD COLUMN promoter_backend_pct numeric DEFAULT 15;
  END IF;
END $$;