import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { OfferWithShow, CompanySettings } from '../types';

export function generateOfferPDF(offer: OfferWithShow, companySettings?: CompanySettings, preview: boolean = false, costsOnly: boolean = false) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'letter'
  });

  const margin = 40;
  const pageWidth = 612;
  const contentWidth = pageWidth - (margin * 2);
  const leftColX = margin;
  const rightColX = margin + 250;
  const leftColWidth = 230;
  const rightColWidth = 302;

  const facilityFee = offer.facility_fee_per_ticket || 2.00;
  const totalAllotment = offer.ticket_tiers.reduce((sum, t) => sum + t.allotment, 0);
  const totalComps = offer.ticket_tiers.reduce((sum, t) => sum + t.comps, 0);
  const totalSellable = totalAllotment - totalComps;

  const grossPotential = offer.ticket_tiers.reduce((sum, t) => sum + (t.allotment * t.price), 0);
  const totalFacilityFee = totalSellable * facilityFee;
  const adjustedGrossPotential = grossPotential - totalFacilityFee;
  const salesTaxAmount = adjustedGrossPotential * (offer.sales_tax_pct / 100);
  const netGrossPotential = adjustedGrossPotential - salesTaxAmount;

  const ascapFee = netGrossPotential * (offer.ascap_rate || 0.0023);
  const bmiFee = netGrossPotential * (offer.bmi_rate || 0.003);
  const sesacFee = netGrossPotential * (offer.sesac_rate || 0.000214);
  const insuranceFee = totalSellable * (offer.insurance_per_attendee || 0.62);
  const ccFee = netGrossPotential * (offer.cc_fee_rate || 0.012);
  const totalVariableExpenses = ascapFee + bmiFee + sesacFee + insuranceFee + ccFee;

  const artistDeductions = (offer.artist_deductions as any[] || []).reduce((sum: number, d: any) => sum + (d.amount || 0), 0);
  const totalFixedExpenses = offer.calculations.totalExpenses;
  const splitPointTotal = totalFixedExpenses + totalVariableExpenses;

  const netRevenue = netGrossPotential - splitPointTotal;

  // Use the actual calculated artist payout from calculations
  const artistWalkout = offer.calculations.artistTotalPayout || (netRevenue - artistDeductions);

  let y = 40;

  if (companySettings?.logo_url) {
    try {
      doc.addImage(companySettings.logo_url, 'PNG', leftColX, y, 100, 30);
      y += 50;
    } catch (error) {
      console.error('Failed to add logo:', error);
      y += 20;
    }
  } else {
    y = 70;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(24);
  doc.setTextColor(139, 92, 246);
  doc.text(offer.show.artist_name, leftColX, y);

  y += 22;
  doc.setFontSize(16);
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  doc.text(formatDateLong(offer.show.event_date), leftColX, y);

  y += 25;
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(offer.show.venue_name, leftColX, y);

  y += 18;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);

  if (offer.venue_full_address) {
    const addressLines = offer.venue_full_address.split('\n').filter(line => line.trim());
    addressLines.forEach(line => {
      doc.text(line, leftColX, y);
      y += 13;
    });
  }

  doc.setTextColor(0, 0, 0);

  y += 15;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Headliner Offer', leftColX, y);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Total Potential Payout', rightColX, y);
  doc.setTextColor(22, 163, 74);
  doc.setFontSize(11);
  doc.text(formatMoney(Math.max(0, artistWalkout)), pageWidth - margin, y, { align: 'right' });
  doc.setTextColor(0, 0, 0);

  const rightStartY = y;
  y += 16;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(139, 92, 246);

  let dealDescription = '';
  if (offer.deal_type === 'flat_guarantee' || offer.deal_type === 'flat_fee') {
    dealDescription = `${formatMoney(offer.guarantee)} Flat Guarantee`;
  } else if (offer.deal_type === 'promoter_profit') {
    const artistPct = offer.artist_percentage || 100;
    dealDescription = `${artistPct.toFixed(2)}% of Net Revenue after Taxes, Fees, and ${formatMoney(totalFixedExpenses)}`;
  } else {
    dealDescription = `100.00% of Net Revenue after Taxes, Fees, and ${formatMoney(totalFixedExpenses)}`;
  }

  const dealLines = doc.splitTextToSize(dealDescription, leftColWidth - 10);
  dealLines.forEach((line: string) => {
    doc.text(line, leftColX, y);
    y += 12;
  });

  doc.setTextColor(0, 0, 0);

  if (artistDeductions > 0) {
    y += 3;
    (offer.artist_deductions as any[] || []).forEach((deduction: any) => {
      doc.text(deduction.name, leftColX, y);
      doc.text(formatMoney(-deduction.amount), leftColX + leftColWidth - 10, y, { align: 'right' });
      y += 12;
    });
  }

  doc.setFontSize(10);

  y += 20;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Event Details', leftColX, y);
  y += 14;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);

  const eventDetails = [
    ['Age Limit', offer.age_limit || 'All Ages'],
    ['Artist Merch Rate', `${offer.merch_rate_soft || 100}% soft (artist sells)\n${offer.merch_rate_hard || 100}% hard (artist sells)`],
    ['Offer Sent', offer.offer_sent_date ? formatDateShort(offer.offer_sent_date) : formatDateShort(new Date())],
    ['Event Date(s)', formatDateShort(offer.show.event_date)],
  ];

  if (offer.doors_time) {
    const doorsDay = formatDayOfWeek(offer.show.event_date);
    const doorsShort = doorsDay.substring(0, 3);
    const dateShort = new Date(offer.show.event_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    eventDetails.push(['Doors', `${offer.doors_time} (${offer.doors_duration || 60}min) ${doorsShort}, ${dateShort}`]);
  }
  if (offer.show_time) {
    eventDetails.push(['Show', `${offer.show_time} (${offer.show_duration || 120}min)`]);
  }
  if (offer.curfew_time) {
    const curfewDay = formatDayOfWeek(offer.show.event_date);
    const curfewShort = curfewDay.substring(0, 3);
    const dateShort = new Date(offer.show.event_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    eventDetails.push(['Curfew', `${offer.curfew_time} ${curfewShort}, ${dateShort}`]);
  }

  eventDetails.forEach(([label, value]) => {
    doc.setFont('helvetica', 'bold');
    doc.text(label, leftColX, y);
    doc.setFont('helvetica', 'normal');
    const valueLines = value.split('\n');
    valueLines.forEach((line, idx) => {
      doc.text(line, leftColX + 85, y + (idx * 11));
    });
    y += 11 * valueLines.length + 2;
  });

  let rightY = rightStartY;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Event Summary', rightColX, rightY);
  rightY += 14;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);

  const summaryItems = [
    ['Gross Potential', grossPotential, false],
    [`Total Facility Fee (${formatMoney(facilityFee)} per ticket)`, -totalFacilityFee, false],
    ['Adjusted Gross Potential', adjustedGrossPotential, true],
    [`Ticket Sales Tax (${offer.sales_tax_pct}% sales tax)`, -salesTaxAmount, false],
    ['Net Gross Potential', netGrossPotential, true],
    ['Fixed Expenses', -totalFixedExpenses, false],
    ['Variable Expenses', -totalVariableExpenses, false],
    ['100% of Net Revenue', netRevenue, true],
  ];

  summaryItems.forEach(([label, amount, isBold]) => {
    if (isBold) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
    }
    doc.text(label as string, rightColX, rightY);
    doc.text(formatMoney(amount as number), pageWidth - margin, rightY, { align: 'right' });
    if (isBold) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      rightY += 15;
    } else {
      rightY += 13;
    }
  });

  const maxY = Math.max(y, rightY);

  y = maxY + 15;

  if (!costsOnly) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Ticket Scaling', leftColX, y);
    y += 12;

    const tableData = offer.ticket_tiers.map(tier => {
      const sellable = tier.allotment - tier.comps;
      const netPrice = tier.price - facilityFee;
      const breakEven = Math.ceil(splitPointTotal / netPrice);
      const tierGross = tier.allotment * tier.price;
      return [
        tier.type,
        tier.allotment.toString(),
        tier.comps.toString(),
        sellable.toString(),
        '$' + tier.price.toFixed(2),
        '-$' + facilityFee.toFixed(2),
        '$' + netPrice.toFixed(2),
        breakEven.toString(),
        formatMoney(tierGross)
      ];
    });

    autoTable(doc, {
      startY: y,
      margin: { left: leftColX, right: margin },
      tableWidth: contentWidth,
      head: [[
        'Type',
        'Allotment',
        'Comps',
        'Sellable',
        'Ticket Price',
        'Per Ticket Fees',
        'Net Price',
        'Break Even',
        'Adjusted Gross\nPotential'
      ]],
      body: tableData,
      foot: [[
        'Totals:',
        totalAllotment.toString(),
        totalComps.toString(),
        totalSellable.toString(),
        '',
        '',
        '',
        '',
        formatMoney(adjustedGrossPotential)
      ]],
      theme: 'grid',
      styles: {
        fontSize: 8,
        cellPadding: 4,
        lineColor: [200, 200, 200],
        lineWidth: 0.5,
        textColor: [0, 0, 0],
        halign: 'center'
      },
      headStyles: {
        fillColor: [245, 245, 245],
        textColor: [0, 0, 0],
        fontStyle: 'bold',
        halign: 'center',
        valign: 'middle',
        minCellHeight: 24
      },
      bodyStyles: {
        minCellHeight: 20,
        halign: 'center'
      },
      footStyles: {
        fillColor: [245, 245, 245],
        fontStyle: 'bold',
        minCellHeight: 22,
        halign: 'center'
      },
      columnStyles: {
        0: { cellWidth: 'auto', halign: 'left', minCellWidth: 40 },
        1: { cellWidth: 'auto', halign: 'center' },
        2: { cellWidth: 'auto', halign: 'center' },
        3: { cellWidth: 'auto', halign: 'center' },
        4: { cellWidth: 'auto', halign: 'right' },
        5: { cellWidth: 'auto', halign: 'right' },
        6: { cellWidth: 'auto', halign: 'right' },
        7: { cellWidth: 'auto', halign: 'center' },
        8: { cellWidth: 'auto', halign: 'right', minCellWidth: 70 }
      },
      pageBreak: 'avoid'
    });

    y = (doc as any).lastAutoTable.finalY + 8;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`Ticket Sales Tax (${offer.sales_tax_pct}% sales tax)`, leftColX, y);
    doc.text(formatMoney(-salesTaxAmount), pageWidth - margin, y, { align: 'right' });

    y += 15;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('Net Gross Potential', leftColX, y);
    doc.text(formatMoney(netGrossPotential), pageWidth - margin, y, { align: 'right' });

    y += 25;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Split Point Summary', leftColX, y);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`Total: ${formatMoney(splitPointTotal)}`, pageWidth - margin, y, { align: 'right' });
    y += 15;

    doc.setFont('helvetica', 'bold');
    doc.text('Fixed Expenses', leftColX, y);
    doc.text(formatMoney(totalFixedExpenses), pageWidth - margin, y, { align: 'right' });
    y += 15;

    if (artistDeductions > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text('Adjustments Included In Split', leftColX, y);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text('Total', pageWidth - 160, y, { align: 'left' });
      y += 13;

      (offer.artist_deductions as any[] || []).forEach((deduction: any) => {
        doc.text(deduction.name, leftColX, y);
        doc.text(formatMoney(-deduction.amount), leftColX + 180, y);
        y += 12;
      });

      y += 4;
      doc.setFont('helvetica', 'bold');
      doc.text('Total', leftColX, y);
      doc.text(formatMoney(-artistDeductions), leftColX + 180, y);
      y += 18;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Variable Expenses', leftColX, y);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(formatMoney(totalVariableExpenses), pageWidth - margin, y, { align: 'right' });
    y += 12;

    const variableExpenseData = [
      ['ASCAP', `${((offer.ascap_rate || 0.0023) * 100).toFixed(4)}%`, formatMoney(ascapFee)],
      ['BMI', `${((offer.bmi_rate || 0.003) * 100).toFixed(4)}%`, formatMoney(bmiFee)],
      ['Insurance', `${formatMoney(offer.insurance_per_attendee || 0.62)} per attendee`, formatMoney(insuranceFee)],
      ['CC Fee', `${((offer.cc_fee_rate || 0.012) * 100).toFixed(2)}%`, formatMoney(ccFee)],
      ['SESAC', `${((offer.sesac_rate || 0.000214) * 100).toFixed(4)}%`, formatMoney(sesacFee)],
    ];

    autoTable(doc, {
      startY: y,
      margin: { left: leftColX, right: margin },
      tableWidth: contentWidth,
      head: [['Type', 'Amount', 'Total Potential']],
      body: variableExpenseData,
      foot: [['Totals:', '', formatMoney(totalVariableExpenses)]],
      theme: 'grid',
      styles: {
        fontSize: 8,
        cellPadding: 4,
        lineColor: [200, 200, 200],
        lineWidth: 0.5
      },
      headStyles: {
        fillColor: [245, 245, 245],
        textColor: [0, 0, 0],
        fontStyle: 'bold',
        halign: 'center',
        minCellHeight: 22
      },
      bodyStyles: {
        minCellHeight: 18
      },
      footStyles: {
        fontStyle: 'bold',
        fillColor: [245, 245, 245],
        minCellHeight: 22
      },
      columnStyles: {
        0: { halign: 'left', cellWidth: 90 },
        1: { halign: 'left', cellWidth: 200 },
        2: { halign: 'right', cellWidth: 'auto' }
      }
    });

    y = (doc as any).lastAutoTable.finalY + 18;

    // Support Acts section
    if (offer.support_acts && offer.support_acts.length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text('Support Acts', leftColX, y);
      y += 14;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);

      offer.support_acts.forEach((act: any) => {
        const actType = act.type.charAt(0).toUpperCase() + act.type.slice(1);
        doc.setFont('helvetica', 'bold');
        doc.text(`(${actType}) ${act.name}`, leftColX, y);
        doc.setFont('helvetica', 'normal');
        doc.text(formatMoney(act.guarantee), leftColX + leftColWidth - 10, y, { align: 'right' });
        y += 11;
        if (act.set_length) {
          doc.text(`Set Length: ${act.set_length} min`, leftColX + 5, y);
          y += 11;
        }
        y += 3;
      });

      y += 8;
    }

    if (offer.holds && offer.holds.length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text('Holds', leftColX, y);
      y += 13;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);

      offer.holds.forEach((hold: string) => {
        doc.text(hold, leftColX, y);
        y += 12;
      });
    }
  }

  const footerY = 750;
  doc.setFontSize(9);
  doc.setTextColor(59, 130, 246);
  const importUrl = `https://atlas-promoter.com/import-offer/${offer.id}`;
  doc.textWithLink('Click to import offer into PromoterOS', leftColX, footerY, {
    url: importUrl
  });

  doc.setFontSize(8);
  doc.setTextColor(128, 128, 128);
  doc.text(`Powered by ${companySettings?.company_name || 'Atlas'}`, pageWidth - margin, footerY, { align: 'right' });

  doc.addPage();
  let page2Y = 60;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(0, 0, 0);
  doc.text('Contacts', leftColX, page2Y);
  page2Y += 22;

  if (companySettings) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Promoter Contact', leftColX, page2Y);
    page2Y += 16;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);

    if (companySettings.company_name) {
      doc.text(`Company: ${companySettings.company_name}`, leftColX, page2Y);
      page2Y += 13;
    }
    if (companySettings.contact_name) {
      doc.text(`Contact: ${companySettings.contact_name}`, leftColX, page2Y);
      page2Y += 13;
    }
    if (companySettings.email) {
      doc.text(`Email: ${companySettings.email}`, leftColX, page2Y);
      page2Y += 13;
    }
    if (companySettings.phone) {
      doc.text(`Phone: ${companySettings.phone}`, leftColX, page2Y);
      page2Y += 13;
    }

    page2Y += 18;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text('Expense Breakdown', leftColX, page2Y);
  page2Y += 25;

  const expenseCategories = [
    { title: 'General', expenses: offer.expenses.general },
    { title: 'Talent Pay Included in Split', expenses: offer.expenses.talent },
    { title: 'Production', expenses: offer.expenses.production },
    { title: 'Marketing', expenses: offer.expenses.marketing }
  ];

  expenseCategories.forEach(category => {
    const categoryTotal = Object.values(category.expenses).reduce((sum, val) => sum + val, 0);

    if (categoryTotal > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text(category.title, leftColX, page2Y);
      page2Y += 18;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);

      Object.entries(category.expenses).forEach(([name, amount]) => {
        if (amount > 0) {
          const displayName = name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
          doc.text(displayName, leftColX, page2Y);
          doc.text(formatMoney(amount), pageWidth - margin, page2Y, { align: 'right' });
          page2Y += 14;
        }
      });

      doc.setFont('helvetica', 'bold');
      doc.text('Totals', leftColX, page2Y);
      doc.text(formatMoney(categoryTotal), pageWidth - margin, page2Y, { align: 'right' });
      page2Y += 22;
    }
  });

  if (companySettings?.legal_terms) {
    page2Y += 8;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(15);
    doc.text('Additional Terms and Conditions', leftColX, page2Y);
    page2Y += 22;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(60, 60, 60);

    const terms = companySettings.legal_terms.split('\n').filter(line => line.trim());
    terms.forEach(term => {
      if (page2Y > 730) {
        doc.addPage();
        page2Y = 60;
      }
      const lines = doc.splitTextToSize(term, contentWidth);
      lines.forEach((line: string) => {
        doc.text(line, leftColX, page2Y);
        page2Y += 12;
      });
      page2Y += 4;
    });

    doc.setTextColor(0, 0, 0);
  }

  if (preview) {
    const pdfBlob = doc.output('blob');
    const pdfUrl = URL.createObjectURL(pdfBlob);
    window.open(pdfUrl, '_blank');
  } else {
    const baseName = (offer.show.event_name || offer.show.artist_name).replace(/\s+/g, '_');
    const filename = `${baseName}_Offer_${formatDate(offer.show.event_date)}.pdf`;
    doc.save(filename);
  }
}

function formatMoney(amount: number): string {
  const absAmount = Math.abs(amount);
  const formatted = absAmount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  return amount < 0 ? `-$${formatted}` : `$${formatted}`;
}

function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatDateShort(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

function formatDateLong(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

function formatDayOfWeek(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { weekday: 'long' });
}
