/*
  # Add Event Name to Shows

  1. Changes
    - Add `event_name` column to `shows` table
      - Optional text field for custom event names
      - Allows promoters to label events with custom names like "Summer Festival 2024" or "Holiday Show"
    
  2. Notes
    - Field is optional - if empty, UI will fall back to showing artist name
    - Existing shows will have NULL event_name (backward compatible)
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'shows' AND column_name = 'event_name'
  ) THEN
    ALTER TABLE shows ADD COLUMN event_name text;
  END IF;
END $$;