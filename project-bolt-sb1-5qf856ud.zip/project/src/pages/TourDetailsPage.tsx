import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Calendar, Music2, MapPin, Users, Plus, Download, Edit, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { TourWithDates } from '../types';
import { formatCurrency } from '../lib/calculations';
import { parseLocalDate } from '../lib/dateHelpers';

export function TourDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [tour, setTour] = useState<TourWithDates | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAddShow, setShowAddShow] = useState(false);
  const [availableOffers, setAvailableOffers] = useState<any[]>([]);
  const [settlements, setSettlements] = useState<any[]>([]);

  useEffect(() => {
    if (id) {
      loadTourData();
      loadAvailableOffers();
      loadSettlements();
    }
  }, [id]);

  const loadTourData = async () => {
    try {
      const { data: tourData } = await supabase
        .from('tours')
        .select('*')
        .eq('id', id)
        .single();

      if (tourData) {
        const { data: offers } = await supabase
          .from('offers')
          .select('*, show:shows(*)')
          .eq('tour_id', id)
          .order('show_number', { ascending: true });

        const dates = offers?.map((offer: any) => ({
          offer_id: offer.id,
          event_date: offer.show.event_date,
          venue_name: offer.show.venue_name,
          city: offer.show.venue_name.split(',')[1]?.trim() || 'TBD',
          capacity: offer.show.capacity,
          net_profit: offer.calculations?.netProfit || 0,
          gross_potential: offer.calculations?.grossPotential || 0,
          total_expenses: offer.calculations?.totalExpenses || 0,
          status: offer.status || 'planning',
          show_number: offer.show_number || 0
        })) || [];

        const projected_revenue = dates.reduce((sum, d) => {
          const revenue = parseFloat(d.gross_potential) || 0;
          return sum + revenue;
        }, 0);

        const total_costs = dates.reduce((sum, d) => {
          const costs = parseFloat(d.total_expenses) || 0;
          return sum + costs;
        }, 0);

        const net_profit = dates.reduce((sum, d) => {
          const profit = parseFloat(d.net_profit) || 0;
          return sum + profit;
        }, 0);

        console.log('=== TOUR CALCULATIONS ===');
        console.log('Number of shows:', dates.length);
        console.log('Projected Revenue:', projected_revenue);
        console.log('Total Costs:', total_costs);
        console.log('Net Profit:', net_profit);
        console.log('Shows data:', dates);

        setTour({
          ...tourData,
          dates,
          projected_revenue,
          total_costs,
          net_profit
        });
      }
    } catch (error) {
      console.error('Error loading tour:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAvailableOffers = async () => {
    try {
      const { data } = await supabase
        .from('offers')
        .select('*, show:shows(*)')
        .is('tour_id', null);

      if (data) {
        setAvailableOffers(data);
      }
    } catch (error) {
      console.error('Error loading offers:', error);
    }
  };

  const loadSettlements = async () => {
    try {
      const { data: offers } = await supabase
        .from('offers')
        .select('id')
        .eq('tour_id', id);

      if (offers && offers.length > 0) {
        const offerIds = offers.map(o => o.id);

        const { data: settlementsData } = await supabase
          .from('settlements')
          .select('*')
          .in('offer_id', offerIds);

        if (settlementsData) {
          setSettlements(settlementsData);
        }
      }
    } catch (error) {
      console.error('Error loading settlements:', error);
    }
  };

  const calculateSettlementTotals = () => {
    if (settlements.length === 0) {
      return null;
    }

    const actual_revenue = settlements.reduce((sum, s) => {
      const revenue = parseFloat(s.actual_revenue) || 0;
      return sum + revenue;
    }, 0);

    const actual_expenses = settlements.reduce((sum, s) => {
      const expenses = parseFloat(s.actual_total_expenses) || 0;
      return sum + expenses;
    }, 0);

    const actual_profit = settlements.reduce((sum, s) => {
      const profit = parseFloat(s.actual_net_profit) || 0;
      return sum + profit;
    }, 0);

    const projected_revenue = settlements.reduce((sum, s) => {
      const revenue = parseFloat(s.projected_revenue) || 0;
      return sum + revenue;
    }, 0);

    const projected_expenses = settlements.reduce((sum, s) => {
      const expenses = parseFloat(s.projected_expenses) || 0;
      return sum + expenses;
    }, 0);

    const projected_profit = settlements.reduce((sum, s) => {
      const profit = parseFloat(s.projected_profit) || 0;
      return sum + profit;
    }, 0);

    return {
      actual_revenue,
      actual_expenses,
      actual_profit,
      projected_revenue,
      projected_expenses,
      projected_profit,
      variance_revenue: actual_revenue - projected_revenue,
      variance_expenses: actual_expenses - projected_expenses,
      variance_profit: actual_profit - projected_profit,
      settled_count: settlements.length
    };
  };

  const addShowToTour = async (offerId: string) => {
    try {
      const nextShowNumber = (tour?.dates?.length || 0) + 1;

      const { error } = await supabase
        .from('offers')
        .update({
          tour_id: id,
          show_number: nextShowNumber
        })
        .eq('id', offerId);

      if (error) throw error;

      loadTourData();
      loadAvailableOffers();
      setShowAddShow(false);
    } catch (error) {
      console.error('Error adding show to tour:', error);
      alert('Failed to add show to tour');
    }
  };

  if (loading) {
    return <div className="min-h-screen bg-slate-50 flex items-center justify-center">Loading...</div>;
  }

  if (!tour) {
    return <div className="min-h-screen bg-slate-50 flex items-center justify-center">Tour not found</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={() => navigate('/tours')}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{tour.name}</h1>
              <div className="flex items-center gap-4 text-sm opacity-90">
                <span className="flex items-center gap-2">
                  <Music2 className="h-4 w-4" />
                  {tour.artist_name}
                </span>
                <span className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {new Date(tour.start_date).toLocaleDateString()} - {new Date(tour.end_date).toLocaleDateString()}
                </span>
                <span className="bg-white/20 px-2.5 py-1 rounded-full text-xs font-medium">
                  {tour.status}
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl">
              <div className="text-sm opacity-90 mb-1">Total Shows</div>
              <div className="text-3xl font-bold">{tour.dates?.length || 0}</div>
            </div>

            <div className="p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl">
              <div className="text-sm opacity-90 mb-1">Projected Revenue</div>
              <div className="text-3xl font-bold">
                {formatCurrency(tour.projected_revenue || 0)}
              </div>
              <div className="text-xs opacity-75 mt-1">
                Gross potential
              </div>
            </div>

            <div className="p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl">
              <div className="text-sm opacity-90 mb-1">Total Costs</div>
              <div className="text-3xl font-bold">
                {formatCurrency(tour.total_costs || 0)}
              </div>
              <div className="text-xs opacity-75 mt-1">
                All expenses
              </div>
            </div>

            <div className="p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl">
              <div className="text-sm opacity-90 mb-1">Net Profit</div>
              <div className={`text-3xl font-bold ${
                (tour.net_profit || 0) >= 0 ? 'text-green-300' : 'text-red-300'
              }`}>
                {(tour.net_profit || 0) >= 0 ? '+' : ''}{formatCurrency(tour.net_profit || 0)}
              </div>
              <div className="text-xs opacity-75 mt-1">
                Avg: {formatCurrency((tour.net_profit || 0) / Math.max(tour.dates?.length || 1, 1))} per show
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {calculateSettlementTotals() && (
          <div className="bg-white border border-slate-200 rounded-xl p-6 mb-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Settlement Overview</h3>
                <p className="text-sm text-slate-600 mt-1">
                  {calculateSettlementTotals()!.settled_count} of {tour?.dates?.length || 0} shows settled
                </p>
              </div>
              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                Settled Events
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Revenue Comparison */}
              <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border border-green-200">
                <div className="text-sm font-semibold text-slate-700 mb-3">Revenue</div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-600">Projected:</span>
                    <span className="text-sm font-bold text-slate-700">
                      {formatCurrency(calculateSettlementTotals()!.projected_revenue)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-600">Actual:</span>
                    <span className="text-sm font-bold text-green-700">
                      {formatCurrency(calculateSettlementTotals()!.actual_revenue)}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-green-200">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold text-slate-700">Variance:</span>
                      <span className={`text-sm font-bold ${
                        calculateSettlementTotals()!.variance_revenue >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {calculateSettlementTotals()!.variance_revenue >= 0 ? '+' : ''}
                        {formatCurrency(calculateSettlementTotals()!.variance_revenue)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Expenses Comparison */}
              <div className="p-4 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl border border-orange-200">
                <div className="text-sm font-semibold text-slate-700 mb-3">Expenses</div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-600">Projected:</span>
                    <span className="text-sm font-bold text-slate-700">
                      {formatCurrency(calculateSettlementTotals()!.projected_expenses)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-600">Actual:</span>
                    <span className="text-sm font-bold text-orange-700">
                      {formatCurrency(calculateSettlementTotals()!.actual_expenses)}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-orange-200">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold text-slate-700">Variance:</span>
                      <span className={`text-sm font-bold ${
                        calculateSettlementTotals()!.variance_expenses <= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {calculateSettlementTotals()!.variance_expenses >= 0 ? '+' : ''}
                        {formatCurrency(calculateSettlementTotals()!.variance_expenses)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Profit Comparison */}
              <div className="p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl border border-purple-200">
                <div className="text-sm font-semibold text-slate-700 mb-3">Net Profit</div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-600">Projected:</span>
                    <span className="text-sm font-bold text-slate-700">
                      {formatCurrency(calculateSettlementTotals()!.projected_profit)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-600">Actual:</span>
                    <span className={`text-sm font-bold ${
                      calculateSettlementTotals()!.actual_profit >= 0 ? 'text-purple-700' : 'text-red-700'
                    }`}>
                      {formatCurrency(calculateSettlementTotals()!.actual_profit)}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-purple-200">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold text-slate-700">Variance:</span>
                      <span className={`text-sm font-bold ${
                        calculateSettlementTotals()!.variance_profit >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {calculateSettlementTotals()!.variance_profit >= 0 ? '+' : ''}
                        {formatCurrency(calculateSettlementTotals()!.variance_profit)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Overall Performance Indicator */}
            <div className="mt-4 p-4 bg-slate-50 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-semibold text-slate-700">Overall Performance</div>
                  <div className="text-xs text-slate-600 mt-1">
                    Settled shows performing {calculateSettlementTotals()!.variance_profit >= 0 ? 'better' : 'worse'} than projected
                  </div>
                </div>
                <div className={`text-2xl font-bold ${
                  calculateSettlementTotals()!.variance_profit >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {((calculateSettlementTotals()!.actual_profit / Math.max(calculateSettlementTotals()!.projected_profit, 1)) * 100).toFixed(1)}%
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-900">Tour Dates</h3>
            <button
              onClick={() => setShowAddShow(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
            >
              <Plus className="h-4 w-4" />
              Add Show
            </button>
          </div>

          <div className="space-y-3">
            {tour.dates && tour.dates.length > 0 ? (
              tour.dates.map((show, index) => (
                <div
                  key={show.offer_id}
                  className="p-4 border border-slate-200 rounded-lg hover:shadow-md transition-all cursor-pointer"
                  onClick={() => navigate(`/offers/${show.offer_id}`)}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-lg flex flex-col items-center justify-center flex-shrink-0">
                      {(() => {
                        const eventDate = parseLocalDate(show.event_date);
                        return eventDate ? (
                          <>
                            <div className="text-xs opacity-80">
                              {eventDate.toLocaleDateString('en-US', { month: 'short' })}
                            </div>
                            <div className="text-2xl font-bold">
                              {eventDate.getDate()}
                            </div>
                          </>
                        ) : (
                          <div className="text-xs">Invalid</div>
                        );
                      })()}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-bold text-slate-900">{show.venue_name}</h4>
                        <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700">
                          {show.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {show.city}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {show.capacity}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-xs text-slate-600 mb-1">Revenue</div>
                          <div className="text-sm font-bold text-green-600">
                            {formatCurrency(show.gross_potential || 0)}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-600 mb-1">Costs</div>
                          <div className="text-sm font-bold text-orange-600">
                            {formatCurrency(show.total_expenses || 0)}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-600 mb-1">Profit</div>
                          <div className={`text-sm font-bold ${
                            (show.net_profit || 0) >= 0 ? 'text-purple-600' : 'text-red-600'
                          }`}>
                            {formatCurrency(show.net_profit || 0)}
                          </div>
                        </div>
                      </div>
                    </div>

                    <ChevronRight className="h-5 w-5 text-slate-400" />
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-slate-500">
                <Calendar className="h-12 w-12 mx-auto mb-3 text-slate-400" />
                <p>No shows added yet</p>
                <button
                  onClick={() => setShowAddShow(true)}
                  className="mt-2 text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  Add your first show
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {showAddShow && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-slate-900">Add Show to Tour</h2>
                <button
                  onClick={() => setShowAddShow(false)}
                  className="p-2 hover:bg-slate-100 rounded-lg"
                >
                  ×
                </button>
              </div>

              <div className="space-y-3">
                {availableOffers.length > 0 ? (
                  availableOffers.map((offer) => (
                    <div
                      key={offer.id}
                      className="p-4 border border-slate-200 rounded-lg hover:border-indigo-500 cursor-pointer transition-all"
                      onClick={() => addShowToTour(offer.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-bold text-slate-900">{offer.show.venue_name}</h4>
                          <div className="flex items-center gap-4 text-sm text-slate-600 mt-1">
                            <span>{(() => {
                              const eventDate = parseLocalDate(offer.show.event_date);
                              return eventDate ? eventDate.toLocaleDateString() : 'Invalid date';
                            })()}</span>
                            <span>{offer.show.capacity} capacity</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-slate-600">Projected Profit</div>
                          <div className="text-xl font-bold text-green-600">
                            ${Math.round(offer.calculations.netProfit / 1000)}K
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 text-slate-500">
                    <p>No available offers</p>
                    <button
                      onClick={() => navigate('/offers/create')}
                      className="mt-4 text-indigo-600 hover:text-indigo-700 font-medium"
                    >
                      Create a new offer first
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
