/*
  # Add Admin Role System

  1. Changes
    - Add `is_admin` column to auth.users metadata
    - Create `user_roles` table to track admin status
    - Add RLS policies for admin access
    - Set jhuaroco@gmail.com as admin

  2. Security
    - Enable RLS on `user_roles` table
    - Only admins can view all user roles
    - Users can view their own role status
*/

-- Create user_roles table to track admin status
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  is_admin boolean DEFAULT false NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own role
CREATE POLICY "Users can view own role"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policy: Admins can view all roles
CREATE POLICY "Admins can view all roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.is_admin = true
    )
  );

-- Policy: Admins can update roles
CREATE POLICY "Admins can update roles"
  ON user_roles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.is_admin = true
    )
  );

-- Policy: System can insert roles (for new user creation)
CREATE POLICY "System can insert roles"
  ON user_roles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create function to automatically create user_role entry for new users
CREATE OR REPLACE FUNCTION create_user_role()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_roles (user_id, is_admin)
  VALUES (NEW.id, false)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to auto-create user_role on user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_user_role();

-- Set jhuaroco@gmail.com as admin
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Get the user ID for jhuaroco@gmail.com
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = 'jhuaroco@gmail.com';

  -- If user exists, make them admin
  IF admin_user_id IS NOT NULL THEN
    INSERT INTO user_roles (user_id, is_admin)
    VALUES (admin_user_id, true)
    ON CONFLICT (user_id)
    DO UPDATE SET is_admin = true, updated_at = now();
  END IF;
END $$;

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_is_admin ON user_roles(is_admin);
